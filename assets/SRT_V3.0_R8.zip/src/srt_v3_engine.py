#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SRT V3.0 parser and source-verification engine.
Production support for the ACTIVE srt切片文案 V3.0 workflow.
Python standard library only. Reads each input SRT once per parse invocation.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import re
import unicodedata
from collections import Counter
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Iterable

TS_PATTERN = re.compile(r"^(?P<h>\d{2,}):(?P<m>[0-5]\d):(?P<s>[0-5]\d),(?P<ms>\d{3})$")
SUPPORT_PACKAGE_REVISION = "R8"

TIMING_PATTERN = re.compile(
    r"^\s*(\d{2,}:[0-5]\d:[0-5]\d,\d{3})\s*-->\s*"
    r"(\d{2,}:[0-5]\d:[0-5]\d,\d{3})(?:\s+.*)?$"
)

def timestamp_to_ms(value: str) -> int:
    match = TS_PATTERN.fullmatch(value.strip())
    if not match:
        raise ValueError(f"Invalid SRT timestamp: {value!r}")
    hours = int(match.group("h"))
    minutes = int(match.group("m"))
    seconds = int(match.group("s"))
    millis = int(match.group("ms"))
    return (((hours * 60) + minutes) * 60 + seconds) * 1000 + millis

def format_ms_dot(value: int) -> str:
    hours, rem = divmod(value, 3_600_000)
    minutes, rem = divmod(rem, 60_000)
    seconds, millis = divmod(rem, 1_000)
    return f"{hours:02}:{minutes:02}:{seconds:02}.{millis:03}"

def format_ms_comma(value: int) -> str:
    return format_ms_dot(value).replace(".", ",")

def union_duration_ms(intervals: Iterable[tuple[int, int]]) -> int:
    valid = sorted((int(s), int(e)) for s, e in intervals if e > s)
    if not valid:
        return 0
    total = 0
    cur_s, cur_e = valid[0]
    for start, end in valid[1:]:
        if start <= cur_e:
            cur_e = max(cur_e, end)
        else:
            total += cur_e - cur_s
            cur_s, cur_e = start, end
    total += cur_e - cur_s
    return total

def compress_int_ranges(values: Iterable[int]) -> list[str]:
    vals = sorted(set(int(v) for v in values))
    if not vals:
        return []
    ranges=[]
    start=prev=vals[0]
    for value in vals[1:]:
        if value == prev + 1:
            prev=value
        else:
            ranges.append(str(start) if start == prev else f"{start}-{prev}")
            start=prev=value
    ranges.append(str(start) if start == prev else f"{start}-{prev}")
    return ranges

def decode_srt_strict(raw: bytes) -> tuple[str, str]:
    """Decode strictly in the required order while reporting the actual UTF-8 form."""
    failures = []
    for encoding in ("utf-8-sig", "utf-8", "gb18030"):
        try:
            decoded = raw.decode(encoding, errors="strict")
            if encoding == "utf-8-sig":
                actual_label = "utf-8-sig" if raw.startswith(b"\xef\xbb\xbf") else "utf-8"
                return decoded, actual_label
            return decoded, encoding
        except UnicodeDecodeError as exc:
            failures.append(f"{encoding}: {exc}")
    raise UnicodeError("SRT cannot be decoded strictly; " + " | ".join(failures))

def parse_srt_bytes_v3(
    raw: bytes,
    filename: str,
    file_id: str | None = None,
    long_gap_threshold_ms: int = 5_000,
) -> dict[str, Any]:
    source_hash = hashlib.sha256(raw).hexdigest()
    stable_file_id = f"{file_id}:{source_hash[:16]}" if file_id else f"{filename}:{source_hash[:16]}"
    decoded, encoding = decode_srt_strict(raw)
    normalized = decoded.replace("\r\n", "\n").replace("\r", "\n")
    stripped = normalized.strip("\n")
    blocks = re.split(r"\n[ \t]*\n+", stripped) if stripped else []
    entries: list[dict[str, Any]] = []
    malformed: list[dict[str, Any]] = []

    for block_ordinal, block in enumerate(blocks, start=1):
        lines = block.split("\n")
        if len(lines) < 2:
            malformed.append({
                "block_ordinal": block_ordinal,
                "reason": "block_has_fewer_than_two_lines",
                "raw_preview": block[:160],
            })
            continue

        index_text = lines[0].strip()
        if not re.fullmatch(r"\d+", index_text):
            malformed.append({
                "block_ordinal": block_ordinal,
                "reason": "invalid_index_line",
                "raw_preview": block[:160],
            })
            continue

        timing = TIMING_PATTERN.fullmatch(lines[1])
        if not timing:
            malformed.append({
                "block_ordinal": block_ordinal,
                "reason": "invalid_timestamp_line",
                "raw_preview": block[:160],
            })
            continue

        try:
            start_ms = timestamp_to_ms(timing.group(1))
            end_ms = timestamp_to_ms(timing.group(2))
        except ValueError as exc:
            malformed.append({
                "block_ordinal": block_ordinal,
                "reason": "invalid_timestamp_value",
                "detail": str(exc),
                "raw_preview": block[:160],
            })
            continue

        original_text = "\n".join(lines[2:])
        cue_index = int(index_text)
        entry = {
            "file_id": stable_file_id,
            "filename": filename,
            "block_ordinal": block_ordinal,
            "index": cue_index,
            "index_raw": index_text,
            "source_key": f"{stable_file_id}:{block_ordinal}:{index_text}",
            "start_ms": start_ms,
            "end_ms": end_ms,
            "start_raw": timing.group(1),
            "end_raw": timing.group(2),
            "original_text": original_text,
        }
        entries.append(entry)

    indices = [e["index"] for e in entries]
    counts = Counter(indices)
    duplicate_indices = sorted(i for i, n in counts.items() if n > 1)
    missing_indices = []
    if indices and max(indices) - min(indices) <= 100_000:
        present = set(indices)
        missing_indices = [i for i in range(min(indices), max(indices) + 1) if i not in present]

    zero_duration = [e["index"] for e in entries if e["end_ms"] == e["start_ms"]]
    negative_duration = [e["index"] for e in entries if e["end_ms"] < e["start_ms"]]
    empty_text = [e["index"] for e in entries if not e["original_text"].strip()]
    non_increasing_indices = [
        (prev["index"], cur["index"])
        for prev, cur in zip(entries, entries[1:])
        if cur["index"] <= prev["index"]
    ]
    source_time_reversals = [
        (prev["index"], cur["index"])
        for prev, cur in zip(entries, entries[1:])
        if cur["start_ms"] < prev["start_ms"]
    ]

    chronological = sorted((e for e in entries if e["end_ms"] > e["start_ms"]), key=lambda e: (e["start_ms"], e["end_ms"], e["block_ordinal"]))
    overlaps = []
    active: list[dict[str, Any]] = []
    for current in chronological:
        active = [e for e in active if e["end_ms"] > current["start_ms"]]
        for previous in active:
            overlaps.append({
                "index_a": previous["index"],
                "index_b": current["index"],
                "overlap_ms": min(previous["end_ms"], current["end_ms"]) - current["start_ms"],
            })
        active.append(current)

    long_gaps = []
    for previous, current in zip(entries, entries[1:]):
        gap = current["start_ms"] - previous["end_ms"]
        if gap > long_gap_threshold_ms:
            long_gaps.append({
                "after_index": previous["index"],
                "before_index": current["index"],
                "gap_ms": gap,
            })

    all_intervals = [(e["start_ms"], e["end_ms"]) for e in entries if e["end_ms"] > e["start_ms"]]
    coverage_start = min((e["start_ms"] for e in entries), default=None)
    coverage_end = max((e["end_ms"] for e in entries), default=None)
    overall_span = (coverage_end - coverage_start) if coverage_start is not None and coverage_end is not None else 0
    overall_coverage = union_duration_ms(all_intervals)

    index_map: dict[int, list[dict[str, Any]]] = {}
    for entry in entries:
        index_map.setdefault(entry["index"], []).append(entry)

    diagnostics = {
        "total_blocks": len(blocks),
        "parsed_entries": len(entries),
        "malformed_blocks": malformed,
        "duplicate_indices": duplicate_indices,
        "missing_index_ranges": compress_int_ranges(missing_indices),
        "zero_duration": zero_duration,
        "negative_duration": negative_duration,
        "empty_text": empty_text,
        "non_increasing_indices": non_increasing_indices,
        "source_time_reversals": source_time_reversals,
        "overlaps": overlaps,
        "long_gaps": long_gaps,
        "fully_parsed": bool(blocks) and len(blocks) == len(entries) and not malformed,
        "index_unique": not duplicate_indices,
        "serials_start_at_one": bool(indices) and indices[0] == 1,
        "time_order_valid": not source_time_reversals,
        "duration_valid": not zero_duration and not negative_duration,
    }

    return {
        "file_id": stable_file_id,
        "filename": filename,
        "sha256": source_hash,
        "encoding": encoding,
        "total_entries": len(entries),
        "entries": entries,
        "entries_by_index": index_map,
        "diagnostics": diagnostics,
        "coverage_start_ms": coverage_start,
        "coverage_end_ms": coverage_end,
        "overall_span_ms": overall_span,
        "overall_subtitle_coverage_ms": overall_coverage,
        "overall_uncovered_gap_ms": max(0, overall_span - overall_coverage),
    }

def parse_srt_path_v3(path: str, long_gap_threshold_ms: int = 5_000) -> dict[str, Any]:
    source_path = Path(path)
    if source_path.suffix.lower() != ".srt":
        raise ValueError(f"Only .srt inputs are accepted by the pure-SRT project: {source_path.name}")
    raw = source_path.read_bytes()  # exactly one byte read per invocation
    return parse_srt_bytes_v3(
        raw,
        filename=source_path.name,
        file_id=str(source_path.resolve()),
        long_gap_threshold_ms=long_gap_threshold_ms,
    )

def _entry_for_index(doc: dict[str, Any], index: int) -> dict[str, Any]:
    matches = doc["entries_by_index"].get(int(index), [])
    if len(matches) == 0:
        raise KeyError(f"Source index {index} does not exist in {doc['filename']}")
    if len(matches) > 1:
        raise ValueError(f"Source index {index} is ambiguous in {doc['filename']}")
    return matches[0]

def validate_and_plan_groups(
    doc: dict[str, Any],
    groups: list[list[int]],
    allow_repeats: bool = False,
    repeat_reason: str | None = None,
) -> dict[str, Any]:
    if not groups:
        raise ValueError("At least one clip group is required.")

    all_occurrences: list[int] = []
    all_occurrences_raw: list[str] = []
    seen_indices: Counter[int] = Counter()
    group_results = []
    cursor_ms = 0

    for group_no, raw_indices in enumerate(groups, start=1):
        if not raw_indices:
            raise ValueError(f"Clip group {group_no} is empty.")
        indices = [int(i) for i in raw_indices]
        # Plans hold independent snapshots; the parsed source index remains immutable.
        entries = [dict(_entry_for_index(doc, i)) for i in indices]
        if any(e["end_ms"] <= e["start_ms"] for e in entries):
            raise ValueError(f"Clip group {group_no} contains a zero/negative-duration source cue.")
        if any(b["start_ms"] < a["start_ms"] for a, b in zip(entries, entries[1:])):
            raise ValueError(f"Clip group {group_no} contains a source-time reversal.")

        block_ordinals = [e["block_ordinal"] for e in entries]
        if block_ordinals != sorted(block_ordinals):
            raise ValueError(f"Clip group {group_no} is not in source order.")
        if any(b != a + 1 for a, b in zip(block_ordinals, block_ordinals[1:])):
            raise ValueError(
                f"Clip group {group_no} skips source subtitle blocks; split it into separate groups."
            )

        for idx in indices:
            seen_indices[idx] += 1
            if seen_indices[idx] > 1 and not allow_repeats:
                raise ValueError(f"Source subtitle {idx} is repeated without explicit repeat permission.")
        all_occurrences.extend(indices)
        all_occurrences_raw.extend(e["index_raw"] for e in entries)

        group_start = min(e["start_ms"] for e in entries)
        group_end = max(e["end_ms"] for e in entries)
        span = group_end - group_start
        coverage = union_duration_ms((e["start_ms"], e["end_ms"]) for e in entries)
        uncovered = max(0, span - coverage)
        timeline_start = cursor_ms
        timeline_end = cursor_ms + span

        group_results.append({
            "group_no": group_no,
            "indices": indices,
            "source_keys": [e["source_key"] for e in entries],
            "source_start_ms": group_start,
            "source_end_ms": group_end,
            "source_span_ms": span,
            "subtitle_coverage_ms": coverage,
            "uncovered_gap_ms": uncovered,
            "timeline_start_ms": timeline_start,
            "timeline_end_ms": timeline_end,
            "entries": entries,
        })
        cursor_ms = timeline_end

    # Distinct groups whose source time ranges overlap imply replay or a boundary ambiguity.
    cross_group_overlaps = []
    for i, left in enumerate(group_results):
        for right in group_results[i + 1:]:
            overlap = min(left["source_end_ms"], right["source_end_ms"]) - max(
                left["source_start_ms"], right["source_start_ms"]
            )
            if overlap > 0:
                cross_group_overlaps.append({
                    "group_a": left["group_no"],
                    "group_b": right["group_no"],
                    "overlap_ms": overlap,
                })
    repeat_counts = {str(k): v for k, v in seen_indices.items() if v > 1}
    if (repeat_counts or cross_group_overlaps) and not allow_repeats:
        raise ValueError(
            "Repeated source cues or overlapping source-time groups require explicit repeat permission."
        )
    if (repeat_counts or cross_group_overlaps) and not (repeat_reason and repeat_reason.strip()):
        raise ValueError(
            "Intentional replay must include a concrete repeat_reason."
        )

    serials = ",".join(all_occurrences_raw)
    return {
        "groups": group_results,
        "selected_count": len(all_occurrences),
        "selected_indices_in_playback_order": all_occurrences,
        "serials": serials,
        "total_planned_span_ms": cursor_ms,
        "total_subtitle_coverage_ms": sum(g["subtitle_coverage_ms"] for g in group_results),
        "total_uncovered_gap_ms": sum(g["uncovered_gap_ms"] for g in group_results),
        "cross_group_overlaps": cross_group_overlaps,
        "repeat_counts": repeat_counts,
        "repeat_reason": repeat_reason.strip() if repeat_reason else None,
        "duration_target_status": "within_45_90s" if 45_000 <= cursor_ms <= 90_000 else "outside_45_90s",
    }


SOURCE_ENTRY_FIELDS = (
    "source_key", "file_id", "filename", "block_ordinal", "index",
    "index_raw", "start_ms", "end_ms", "start_raw", "end_raw",
    "original_text",
)


def _source_entries_by_key(doc: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Build a unique immutable lookup from the parsed source records."""
    by_key: dict[str, dict[str, Any]] = {}
    for entry in doc.get("entries", []):
        key = entry.get("source_key")
        if not key or key in by_key:
            raise ValueError("Parsed source index contains a missing or duplicate source_key.")
        by_key[key] = entry
    return by_key


def resolve_plan_entries_from_source(
    doc: dict[str, Any], plan: dict[str, Any]
) -> list[list[dict[str, Any]]]:
    """Resolve playback entries by source_key and return canonical source objects.

    The planned objects are treated as references/claims only. Every displayed cue is
    rendered from the original parsed source object after all fields are compared.
    """
    source_by_key = _source_entries_by_key(doc)
    canonical_groups: list[list[dict[str, Any]]] = []
    for group_no, group in enumerate(plan.get("groups", []), start=1):
        if group.get("group_no") != group_no:
            raise ValueError(f"Clip group numbering drift at group {group_no}.")
        planned_entries = group.get("entries", [])
        canonical_entries: list[dict[str, Any]] = []
        for planned in planned_entries:
            key = planned.get("source_key")
            original = source_by_key.get(key)
            if original is None:
                raise ValueError(f"Unknown source_key in clip group {group_no}: {key!r}")
            mismatches = [
                field for field in SOURCE_ENTRY_FIELDS
                if planned.get(field) != original.get(field)
            ]
            if mismatches:
                raise ValueError(
                    f"Source mapping mismatch for cue {original.get('index_raw')} "
                    f"in group {group_no}: {', '.join(mismatches)}."
                )
            if original["end_ms"] <= original["start_ms"]:
                raise ValueError(f"Source cue {original['index_raw']} has non-positive duration.")
            if timestamp_to_ms(original["start_raw"]) != original["start_ms"]:
                raise ValueError(f"Source cue {original['index_raw']} start timestamp is inconsistent.")
            if timestamp_to_ms(original["end_raw"]) != original["end_ms"]:
                raise ValueError(f"Source cue {original['index_raw']} end timestamp is inconsistent.")
            canonical_entries.append(original)

        if not canonical_entries:
            raise ValueError(f"Clip group {group_no} is empty.")
        indices = [entry["index"] for entry in canonical_entries]
        keys = [entry["source_key"] for entry in canonical_entries]
        if group.get("indices") != indices:
            raise ValueError(f"Clip group {group_no} index list does not match its source entries.")
        if group.get("source_keys") != keys:
            raise ValueError(f"Clip group {group_no} source_key list does not match its source entries.")
        ordinals = [entry["block_ordinal"] for entry in canonical_entries]
        if ordinals != sorted(ordinals) or any(b != a + 1 for a, b in zip(ordinals, ordinals[1:])):
            raise ValueError(f"Clip group {group_no} is not a contiguous source-order group.")
        if any(b["start_ms"] < a["start_ms"] for a, b in zip(canonical_entries, canonical_entries[1:])):
            raise ValueError(f"Clip group {group_no} contains a source-time reversal.")
        canonical_groups.append(canonical_entries)
    return canonical_groups


def verify_final_selection(
    doc: dict[str, Any],
    plan: dict[str, Any],
    expected_indices: list[int] | None = None,
    _canonical_groups: list[list[dict[str, Any]]] | None = None,
) -> dict[str, Any]:
    checks: list[dict[str, bool]] = []
    group_checks: list[dict[str, bool]] = []
    errors: list[str] = []
    if _canonical_groups is not None:
        canonical_groups = _canonical_groups
    else:
        try:
            canonical_groups = resolve_plan_entries_from_source(doc, plan)
        except (KeyError, TypeError, ValueError) as exc:
            canonical_groups = []
            errors.append(str(exc))

    flattened_entries = [entry for group in canonical_groups for entry in group]
    flattened_indices = [entry["index"] for entry in flattened_entries]
    planned_indices = plan.get("selected_indices_in_playback_order", [])
    expected_serials = ",".join(entry["index_raw"] for entry in flattened_entries)
    playback_order_pass = flattened_indices == planned_indices
    if expected_indices is not None:
        playback_order_pass = playback_order_pass and expected_indices == flattened_indices

    cursor_ms = 0
    expected_coverage_ms = 0
    expected_uncovered_ms = 0
    for group_no, (group, source_entries) in enumerate(zip(plan.get("groups", []), canonical_groups), start=1):
        group_start = min(entry["start_ms"] for entry in source_entries)
        group_end = max(entry["end_ms"] for entry in source_entries)
        span = group_end - group_start
        coverage = union_duration_ms((entry["start_ms"], entry["end_ms"]) for entry in source_entries)
        uncovered = max(0, span - coverage)
        group_checks.append({
            "group_no_exact": group.get("group_no") == group_no,
            "source_start_exact": group.get("source_start_ms") == group_start,
            "source_end_exact": group.get("source_end_ms") == group_end,
            "source_span_exact": group.get("source_span_ms") == span,
            "coverage_exact": group.get("subtitle_coverage_ms") == coverage,
            "uncovered_exact": group.get("uncovered_gap_ms") == uncovered,
            "timeline_start_exact": group.get("timeline_start_ms") == cursor_ms,
            "timeline_end_exact": group.get("timeline_end_ms") == cursor_ms + span,
        })
        cursor_ms += span
        expected_coverage_ms += coverage
        expected_uncovered_ms += uncovered

    # Cue-level checks are generated by looking each source_key up in the original index.
    for group, source_entries in zip(plan.get("groups", []), canonical_groups):
        for planned, original in zip(group.get("entries", []), source_entries):
            checks.append({
                "source_key_exact": planned.get("source_key") == original["source_key"],
                "file_id_exact": planned.get("file_id") == original["file_id"],
                "filename_exact": planned.get("filename") == original["filename"],
                "block_ordinal_exact": planned.get("block_ordinal") == original["block_ordinal"],
                "index_exists": original["index"] == planned.get("index"),
                "index_token_exact": original["index_raw"] == planned.get("index_raw"),
                "text_exact": original["original_text"] == planned.get("original_text"),
                "time_exact": (
                    original["start_ms"] == planned.get("start_ms")
                    and original["end_ms"] == planned.get("end_ms")
                    and original["start_raw"] == planned.get("start_raw")
                    and original["end_raw"] == planned.get("end_raw")
                ),
                "timestamp_direction_valid": original["start_ms"] < original["end_ms"],
                "timestamp_numeric_consistent": (
                    timestamp_to_ms(original["start_raw"]) == original["start_ms"]
                    and timestamp_to_ms(original["end_raw"]) == original["end_ms"]
                ),
            })

    count_pass = (
        plan.get("selected_count") == len(flattened_entries)
        and len(planned_indices) == len(flattened_entries)
    )
    serials_source_mapping_pass = plan.get("serials") == expected_serials
    plan_metrics_pass = (
        plan.get("total_planned_span_ms") == cursor_ms
        and plan.get("total_subtitle_coverage_ms") == expected_coverage_ms
        and plan.get("total_uncovered_gap_ms") == expected_uncovered_ms
    )
    copy_contract = serial_copy_contract(expected_serials)
    serials_codeblock_equals_final_line = (
        copy_contract["code_block_payload"] == copy_contract["absolute_final_line"]
        and copy_contract["copy_button_payload"] == copy_contract["code_block_payload"]
    )
    cue_checks_pass = bool(checks) and all(all(row.values()) for row in checks)
    group_metadata_pass = bool(group_checks) and all(all(row.values()) for row in group_checks)
    return {
        "checks": len(checks),
        "index_pass": bool(checks) and all(row["index_exists"] for row in checks),
        "index_token_pass": bool(checks) and all(row["index_token_exact"] for row in checks),
        "text_pass": bool(checks) and all(row["text_exact"] for row in checks),
        "time_pass": bool(checks) and all(row["time_exact"] and row["timestamp_direction_valid"] and row["timestamp_numeric_consistent"] for row in checks),
        "source_key_pass": bool(checks) and all(row["source_key_exact"] for row in checks),
        "file_identity_pass": bool(checks) and all(row["file_id_exact"] and row["filename_exact"] and row["block_ordinal_exact"] for row in checks),
        "playback_order_pass": playback_order_pass,
        "group_metadata_pass": group_metadata_pass,
        "plan_metrics_pass": plan_metrics_pass,
        "count_pass": count_pass,
        "serials_source_mapping_pass": serials_source_mapping_pass,
        "serials_codeblock_equals_final_line": serials_codeblock_equals_final_line,
        "errors": errors,
        "all_pass": (
            cue_checks_pass and group_metadata_pass and plan_metrics_pass and count_pass
            and playback_order_pass and serials_source_mapping_pass
            and serials_codeblock_equals_final_line and not errors
        ),
    }



def build_verified_manifest(
    doc: dict[str, Any],
    plan: dict[str, Any],
    expected_indices: list[int] | None = None,
) -> dict[str, Any]:
    """Run the deterministic Final Gate once and materialize one canonical output manifest.

    All third/fifth-section data surfaces should consume this object instead of
    recomputing counts, timestamps, source mappings, or copy payloads independently.
    """
    planned_flattened = [
        entry.get("index") for group in plan.get("groups", []) for entry in group.get("entries", [])
    ]
    if plan.get("selected_indices_in_playback_order", []) != planned_flattened:
        raise AssertionError("Playback order array does not match the actual ordered clip groups.")

    try:
        canonical_groups = resolve_plan_entries_from_source(doc, plan)
    except (KeyError, TypeError, ValueError):
        canonical_groups = []

    verification = verify_final_selection(
        doc, plan, expected_indices=expected_indices,
        _canonical_groups=canonical_groups if canonical_groups else None,
    )

    groups: list[dict[str, Any]] = []
    entries_flat: list[dict[str, Any]] = []
    cursor_ms = 0
    total_coverage_ms = 0
    total_uncovered_ms = 0
    for group_no, source_entries in enumerate(canonical_groups, start=1):
        group_start = min(entry["start_ms"] for entry in source_entries)
        group_end = max(entry["end_ms"] for entry in source_entries)
        span = group_end - group_start
        coverage = union_duration_ms((entry["start_ms"], entry["end_ms"]) for entry in source_entries)
        uncovered = max(0, span - coverage)
        # Reuse immutable canonical source objects in-memory; serialization copies values only when requested.
        canonical_entries = list(source_entries)
        groups.append({
            "group_no": group_no,
            "source_keys": [entry["source_key"] for entry in source_entries],
            "indices": [entry["index"] for entry in source_entries],
            "index_raw_tokens": [entry["index_raw"] for entry in source_entries],
            "source_start_ms": group_start,
            "source_end_ms": group_end,
            "source_span_ms": span,
            "subtitle_coverage_ms": coverage,
            "uncovered_gap_ms": uncovered,
            "timeline_start_ms": cursor_ms,
            "timeline_end_ms": cursor_ms + span,
            "entries": canonical_entries,
        })
        entries_flat.extend(canonical_entries)
        cursor_ms += span
        total_coverage_ms += coverage
        total_uncovered_ms += uncovered

    serials = ",".join(entry["index_raw"] for entry in entries_flat)
    copy_contract = serial_copy_contract(serials)
    selected_count = len(entries_flat)
    count_consistent = (
        selected_count == int(plan.get("selected_count", -1))
        and selected_count == len(plan.get("selected_indices_in_playback_order", []))
    )
    serials_consistent = plan.get("serials") == serials
    copy_payloads_consistent = validate_copy_payloads(
        copy_contract["copy_button_payload"],
        copy_contract["code_block_payload"],
        copy_contract["absolute_final_line"],
    ) if serials else False
    metrics_consistent = (
        plan.get("total_planned_span_ms") == cursor_ms
        and plan.get("total_subtitle_coverage_ms") == total_coverage_ms
        and plan.get("total_uncovered_gap_ms") == total_uncovered_ms
    )
    all_pass = bool(
        verification["all_pass"] and count_consistent and serials_consistent
        and copy_payloads_consistent and metrics_consistent and groups
    )
    manifest_identity = {
        "workflow_version": "V3.0",
        "file_id": doc.get("file_id"),
        "filename": doc.get("filename"),
        "sha256": doc.get("sha256"),
        "source_keys": [entry["source_key"] for entry in entries_flat],
        "groups": [[entry["source_key"] for entry in group["entries"]] for group in groups],
    }
    manifest_id = hashlib.sha256(
        json.dumps(manifest_identity, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    return {
        "schema": "srt_v3_verified_manifest_v1",
        "manifest_id": manifest_id,
        "file_id": doc.get("file_id"),
        "filename": doc.get("filename"),
        "sha256": doc.get("sha256"),
        "selected_count": selected_count,
        "serial_count": len(entries_flat),
        "group_count": len(groups),
        "serials": serials,
        **copy_contract,
        "groups": groups,
        "entries": entries_flat,
        "total_planned_span_ms": cursor_ms,
        "total_subtitle_coverage_ms": total_coverage_ms,
        "total_uncovered_gap_ms": total_uncovered_ms,
        "count_consistent": count_consistent,
        "serials_consistent": serials_consistent,
        "copy_payloads_consistent": copy_payloads_consistent,
        "metrics_consistent": metrics_consistent,
        "verification": verification,
        "all_pass": all_pass,
    }

def validate_verified_manifest_for_render(
    doc: dict[str, Any],
    plan: dict[str, Any],
    manifest: dict[str, Any],
) -> bool:
    """Validate a previously built manifest without re-reading canonical source rows."""
    if not manifest.get("all_pass"):
        raise ValueError("Verified manifest is not passing.")
    if manifest.get("file_id") != doc.get("file_id") or manifest.get("filename") != doc.get("filename"):
        raise ValueError("Verified manifest file identity does not match the current document.")
    if manifest.get("sha256") != doc.get("sha256"):
        raise ValueError("Verified manifest SHA-256 does not match the current document.")
    plan_source_keys = [key for group in plan.get("groups", []) for key in group.get("source_keys", [])]
    manifest_source_keys = [entry.get("source_key") for entry in manifest.get("entries", [])]
    if plan_source_keys != manifest_source_keys:
        raise ValueError("Verified manifest playback source_keys do not match the plan.")
    if manifest.get("selected_count") != plan.get("selected_count") or manifest.get("serials") != plan.get("serials"):
        raise ValueError("Verified manifest count/serials do not match the plan.")
    identity = {
        "workflow_version": "V3.0",
        "file_id": doc.get("file_id"),
        "filename": doc.get("filename"),
        "sha256": doc.get("sha256"),
        "source_keys": manifest_source_keys,
        "groups": [list(group.get("source_keys", [])) for group in manifest.get("groups", [])],
    }
    expected_id = hashlib.sha256(
        json.dumps(identity, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    if manifest.get("manifest_id") != expected_id:
        raise ValueError("Verified manifest identity hash mismatch.")
    return True


def validate_five_section_contract(headings: list[str]) -> bool:
    return headings == FIVE_SECTION_HEADINGS

def validate_five_part_document(rendered_text: str) -> bool:
    """Check that all five fixed top-level headings appear once and in order."""
    present = [
        line.strip()
        for line in rendered_text.splitlines()
        if line.strip() in FIVE_SECTION_HEADINGS
    ]
    return present == FIVE_SECTION_HEADINGS

def serial_copy_contract(serials: str) -> dict[str, str]:
    return {
        "copy_button_payload": serials,
        "code_block_payload": serials,
        "absolute_final_line": serials,
    }

def validate_copy_payloads(
    copy_button_payload: str,
    code_block_payload: str,
    absolute_final_line: str,
) -> bool:
    """Validate payload syntax and exact equality; UI click remains a client-side test."""
    values = (copy_button_payload, code_block_payload, absolute_final_line)
    if not all(re.fullmatch(r"\d+(,\d+)*", value or "") for value in values):
        return False
    return values[0] == values[1] == values[2]


def render_fifth_section(
    doc: dict[str, Any],
    plan: dict[str, Any],
    verified_manifest: dict[str, Any] | None = None,
) -> dict[str, str | int | bool]:
    """Build Part Five from the same verified manifest used by Part Three when supplied."""
    if not validate_embedded_format_contract():
        raise ValueError("Embedded frozen format contract hash mismatch; audit contract re-read is required.")
    manifest = verified_manifest if verified_manifest is not None else build_verified_manifest(doc, plan)
    if verified_manifest is not None:
        validate_verified_manifest_for_render(doc, plan, manifest)
    if not manifest["all_pass"]:
        raise ValueError("Part Five rendering is blocked because count/source/copy contract verification failed.")
    serials = str(manifest["serials"])
    return {
        "heading": FROZEN_FIFTH_SECTION_HEADING,
        "count_label": f"最终序号：{manifest['selected_count']}条字幕",
        "selected_count": manifest["selected_count"],
        "group_count": manifest["group_count"],
        "copy_button_payload": serials,
        "code_block_payload": serials,
        "code_block_text": f"```text\n{serials}\n```",
        "absolute_final_line": serials,
        "verified_manifest_id": manifest["manifest_id"],
        "all_pass": True,
    }


# ---------------------------------------------------------------------------
# V3.0 quality-optimization validators. Semantic judgments are supplied by the
# assistant as review data; Python validates completeness, provenance and gates.
# ---------------------------------------------------------------------------

CRITICAL_NUMERIC_PATTERNS = {
    "material_composition_ambiguous": re.compile(
        r"(?P<value>\d+(?:\.\d+)?)\s*的\s*(?P<material>羊毛|羊绒|棉|蚕丝|真丝|羽绒|羊毛混纺|绒)",
        re.IGNORECASE,
    ),
    "material_percentage_explicit": re.compile(
        r"(?P<value>\d+(?:\.\d+)?)\s*(?:%|％|百分之)(?P<material>羊毛|羊绒|棉|蚕丝|真丝|羽绒|绒)?",
        re.IGNORECASE,
    ),
    "material_specification": re.compile(r"(?P<value>\d+(?:\.\d+)?)\s*(?P<unit>支|支纱|支数)"),
    "weight_or_size": re.compile(r"(?P<value>\d+(?:\.\d+)?)\s*(?P<unit>克|公斤|kg|KG|斤|磅|g|G)"),
    "price_explicit": re.compile(r"(?:￥|¥)?\s*(?P<value>\d+(?:\.\d+)?)\s*(?P<unit>元|块|人民币)"),
    "discount_explicit": re.compile(r"(?P<value>\d+(?:\.\d+)?)\s*(?P<unit>折)"),
    "inventory_explicit": re.compile(r"(?P<value>\d+(?:\.\d+)?|[一二三四五六七八九十百千万两几多]+)\s*(?P<unit>件|条|单|个)(?:首单|库存)?"),
}


def detect_critical_numeric_candidates(doc: dict[str, Any]) -> list[dict[str, Any]]:
    """Find numeric claims needing human review; this is a candidate finder, not a fact classifier."""
    candidates: list[dict[str, Any]] = []
    entries = doc["entries"]
    for position, entry in enumerate(entries):
        text = entry["original_text"]
        previous_text = entries[position - 1]["original_text"] if position > 0 else ""
        next_text = entries[position + 1]["original_text"] if position + 1 < len(entries) else ""
        found: dict[str, dict[str, Any]] = {}
        if "羊毛" in text or "羊绒" in text or "棉" in text or "蚕丝" in text or "真丝" in text or "羽绒" in text or "绒" in text:
            ambiguous = CRITICAL_NUMERIC_PATTERNS["material_composition_ambiguous"].search(text)
            explicit = CRITICAL_NUMERIC_PATTERNS["material_percentage_explicit"].search(text)
            if ambiguous:
                found["material_composition"] = {
                    "risk": "ambiguous_missing_unit",
                    "matched_values": [ambiguous.group("value")],
                    "evidence_kind": "number_before_de_without_percentage_unit",
                }
            elif explicit:
                found["material_composition"] = {
                    "risk": "explicit_unit_requires_context_review",
                    "matched_values": [explicit.group("value")],
                    "evidence_kind": "explicit_percentage_unit",
                }
        if "支" in text:
            matches = list(CRITICAL_NUMERIC_PATTERNS["material_specification"].finditer(text))
            if matches:
                found["material_specification"] = {
                    "risk": "explicit_unit_requires_context_review",
                    "matched_values": [m.group("value") + m.group("unit") for m in matches],
                    "evidence_kind": "explicit_fabric_count_unit",
                }
        if any(term in text for term in ("斤", "尺码", "身高", "体重", "穿S", "穿M", "穿L", "码")):
            matches = list(CRITICAL_NUMERIC_PATTERNS["weight_or_size"].finditer(text))
            size_codes = re.findall(r"(?<![A-Za-z])(?:XS|S|M|L|XL|XXL)\s*码", text, re.IGNORECASE)
            if matches or size_codes:
                found["size_guidance"] = {
                    "risk": "explicit_unit_requires_context_review",
                    "matched_values": [m.group("value") + m.group("unit") for m in matches] + size_codes,
                    "evidence_kind": "explicit_size_or_weight_unit",
                }
        else:
            matches = list(CRITICAL_NUMERIC_PATTERNS["weight_or_size"].finditer(text))
            if matches:
                found["weight"] = {
                    "risk": "explicit_unit_requires_context_review",
                    "matched_values": [m.group("value") + m.group("unit") for m in matches],
                    "evidence_kind": "explicit_weight_unit",
                }
        if any(term in text for term in ("价格", "售价", "到手", "券后", "给到", "原价", "减了", "优惠")):
            matches = list(CRITICAL_NUMERIC_PATTERNS["price_explicit"].finditer(text))
            if matches:
                found["price"] = {
                    "risk": "explicit_unit_requires_context_review",
                    "matched_values": [m.group("value") + m.group("unit") for m in matches],
                    "evidence_kind": "explicit_currency_unit",
                }
            elif re.search(r"\d", text):
                nums = re.findall(r"\d+(?:\.\d+)?", text)
                found["price"] = {
                    "risk": "ambiguous_missing_currency_or_format",
                    "matched_values": nums,
                    "evidence_kind": "price_context_without_clear_currency_unit",
                }
        if any(term in text for term in ("减", "折", "优惠")):
            matches = list(CRITICAL_NUMERIC_PATTERNS["discount_explicit"].finditer(text))
            if matches:
                found["discount"] = {
                    "risk": "explicit_unit_requires_context_review",
                    "matched_values": [m.group("value") + m.group("unit") for m in matches],
                    "evidence_kind": "explicit_discount_unit",
                }
            elif re.search(r"\d", text):
                found["discount"] = {
                    "risk": "ambiguous_number_or_discount_format",
                    "matched_values": re.findall(r"\d+(?:\.\d+)?", text),
                    "evidence_kind": "discount_context_without_clear_unit",
                }
        inventory_context = any(term in text for term in ("库存", "首单", "加单", "件了", "条了", "多少件", "多少条", "补货", "加一点", "上了"))
        inventory_context = inventory_context or any(term in previous_text for term in ("多少件", "多少条", "还剩多少", "多少库存"))
        inventory_context = inventory_context or any(term in next_text for term in ("库存", "首单", "加单", "件了", "条了"))
        large_quantity = bool(re.search(r"\d{2,}(?:多)?(?:件|条|单|个)", text))
        if inventory_context or large_quantity or any(term in text for term in ("首单", "库存", "加单", "加100", "加200")):
            matches = list(CRITICAL_NUMERIC_PATTERNS["inventory_explicit"].finditer(text))
            if matches:
                found["inventory"] = {
                    "risk": "explicit_unit_requires_context_review",
                    "matched_values": [m.group("value") + m.group("unit") for m in matches],
                    "evidence_kind": "explicit_quantity_unit_with_inventory_context",
                }
        for category, details in found.items():
            candidates.append({
                "candidate_id": f"{entry['source_key']}|{category}",
                "source_index": entry["index"],
                "source_key": entry["source_key"],
                "category": category,
                "raw_text": text,
                **details,
            })
    return candidates



def normalize_text_fingerprint(text: str) -> str:
    """Conservative mechanical fingerprint for exact/format-normalized duplicate detection."""
    normalized = unicodedata.normalize("NFKC", str(text)).casefold()
    return re.sub(r"[^\w]+", "", normalized, flags=re.UNICODE)


QUESTION_SURFACE_RE = re.compile(
    r"(?:[?？]|吗(?:$|[啊呀呢])|呢(?:$|[啊呀])|什么|哪(?:个|一|款|种|件|条|色)|怎么|怎样|多少|"
    r"有没有|有吗|是不是|对不对|可不可以|能不能|要不要|行不行|好不好|哪个)",
    re.IGNORECASE,
)
DEMONSTRATIVE_FRAGMENT_RE = re.compile(
    r"^(?:啊|呀|嗯|哦|对|好|来|看|你看|这个|这个是|这个颜色|那这个|然后|就是|所以|这样|这里|这个呢)$",
    re.IGNORECASE,
)


def mechanical_surface_flags(text: str) -> dict[str, bool]:
    """Surface-only hints. These are not semantic classifications or exclusion decisions."""
    normalized = normalize_text_fingerprint(text)
    return {
        "question_like": bool(QUESTION_SURFACE_RE.search(str(text))),
        "short_fragment_like": 0 < len(normalized) <= 5,
        "demonstrative_fragment_like": bool(DEMONSTRATIVE_FRAGMENT_RE.fullmatch(str(text).strip())),
    }


def _surface_similarity(a: str, b: str) -> float:
    a_fp = normalize_text_fingerprint(a)
    b_fp = normalize_text_fingerprint(b)
    if not a_fp or not b_fp:
        return 0.0
    if a_fp == b_fp:
        return 1.0
    if min(len(a_fp), len(b_fp)) < 4:
        return 0.0
    if a_fp in b_fp or b_fp in a_fp:
        return min(len(a_fp), len(b_fp)) / max(len(a_fp), len(b_fp))
    return SequenceMatcher(None, a_fp, b_fp, autojunk=False).ratio()


COMPRESSION_FILLER_RE = re.compile(
    r"(?:我觉得|你看|大家|其实|这个|那个|真的|就是|然后|所以|比较|超级|特别|非常|很|也|会|啊|呀|哦|呢|的)",
    re.IGNORECASE,
)
PROTECTED_TRANSACTION_TERMS = (
    "现货", "库存", "下单", "自己拍", "拍吧", "链接", "上车", "没了", "没有了", "不再加单", "不再做", "补货", "优惠", "券", "价格",
)


def _compression_fingerprint(text: str) -> str:
    stripped = COMPRESSION_FILLER_RE.sub("", unicodedata.normalize("NFKC", str(text)).casefold())
    return re.sub(r"[^\w]+", "", stripped, flags=re.UNICODE)


def _compression_similarity(a: str, b: str) -> float:
    a_fp = _compression_fingerprint(a)
    b_fp = _compression_fingerprint(b)
    if not a_fp or not b_fp:
        return 0.0
    if a_fp == b_fp:
        return 1.0
    if min(len(a_fp), len(b_fp)) < 3:
        return 0.0
    if a_fp in b_fp or b_fp in a_fp:
        return min(len(a_fp), len(b_fp)) / max(len(a_fp), len(b_fp))
    return SequenceMatcher(None, a_fp, b_fp, autojunk=False).ratio()


def _has_protected_transaction_term(text: str) -> bool:
    return any(term in str(text) for term in PROTECTED_TRANSACTION_TERMS)


def _build_surface_repeat_runs(doc: dict[str, Any], threshold: float = 0.82, max_gap_ms: int = 1800) -> dict[str, dict[str, Any]]:
    """Annotate only adjacent, high-similarity surface repetitions; never deletes source cues."""
    rows = doc.get("entries", [])
    result: dict[str, dict[str, Any]] = {}
    run_no = 0
    current: list[dict[str, Any]] = []

    def flush() -> None:
        nonlocal run_no, current
        if len(current) >= 2:
            run_no += 1
            run_id = f"surface_repeat_{run_no}"
            for e in current:
                result[e["source_key"]] = {"surface_repeat_group": run_id, "surface_repeat_group_size": len(current)}
        current = []

    for entry in rows:
        if not current:
            current = [entry]
            continue
        prev = current[-1]
        gap = entry["start_ms"] - prev["end_ms"]
        flags_a = mechanical_surface_flags(prev["original_text"])
        flags_b = mechanical_surface_flags(entry["original_text"])
        similarity = _surface_similarity(prev["original_text"], entry["original_text"])
        eligible = (
            gap <= max_gap_ms
            and similarity >= threshold
            and not flags_a["question_like"]
            and not flags_b["question_like"]
        )
        if eligible:
            current.append(entry)
        else:
            flush()
            current = [entry]
    flush()
    return result


def build_compact_intermediate(
    doc: dict[str, Any],
    source_keys: list[str] | None = None,
) -> dict[str, Any]:
    """Build a compact model-facing cue table without changing source semantics.

    R5 adds surface-only question/context and adjacent repetition hints. They are
    review aids, not automatic semantic labels or deletion decisions.
    """
    source_filter = set(source_keys) if source_keys is not None else None
    candidates = detect_critical_numeric_candidates(doc)
    categories_by_key: dict[str, list[str]] = {}
    for row in candidates:
        categories_by_key.setdefault(row["source_key"], []).append(row["category"])
    fingerprints = [normalize_text_fingerprint(e["original_text"]) for e in doc["entries"]]
    counts = Counter(fp for fp in fingerprints if fp)
    repeat_hints = _build_surface_repeat_runs(doc)
    rows = []
    for pos, entry in enumerate(doc["entries"]):
        if source_filter is not None and entry["source_key"] not in source_filter:
            continue
        prev_entry = doc["entries"][pos - 1] if pos > 0 else None
        next_entry = doc["entries"][pos + 1] if pos + 1 < len(doc["entries"]) else None
        fp = fingerprints[pos]
        flags = mechanical_surface_flags(entry["original_text"])
        repeat = repeat_hints.get(entry["source_key"], {})
        rows.append({
            "source_key": entry["source_key"],
            "index": entry["index"],
            "index_raw": entry["index_raw"],
            "block_ordinal": entry["block_ordinal"],
            "start_ms": entry["start_ms"],
            "end_ms": entry["end_ms"],
            "start_raw": entry["start_raw"],
            "end_raw": entry["end_raw"],
            "text": entry["original_text"],
            "gap_before_ms": None if prev_entry is None else entry["start_ms"] - prev_entry["end_ms"],
            "gap_after_ms": None if next_entry is None else next_entry["start_ms"] - entry["end_ms"],
            "text_fingerprint": fp,
            "exact_duplicate_count": counts.get(fp, 0) if fp else 0,
            "critical_numeric_categories": sorted(categories_by_key.get(entry["source_key"], [])),
            **flags,
            "context_dependency_hint": bool(flags["question_like"] or flags["demonstrative_fragment_like"]),
            "surface_repeat_group": repeat.get("surface_repeat_group"),
            "surface_repeat_group_size": repeat.get("surface_repeat_group_size", 1),
        })
    return {
        "schema": "srt_v3_compact_intermediate_v2",
        "file_id": doc["file_id"],
        "filename": doc["filename"],
        "sha256": doc["sha256"],
        "row_count": len(rows),
        "rows": rows,
    }


def _merge_target_windows(
    target_ordinals: list[int],
    context_before: int,
    context_after: int,
    total_entries: int,
    merge_gap_blocks: int,
) -> list[dict[str, int]]:
    """Build disjoint target windows, then merge only overlapping/nearby expanded windows."""
    if merge_gap_blocks < 0:
        raise ValueError("merge_gap_blocks must be non-negative.")
    raw: list[list[int]] = []
    for ordinal in sorted(set(target_ordinals)):
        if not raw or ordinal - raw[-1][-1] > merge_gap_blocks + 1:
            raw.append([ordinal])
        else:
            raw[-1].append(ordinal)
    expanded = [
        {
            "target_start_block_ordinal": group[0],
            "target_end_block_ordinal": group[-1],
            "slice_start_block_ordinal": max(1, group[0] - context_before),
            "slice_end_block_ordinal": min(total_entries, group[-1] + context_after),
        }
        for group in raw
    ]
    merged: list[dict[str, int]] = []
    for win in expanded:
        if not merged or win["slice_start_block_ordinal"] > merged[-1]["slice_end_block_ordinal"] + 1:
            merged.append(dict(win))
        else:
            merged[-1]["target_end_block_ordinal"] = max(
                merged[-1]["target_end_block_ordinal"], win["target_end_block_ordinal"]
            )
            merged[-1]["slice_end_block_ordinal"] = max(
                merged[-1]["slice_end_block_ordinal"], win["slice_end_block_ordinal"]
            )
    return merged


def build_target_slice(
    doc: dict[str, Any],
    target_source_keys: list[str],
    context_before: int = 1,
    context_after: int = 1,
    merge_gap_blocks: int = 2,
) -> dict[str, Any]:
    """Return multi-window target regions plus bounded context.

    Unlike R4, disjoint target regions are not expanded into one large continuous
    min-to-max slice. This keeps unrelated middle sections out of deep review.
    """
    if context_before < 0 or context_after < 0:
        raise ValueError("Context sizes must be non-negative.")
    by_key = _source_entries_by_key(doc)
    missing = [key for key in target_source_keys if key not in by_key]
    if missing:
        raise KeyError(f"Unknown target source_key(s): {missing[:3]}")
    target_ordinals = sorted({by_key[key]["block_ordinal"] for key in target_source_keys})
    if not target_ordinals:
        raise ValueError("At least one target source_key is required.")
    windows = _merge_target_windows(
        target_ordinals, context_before, context_after, len(doc["entries"]), merge_gap_blocks
    )
    target_set = set(target_source_keys)
    slice_keys: list[str] = []
    window_rows: list[dict[str, Any]] = []
    for no, win in enumerate(windows, start=1):
        keys = [
            e["source_key"] for e in doc["entries"]
            if win["slice_start_block_ordinal"] <= e["block_ordinal"] <= win["slice_end_block_ordinal"]
        ]
        targets = [key for key in keys if key in target_set]
        slice_keys.extend(keys)
        window_rows.append({"window_no": no, **win, "target_source_keys": targets, "slice_source_keys": keys})
    # Expanded windows are disjoint after merging, but preserve order and uniqueness defensively.
    seen: set[str] = set()
    slice_keys = [key for key in slice_keys if not (key in seen or seen.add(key))]
    compact = build_compact_intermediate(doc, slice_keys)
    return {
        "schema": "srt_v3_target_slice_v2",
        "target_source_keys": list(target_source_keys),
        "context_before": context_before,
        "context_after": context_after,
        "merge_gap_blocks": merge_gap_blocks,
        "window_count": len(window_rows),
        "windows": window_rows,
        "slice_start_block_ordinal": min(w["slice_start_block_ordinal"] for w in window_rows),
        "slice_end_block_ordinal": max(w["slice_end_block_ordinal"] for w in window_rows),
        "slice_source_keys": slice_keys,
        "slice_row_count": len(slice_keys),
        "source_row_count": len(doc["entries"]),
        "reduction_ratio": 1.0 - (len(slice_keys) / len(doc["entries"])) if doc["entries"] else 0.0,
        "compact": compact,
    }


def build_model_review_bundle(
    doc: dict[str, Any],
    target_slice: dict[str, Any] | None = None,
    cue_ref_prefix: str = "",
    batch_id: str | None = None,
    file_slot: str | None = None,
) -> dict[str, Any]:
    """Build a token-lean model payload while keeping source_key mapping internal.

    Only `payload` is intended for the language-model semantic stage. `internal`
    stays tool-side and is required to map returned cue_refs back to canonical
    source_keys. This reduces repeated long identifiers and integer timing fields.
    """
    if target_slice is None:
        source_keys = [e["source_key"] for e in doc["entries"]]
        windows = [{"slice_source_keys": source_keys}]
    else:
        source_keys = list(target_slice.get("slice_source_keys", []))
        windows = list(target_slice.get("windows", [])) or [{"slice_source_keys": source_keys}]
    compact = build_compact_intermediate(doc, source_keys)
    ref_to_source_key: dict[str, str] = {}
    source_key_to_ref: dict[str, str] = {}
    payload_rows = []
    for ordinal, row in enumerate(compact["rows"], start=1):
        ref = f"{cue_ref_prefix}c{ordinal:03d}" if cue_ref_prefix else f"c{ordinal:03d}"
        ref_to_source_key[ref] = row["source_key"]
        source_key_to_ref[row["source_key"]] = ref
        flags = ""
        if row.get("question_like"):
            flags += "q"
        if row.get("context_dependency_hint"):
            flags += "d"
        if row.get("surface_repeat_group"):
            flags += "r"
        packed = {
            "r": ref,
            "i": row["index_raw"],
            "x": row["text"],
        }
        if flags:
            packed["f"] = flags
        if row.get("critical_numeric_categories"):
            packed["n"] = row["critical_numeric_categories"]
        payload_rows.append(packed)
    window_refs = []
    for window in windows:
        keys = [key for key in window.get("slice_source_keys", []) if key in source_key_to_ref]
        if keys:
            window_refs.append([source_key_to_ref[keys[0]], source_key_to_ref[keys[-1]]])
    identity = {
        "workflow_version": "V3.0",
        "support_package_revision": SUPPORT_PACKAGE_REVISION,
        "file_id": doc.get("file_id"),
        "filename": doc.get("filename"),
        "sha256": doc.get("sha256"),
        "ordered_source_keys": source_keys,
        "batch_id": batch_id,
        "file_slot": file_slot,
    }
    bundle_id = hashlib.sha256(
        json.dumps(identity, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    return {
        "schema": "srt_v3_model_review_bundle_v2",
        "payload": {
            "b": bundle_id,
            "rows": payload_rows,
            "w": window_refs,
        },
        "internal": {
            "bundle_id": bundle_id,
            "file_id": doc.get("file_id"),
            "filename": doc.get("filename"),
            "sha256": doc.get("sha256"),
            "batch_id": batch_id,
            "file_slot": file_slot,
            "ref_to_source_key": ref_to_source_key,
            "source_key_to_ref": source_key_to_ref,
        },
    }


def resolve_model_cue_refs(
    doc: dict[str, Any],
    bundle: dict[str, Any],
    cue_refs: list[str],
    bundle_id: str | None = None,
) -> list[str]:
    """Map model-returned short cue_refs back to canonical source_keys safely."""
    internal = bundle.get("internal", {})
    payload = bundle.get("payload", {})
    expected_bundle_id = internal.get("bundle_id")
    observed_bundle_id = bundle_id if bundle_id is not None else payload.get("b")
    if not expected_bundle_id or observed_bundle_id != expected_bundle_id:
        raise ValueError("Model review bundle identity mismatch.")
    if (
        internal.get("file_id") != doc.get("file_id")
        or internal.get("filename") != doc.get("filename")
        or internal.get("sha256") != doc.get("sha256")
    ):
        raise ValueError("Model review bundle does not match the current canonical document.")
    ref_map = internal.get("ref_to_source_key", {})
    missing = [ref for ref in cue_refs if ref not in ref_map]
    if missing:
        raise KeyError(f"Unknown model cue_ref(s): {missing[:3]}")
    source_keys = [ref_map[ref] for ref in cue_refs]
    by_key = _source_entries_by_key(doc)
    if any(key not in by_key for key in source_keys):
        raise ValueError("Model cue_ref resolved outside the canonical source index.")
    return source_keys


def resolve_candidate_cue_refs(
    doc: dict[str, Any],
    bundle: dict[str, Any],
    candidates: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Convert model candidate cue_refs to source_keys before deterministic compression."""
    resolved = []
    for row in candidates:
        copied = dict(row)
        refs = list(copied.pop("cue_refs", []))
        if refs:
            copied["source_keys"] = resolve_model_cue_refs(
                doc, bundle, refs, bundle_id=str(bundle.get("payload", {}).get("b") or "")
            )
        resolved.append(copied)
    return resolved


def create_task_state(doc: dict[str, Any]) -> dict[str, Any]:
    """Create a serializable session state so confirmed-product turns can resume without reparse."""
    source_keys = [e["source_key"] for e in doc["entries"]]
    canonical_digest = hashlib.sha256("\n".join(source_keys).encode("utf-8")).hexdigest()
    return {
        "schema": "srt_v3_task_state_v2",
        "workflow_version": "V3.0",
        "support_package_revision": SUPPORT_PACKAGE_REVISION,
        "file_id": doc["file_id"],
        "filename": doc["filename"],
        "sha256": doc["sha256"],
        "canonical_entry_count": len(source_keys),
        "canonical_source_keys_digest": canonical_digest,
        "phase": "parsed",
        "target_product": None,
        "target_source_keys": [],
        "target_slice": None,
        "verified_manifest_id": None,
    }


def _validate_task_state_identity(state: dict[str, Any], doc: dict[str, Any]) -> None:
    source_keys = [e["source_key"] for e in doc["entries"]]
    digest = hashlib.sha256("\n".join(source_keys).encode("utf-8")).hexdigest()
    checks = (
        state.get("sha256") == doc.get("sha256"),
        state.get("file_id") == doc.get("file_id"),
        state.get("filename") == doc.get("filename"),
        state.get("canonical_entry_count") == len(source_keys),
        state.get("canonical_source_keys_digest") == digest,
    )
    if not all(checks):
        raise ValueError("Task state does not match the current canonical SRT document.")


def set_task_state_target(
    state: dict[str, Any],
    doc: dict[str, Any],
    target_product: str,
    target_source_keys: list[str],
    context_before: int = 1,
    context_after: int = 1,
    merge_gap_blocks: int = 2,
) -> dict[str, Any]:
    """Advance state after product confirmation, validating full canonical identity."""
    _validate_task_state_identity(state, doc)
    if not str(target_product).strip():
        raise ValueError("target_product must be non-empty.")
    target_slice = build_target_slice(
        doc, target_source_keys, context_before, context_after, merge_gap_blocks
    )
    updated = dict(state)
    updated.update({
        "phase": "target_confirmed",
        "target_product": str(target_product).strip(),
        "target_source_keys": list(target_source_keys),
        "target_slice": target_slice,
    })
    return updated


def _candidate_surface_profile(row: dict[str, Any], by_key: dict[str, dict[str, Any]]) -> dict[str, Any]:
    entries = [by_key[key] for key in row.get("source_keys", []) if key in by_key]
    text = " ".join(e["original_text"] for e in entries)
    flags = [mechanical_surface_flags(e["original_text"]) for e in entries]
    numbers = re.findall(r"\d+(?:\.\d+)?", text)
    return {
        "text": text,
        "fingerprint": normalize_text_fingerprint(text),
        "numbers": numbers,
        "question_like": any(x["question_like"] for x in flags),
        "context_dependency_hint": any(x["question_like"] or x["demonstrative_fragment_like"] for x in flags),
        "critical_numeric": bool(re.search(r"\d", text)),
        "protected_transaction_term": _has_protected_transaction_term(text),
    }


def compress_candidate_pool(
    candidates: list[dict[str, Any]],
    per_cluster_limit: int = 3,
    opening_limit: int = 5,
    ending_limit: int = 5,
    doc: dict[str, Any] | None = None,
    near_duplicate_threshold: float = 0.88,
) -> dict[str, Any]:
    """Mechanically bound an already-ranked assistant candidate pool.

    R5 may drop a surface-near-duplicate only inside the same assistant-authored
    semantic_cluster + role, with no conflicting numeric surface. Questions/context
    fragments are flagged for review, never auto-deleted for being questions.
    """
    if per_cluster_limit < 1 or opening_limit < 1 or ending_limit < 1:
        raise ValueError("Candidate limits must be positive.")
    if not 0.0 <= near_duplicate_threshold <= 1.0:
        raise ValueError("near_duplicate_threshold must be between 0 and 1.")
    kept: list[dict[str, Any]] = []
    dropped: list[dict[str, Any]] = []
    cluster_counts: Counter[str] = Counter()
    role_counts: Counter[str] = Counter()
    seen_source_sets: set[tuple[str, ...]] = set()
    by_key = _source_entries_by_key(doc) if doc is not None else {}
    profiles: dict[str, dict[str, Any]] = {}

    def is_protected(row: dict[str, Any]) -> bool:
        return bool(
            row.get("compression_exempt")
            or row.get("unique_fact")
            or row.get("unique_purchase_action")
            or row.get("required_context")
        )

    for original_row in candidates:
        row = dict(original_row)
        keys = tuple(str(x) for x in row.get("source_keys", []))
        if keys and keys in seen_source_sets:
            dropped.append({"candidate_id": row.get("candidate_id"), "reason": "exact_source_duplicate"})
            continue
        cluster = str(row.get("semantic_cluster") or row.get("cluster_key") or row.get("role") or "unclustered")
        role = str(row.get("role") or "other")
        role_limit = opening_limit if role == "opening_hook" else ending_limit if role == "ending_close" else None
        profile = _candidate_surface_profile(row, by_key) if doc is not None else None
        if profile is not None:
            row["mechanical_flags"] = {
                "question_like": profile["question_like"],
                "context_dependency_hint": profile["context_dependency_hint"],
            }
            if (
                not is_protected(row)
                and not profile["question_like"]
                and not profile["critical_numeric"]
                and not profile["protected_transaction_term"]
            ):
                for kept_row in kept:
                    if str(kept_row.get("semantic_cluster") or kept_row.get("cluster_key") or kept_row.get("role") or "unclustered") != cluster:
                        continue
                    if str(kept_row.get("role") or "other") != role:
                        continue
                    kept_id = str(kept_row.get("candidate_id"))
                    kept_profile = profiles.get(kept_id)
                    if (
                        not kept_profile
                        or kept_profile["question_like"]
                        or kept_profile["critical_numeric"]
                        or kept_profile["protected_transaction_term"]
                    ):
                        continue
                    if profile["numbers"] != kept_profile["numbers"]:
                        continue
                    similarity = _compression_similarity(profile["text"], kept_profile["text"])
                    if similarity >= near_duplicate_threshold:
                        dropped.append({
                            "candidate_id": row.get("candidate_id"),
                            "reason": "surface_near_duplicate",
                            "similar_to": kept_row.get("candidate_id"),
                            "similarity": round(similarity, 4),
                        })
                        break
                else:
                    pass
                if dropped and dropped[-1].get("candidate_id") == row.get("candidate_id") and dropped[-1].get("reason") == "surface_near_duplicate":
                    continue
        protected = is_protected(row)
        if not protected and cluster_counts[cluster] >= per_cluster_limit:
            dropped.append({"candidate_id": row.get("candidate_id"), "reason": "cluster_limit"})
            continue
        if not protected and role_limit is not None and role_counts[role] >= role_limit:
            dropped.append({"candidate_id": row.get("candidate_id"), "reason": "role_limit"})
            continue
        kept.append(row)
        cluster_counts[cluster] += 1
        role_counts[role] += 1
        if keys:
            seen_source_sets.add(keys)
        if profile is not None:
            profiles[str(row.get("candidate_id"))] = profile
    return {
        "schema": "srt_v3_candidate_compression_v2",
        "input_count": len(candidates),
        "kept_count": len(kept),
        "dropped_count": len(dropped),
        "kept": kept,
        "dropped": dropped,
        "limits": {
            "per_cluster": per_cluster_limit,
            "opening": opening_limit,
            "ending": ending_limit,
            "near_duplicate_threshold": near_duplicate_threshold,
        },
    }

def validate_critical_claim_reviews(
    doc: dict[str, Any],
    plan: dict[str, Any],
    reviews: list[dict[str, Any]],
) -> dict[str, Any]:
    """Require explicit human review for every detected critical numeric cue used in the edit."""
    errors: list[str] = []
    candidates = detect_critical_numeric_candidates(doc)
    candidate_map = {(c["source_index"], c["category"]): c for c in candidates}
    selected_indices = set(plan["selected_indices_in_playback_order"])
    required = {key for key in candidate_map if key[0] in selected_indices}
    review_map: dict[tuple[int, str], dict[str, Any]] = {}
    allowed_decisions = {"clear", "verbatim_only", "exclude", "conflict"}
    for row in reviews:
        try:
            key = (int(row.get("source_index")), str(row.get("category", "")))
        except (TypeError, ValueError):
            errors.append("Critical-claim review has an invalid source_index.")
            continue
        if key not in candidate_map:
            errors.append(f"Critical-claim review points to an unknown candidate: {key}.")
            continue
        if key in review_map:
            errors.append(f"Duplicate critical-claim review: {key}.")
            continue
        review_map[key] = row
        candidate = candidate_map[key]
        entry = _entry_for_index(doc, key[0])
        if row.get("raw_text") != entry["original_text"]:
            errors.append(f"Critical-claim review raw_text mismatch at source cue {key[0]}.")
        decision = row.get("decision")
        if decision not in allowed_decisions:
            errors.append(f"Critical-claim review has invalid decision at source cue {key[0]}.")
            continue
        if not str(row.get("reason", "")).strip():
            errors.append(f"Critical-claim review needs a reason at source cue {key[0]}.")
        use_as_fact = row.get("use_as_fact")
        if not isinstance(use_as_fact, bool):
            errors.append(f"Critical-claim review needs boolean use_as_fact at source cue {key[0]}.")
        if candidate["risk"].startswith("ambiguous") and decision == "clear":
            errors.append(f"Ambiguous numeric cue cannot be cleared without an explicit unit at source cue {key[0]}.")
        if decision != "clear" and use_as_fact is True:
            errors.append(f"Non-clear numeric cue cannot be used as a factual claim at source cue {key[0]}.")
        if decision in {"exclude", "conflict"} and key[0] in selected_indices:
            errors.append(f"Excluded/conflicting numeric cue is still selected at source cue {key[0]}.")
        if decision == "verbatim_only" and key[0] in selected_indices:
            if not str(row.get("warning", "")).strip():
                errors.append(f"Verbatim-only numeric cue needs a warning at source cue {key[0]}.")
            if row.get("normalized_value") not in (None, ""):
                errors.append(f"Verbatim-only numeric cue cannot have a normalized_value at source cue {key[0]}.")
    missing = sorted(required - set(review_map))
    for source_index, category in missing:
        errors.append(f"Selected critical numeric cue lacks review: source cue {source_index} ({category}).")
    return {
        "detected_candidate_count": len(candidates),
        "selected_candidate_count": len(required),
        "reviewed_candidate_count": len(required - set(missing)),
        "missing_reviews": [{"source_index": i, "category": c} for i, c in missing],
        "errors": errors,
        "all_pass": not errors,
        "method": "heuristic candidate detection plus explicit human review; not an automatic fact verifier",
    }


def validate_candidate_competition(
    doc: dict[str, Any],
    role: str,
    candidates: list[dict[str, Any]],
    selected_candidate_id: str | None = None,
    no_selection_reason: str | None = None,
) -> dict[str, Any]:
    """Validate a human-authored opening/ending comparison without scoring semantics in code."""
    errors: list[str] = []
    if role not in {"opening_hook", "ending_close"}:
        errors.append(f"Unsupported candidate competition role: {role}.")
    if not candidates:
        errors.append(f"{role}: candidate pool is empty.")
    ids: set[str] = set()
    selected_rows = []
    common_enums = {
        "standalone_intelligibility": {"yes", "partial", "no"},
        "product_anchor": {"clear", "contextual", "unclear"},
        "transition_fit": {"strong", "medium", "weak"},
        "context_dependency": {"low", "medium", "high"},
    }
    for row in candidates:
        cid = str(row.get("candidate_id", ""))
        if not cid or cid in ids:
            errors.append(f"{role}: missing or duplicate candidate_id {cid!r}.")
        ids.add(cid)
        indices = row.get("source_indices")
        if not isinstance(indices, list) or not indices:
            errors.append(f"{role}/{cid}: source_indices must be a non-empty list.")
            indices = []
        entries = []
        try:
            entries = [_entry_for_index(doc, int(i)) for i in indices]
        except (KeyError, ValueError, TypeError) as exc:
            errors.append(f"{role}/{cid}: invalid source mapping ({exc}).")
        if entries:
            ordinals = [e["block_ordinal"] for e in entries]
            if ordinals != sorted(ordinals) or any(b != a + 1 for a, b in zip(ordinals, ordinals[1:])):
                errors.append(f"{role}/{cid}: candidate source cues must be a contiguous source block.")
        for field, allowed in common_enums.items():
            if row.get(field) not in allowed:
                errors.append(f"{role}/{cid}: invalid or missing {field}.")
        if not str(row.get("decision_reason", "")).strip():
            errors.append(f"{role}/{cid}: decision_reason is required.")
        decision = row.get("decision")
        if decision not in {"selected", "rejected"}:
            errors.append(f"{role}/{cid}: decision must be selected or rejected.")
        if decision == "selected":
            selected_rows.append(row)
            if role == "opening_hook":
                if row.get("standalone_intelligibility") != "yes":
                    errors.append(f"{role}/{cid}: selected opening must be independently intelligible.")
                if row.get("product_anchor") == "unclear":
                    errors.append(f"{role}/{cid}: selected opening must anchor the target product.")
                if row.get("transition_fit") == "weak" or row.get("context_dependency") == "high":
                    errors.append(f"{role}/{cid}: selected opening has weak transition or excessive context dependency.")
            elif role == "ending_close":
                if row.get("purchase_action") not in {"explicit", "soft"}:
                    errors.append(f"{role}/{cid}: selected ending needs a reliable purchase action.")
                if row.get("natural_close") not in {"strong", "medium"}:
                    errors.append(f"{role}/{cid}: selected ending is not a natural close.")
                if row.get("product_anchor") == "unclear" or row.get("context_dependency") == "high":
                    errors.append(f"{role}/{cid}: selected ending lacks a reliable product anchor or depends too heavily on context.")
                if row.get("transaction_info") not in {"reliable", "partial", "uncertain", "not_applicable"}:
                    errors.append(f"{role}/{cid}: transaction_info is required.")
    if selected_candidate_id:
        matches = [row for row in candidates if row.get("candidate_id") == selected_candidate_id]
        if len(matches) != 1 or len(selected_rows) != 1 or selected_rows[0].get("candidate_id") != selected_candidate_id:
            errors.append(f"{role}: selected_candidate_id must identify the sole selected candidate.")
        if no_selection_reason:
            errors.append(f"{role}: no_selection_reason must be empty when a candidate is selected.")
    else:
        if selected_rows:
            errors.append(f"{role}: a selected candidate exists but selected_candidate_id is missing.")
        if not str(no_selection_reason or "").strip():
            errors.append(f"{role}: explain why no candidate was selected.")
    return {
        "role": role,
        "candidate_count": len(candidates),
        "selected_candidate_id": selected_candidate_id,
        "selected_count": len(selected_rows),
        "errors": errors,
        "all_pass": not errors,
        "semantic_method": "human semantic comparison; Python validates review completeness and hard constraints only",
    }


def validate_final_composition_review(
    doc: dict[str, Any],
    plan: dict[str, Any],
    review: dict[str, Any],
) -> dict[str, Any]:
    """Require a documented whole-edit read-through and a contribution reason for every segment."""
    errors: list[str] = []
    required_flags = (
        "price_placement_reviewed",
        "product_boundary_reviewed",
        "continuity_reviewed",
        "duplication_reviewed",
        "marginal_contribution_reviewed",
        "final_readthrough_completed",
        "final_readthrough_passed",
    )
    for field in required_flags:
        if review.get(field) is not True:
            errors.append(f"Final composition review requires {field}=true.")
    if review.get("overall_decision") != "pass":
        errors.append("Final composition review overall_decision must be pass.")
    contribution_types = {
        "new_information", "distinct_evidence", "context_required",
        "transaction_closure", "audience_relevance",
    }
    rows = review.get("segment_contributions", [])
    by_group: dict[int, dict[str, Any]] = {}
    for row in rows:
        try:
            group_no = int(row.get("group_no"))
        except (TypeError, ValueError):
            errors.append("Segment contribution has an invalid group_no.")
            continue
        if group_no in by_group:
            errors.append(f"Duplicate segment contribution for group {group_no}.")
        by_group[group_no] = row
    expected_group_nos = {int(g["group_no"]) for g in plan["groups"]}
    if set(by_group) != expected_group_nos:
        errors.append("Segment contribution records must cover every final group exactly once.")
    for group in plan["groups"]:
        group_no = int(group["group_no"])
        row = by_group.get(group_no)
        if not row:
            continue
        if row.get("source_indices") != group["indices"]:
            errors.append(f"Segment contribution source indices mismatch for group {group_no}.")
        if row.get("contribution_type") not in contribution_types:
            errors.append(f"Segment {group_no} has no valid independent contribution type.")
        if not str(row.get("reason", "")).strip():
            errors.append(f"Segment {group_no} needs a marginal-contribution reason.")
    return {
        "group_count": len(plan["groups"]),
        "reviewed_group_count": len(set(by_group) & expected_group_nos),
        "errors": errors,
        "all_pass": not errors,
    }


def validate_conversion_flow_review(
    plan: dict[str, Any],
    review: dict[str, Any],
) -> dict[str, Any]:
    """Validate a compact assistant-authored conversion-flow review.

    This does not infer sales quality. It only ensures the single semantic pass
    documented hook payoff, per-segment conversion roles, marginal value,
    adjacent-flow quality, and terminal CTA placement without adding another
    SRT scan.
    """
    errors: list[str] = []
    groups = plan.get("groups", [])
    expected = [int(g["group_no"]) for g in groups]
    valid_roles = {
        "hook", "hook_payoff", "core_value", "evidence", "fit_or_scenario",
        "objection_resolution", "transaction_reason", "cta", "context_required",
    }
    valid_delta = {"high", "medium", "required"}
    valid_fit = {"strong", "medium", "na"}

    rows = review.get("segments", [])
    by_group: dict[int, dict[str, Any]] = {}
    for row in rows:
        try:
            group_no = int(row.get("group_no"))
        except (TypeError, ValueError):
            errors.append("Conversion-flow segment has invalid group_no.")
            continue
        if group_no in by_group:
            errors.append(f"Duplicate conversion-flow segment for group {group_no}.")
        by_group[group_no] = row
    if set(by_group) != set(expected):
        errors.append("Conversion-flow review must cover every final group exactly once.")

    for pos, group_no in enumerate(expected):
        row = by_group.get(group_no)
        if not row:
            continue
        if row.get("role") not in valid_roles:
            errors.append(f"Conversion-flow group {group_no} has invalid role.")
        if row.get("value_delta") not in valid_delta:
            errors.append(f"Conversion-flow group {group_no} lacks positive marginal value.")
        expected_fit = "na" if pos == len(expected) - 1 else None
        fit = row.get("next_fit")
        if expected_fit == "na":
            if fit != "na":
                errors.append(f"Final conversion-flow group {group_no} must use next_fit=na.")
        elif fit not in {"strong", "medium"}:
            errors.append(f"Conversion-flow group {group_no} must connect to the next group without a weak edge.")

    opening = review.get("opening", {})
    if opening.get("audience_fit") not in {"strong", "medium"}:
        errors.append("Conversion-flow opening requires strong/medium audience_fit.")
    if opening.get("value_promise") not in {"clear", "partial"}:
        errors.append("Conversion-flow opening requires a clear/partial value_promise.")
    try:
        payoff_group_no = int(opening.get("payoff_group_no"))
    except (TypeError, ValueError):
        payoff_group_no = -1
        errors.append("Conversion-flow opening requires payoff_group_no.")
    if payoff_group_no not in set(expected[:3]):
        errors.append("Hook payoff must occur within the first three final groups.")
    if opening.get("payoff_strength") not in {"strong", "medium"}:
        errors.append("Hook payoff must be strong/medium.")

    cta = review.get("cta", {})
    cta_group_no = cta.get("group_no")
    if cta_group_no is not None:
        try:
            cta_group_no = int(cta_group_no)
        except (TypeError, ValueError):
            errors.append("CTA group_no is invalid.")
            cta_group_no = None
        if expected and cta_group_no != expected[-1]:
            errors.append("CTA must be the terminal final group when present.")
        if cta.get("terminal") is not True:
            errors.append("CTA terminal rule must be explicitly confirmed.")
    elif cta.get("reason") in (None, ""):
        errors.append("If no CTA exists, explain why no reliable CTA was available.")

    if review.get("overall_decision") != "pass":
        errors.append("Conversion-flow overall_decision must be pass.")
    return {
        "group_count": len(expected),
        "reviewed_group_count": len(set(by_group) & set(expected)),
        "payoff_group_no": payoff_group_no,
        "cta_group_no": cta_group_no,
        "errors": errors,
        "all_pass": not errors,
        "semantic_method": "assistant-authored compact conversion-flow review; no extra SRT scan",
    }


def validate_semantic_review(
    doc: dict[str, Any],
    plan: dict[str, Any],
    review: dict[str, Any],
) -> dict[str, Any]:
    opening = review.get("opening_competition", {})
    ending = review.get("ending_competition", {})
    opening_result = validate_candidate_competition(
        doc, "opening_hook", opening.get("candidates", []),
        opening.get("selected_candidate_id"), opening.get("no_selection_reason"),
    )
    ending_result = validate_candidate_competition(
        doc, "ending_close", ending.get("candidates", []),
        ending.get("selected_candidate_id"), ending.get("no_selection_reason"),
    )
    claims_result = validate_critical_claim_reviews(
        doc, plan, review.get("critical_claim_reviews", []),
    )
    composition_result = validate_final_composition_review(
        doc, plan, review.get("composition_review", {}),
    )
    conversion_result = None
    if "conversion_flow" in review:
        conversion_result = validate_conversion_flow_review(plan, review.get("conversion_flow", {}))
    errors = []
    result_rows = [
        ("opening_competition", opening_result),
        ("ending_competition", ending_result),
        ("critical_claim_reviews", claims_result),
        ("composition_review", composition_result),
    ]
    if conversion_result is not None:
        result_rows.append(("conversion_flow", conversion_result))
    for label, result in result_rows:
        errors.extend(f"{label}: {error}" for error in result["errors"])
    return {
        "opening_competition": opening_result,
        "ending_competition": ending_result,
        "critical_claim_reviews": claims_result,
        "composition_review": composition_result,
        "conversion_flow": conversion_result,
        "errors": errors,
        "all_pass": not errors,
        "semantic_method": "assistant-authored single-pass semantic + conversion review with Python provenance/completeness validation",
    }


def build_delivery_sequence_contract(doc: dict[str, Any], plan: dict[str, Any]) -> dict[str, Any]:
    """Compatibility wrapper over the single Final-Gate verified manifest."""
    manifest = build_verified_manifest(doc, plan)
    return {
        "selected_count": manifest["selected_count"],
        "serial_count": manifest["serial_count"],
        "group_count": manifest["group_count"],
        "serials": manifest["serials"],
        "copy_button_payload": manifest["copy_button_payload"],
        "code_block_payload": manifest["code_block_payload"],
        "absolute_final_line": manifest["absolute_final_line"],
        "count_consistent": manifest["count_consistent"],
        "serials_consistent": manifest["serials_consistent"],
        "copy_payloads_consistent": manifest["copy_payloads_consistent"],
        "source_verification": manifest["verification"],
        "verified_manifest_id": manifest["manifest_id"],
        "all_pass": manifest["all_pass"],
    }

FIVE_SECTION_HEADINGS = [
    "一、文件解析结果",
    "二、商品识别",
    "三、最佳成片方案",
    "四、作品标题与话题",
    "五、原始SRT序号（按成片播放顺序）",
]

# This order and the templates below are an embedded machine-readable copy of
# the approved V3.0 frozen delivery contract. Daily runs do not need a second
# Drive read of the audit contract; the audit document remains authoritative
# for change control and this embedded hash detects accidental code drift.
THIRD_SECTION_FIELD_ORDER = [
    "片段序号/片段功能",
    "预计成片时间轴",
    "原SRT起止时间",
    "源序号",
    "本组未覆盖间隔",
    "SRT源字幕定位",
    "完整原始字幕文本",
]
FROZEN_FORMAT_CONTRACT_VERSION = "V3.0_LOCKED_20261031"
FROZEN_THIRD_SECTION_HEADING = "三、最佳成片方案"
FROZEN_THIRD_SECTION_THEME_TEMPLATE = "主推主题：{theme}"
FROZEN_THIRD_SECTION_DURATION_TEMPLATE = "预计成片时长：{duration}"
FROZEN_THIRD_SECTION_METADATA_TEMPLATE = (
    "片段{n}｜{function}｜预计成片 {timeline}｜原SRT {source}｜"
    "源序号 {serials}｜本组未覆盖间隔 {uncovered}｜SRT源字幕定位"
)
FROZEN_THIRD_SECTION_SOURCE_LINE_TEMPLATE = "{index_raw} | {start_raw} --> {end_raw} | {text}"
FROZEN_FIFTH_SECTION_HEADING = "五、原始SRT序号（按成片播放顺序）"
FROZEN_SERIAL_DELIMITER = ","


def _embedded_format_contract_payload() -> str:
    payload = {
        "version": FROZEN_FORMAT_CONTRACT_VERSION,
        "headings": FIVE_SECTION_HEADINGS,
        "third_field_order": THIRD_SECTION_FIELD_ORDER,
        "third_heading": FROZEN_THIRD_SECTION_HEADING,
        "third_theme": FROZEN_THIRD_SECTION_THEME_TEMPLATE,
        "third_duration": FROZEN_THIRD_SECTION_DURATION_TEMPLATE,
        "third_metadata": FROZEN_THIRD_SECTION_METADATA_TEMPLATE,
        "third_source_line": FROZEN_THIRD_SECTION_SOURCE_LINE_TEMPLATE,
        "fifth_heading": FROZEN_FIFTH_SECTION_HEADING,
        "serial_delimiter": FROZEN_SERIAL_DELIMITER,
    }
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


# Updated only when the approved V3.0 frozen contract itself changes.
FROZEN_FORMAT_CONTRACT_SHA256 = "25c49cac6254299842351c8f4e668a561e2da531e77e4e8a2d7c9d26f392973c"


def validate_embedded_format_contract() -> bool:
    actual = hashlib.sha256(_embedded_format_contract_payload().encode("utf-8")).hexdigest()
    return actual == FROZEN_FORMAT_CONTRACT_SHA256

def _compress_source_serials(tokens: list[str]) -> str:
    """Compress consecutive serials while preserving source order and zero padding."""
    if not tokens:
        return ""
    out = []
    i = 0
    while i < len(tokens):
        j = i
        start_value = int(tokens[i])
        width = len(tokens[i])
        while j + 1 < len(tokens):
            next_value = int(tokens[j + 1])
            next_width = len(tokens[j + 1])
            if next_value == int(tokens[j]) + 1 and next_width == width:
                j += 1
            else:
                break
        if j > i:
            out.append(f"{tokens[i]}–{tokens[j]}")
        else:
            out.append(tokens[i])
        i = j + 1
    return ",".join(out)

def render_third_section(
    doc: dict[str, Any],
    plan: dict[str, Any],
    theme: str,
    segment_functions: list[str],
    subtitle_note: str | None = None,
    verified_manifest: dict[str, Any] | None = None,
) -> str:
    """Render the immutable approved Part Three structure from the verified source index."""
    if len(segment_functions) != len(plan["groups"]):
        raise ValueError("One segment function is required for each clip group.")
    if not validate_embedded_format_contract():
        raise ValueError("Embedded frozen format contract hash mismatch; audit contract re-read is required.")
    if verified_manifest is None:
        verified_manifest = build_verified_manifest(doc, plan)
    else:
        validate_verified_manifest_for_render(doc, plan, verified_manifest)
    if not verified_manifest["all_pass"]:
        raise ValueError("Part Three rendering is blocked because source/count/copy contract verification failed.")
    if not theme.strip() or any(not str(label).strip() for label in segment_functions):
        raise ValueError("Theme and segment functions must be non-empty.")

    total_ms = verified_manifest["total_planned_span_ms"]
    lines = [
        FROZEN_THIRD_SECTION_HEADING,
        FROZEN_THIRD_SECTION_THEME_TEMPLATE.format(theme=theme),
        FROZEN_THIRD_SECTION_DURATION_TEMPLATE.format(duration=format_ms_dot(total_ms)),
    ]
    for group, function in zip(verified_manifest["groups"], segment_functions):
        source_entries = group["entries"]
        n = group["group_no"]
        timeline = f"{format_ms_dot(group['timeline_start_ms'])}–{format_ms_dot(group['timeline_end_ms'])}"
        source = f"{format_ms_dot(group['source_start_ms'])}–{format_ms_dot(group['source_end_ms'])}"
        serials = _compress_source_serials([e["index_raw"] for e in source_entries])
        uncovered = format_ms_dot(group["uncovered_gap_ms"])
        lines.append(FROZEN_THIRD_SECTION_METADATA_TEMPLATE.format(
            n=n, function=function, timeline=timeline, source=source,
            serials=serials, uncovered=uncovered,
        ))
        for entry in source_entries:
            lines.append(FROZEN_THIRD_SECTION_SOURCE_LINE_TEMPLATE.format(
                index_raw=entry["index_raw"], start_raw=entry["start_raw"],
                end_raw=entry["end_raw"], text=entry["original_text"],
            ))
    if subtitle_note:
        lines.append(f"字幕疑点提醒：{subtitle_note}")
    return "\n".join(lines)

def render_five_part_document(section_bodies: dict[str, str]) -> str:
    """Render a text-level five-part contract preview in the fixed order."""
    if set(section_bodies) != set(FIVE_SECTION_HEADINGS):
        raise ValueError("Exactly the five fixed section bodies must be supplied.")
    return "\n\n".join(
        f"{heading}\n{section_bodies[heading]}" for heading in FIVE_SECTION_HEADINGS
    )

def route_project(trigger: str, filenames: list[str]) -> dict[str, Any]:
    """V3.0 router contract; formal Drive routing is maintained by the V3.0 master and registry."""
    normalized = trigger.strip()
    if normalized == "srt切片文案":
        accepted = [name for name in filenames if Path(name).suffix.lower() == ".srt"]
        ignored = [name for name in filenames if Path(name).suffix.lower() != ".srt"]
        return {
            "route": "srt_v3_active",
            "scope": "pure_srt",
            "accepted_files": accepted,
            "ignored_files": ignored,
            "reads_media": False,
        }
    if normalized == "切片文案":
        return {
            "route": "cut_v5.1",
            "scope": "video_plus_srt",
            "accepted_files": list(filenames),
            "ignored_files": [],
            "reads_media": True,
        }
    return {
        "route": "unknown",
        "scope": "unresolved",
        "accepted_files": [],
        "ignored_files": list(filenames),
        "reads_media": False,
    }

def validate_semantic_gate(manifest: dict[str, Any]) -> dict[str, Any]:
    """Validate manually reviewed semantic-gate records; it does not infer semantics."""
    errors = []
    results = manifest.get("semantic_gate_results", [])
    for row in results:
        classification = row.get("classification")
        blocked = row.get("block_required")
        plan = row.get("draft_plan")
        if classification == "multiple_products":
            if blocked is not True:
                errors.append(f"{row.get('filename')}: multiple products must block.")
            if plan is not None:
                errors.append(f"{row.get('filename')}: blocked file must not contain a draft plan.")
            if not row.get("product_segments"):
                errors.append(f"{row.get('filename')}: blocked file must list product segments.")
        elif classification in ("single_primary_product", "single_primary_product_with_opening_transition"):
            if blocked is not False:
                errors.append(f"{row.get('filename')}: single-product file must not be blocked.")
            if not plan:
                errors.append(f"{row.get('filename')}: single-product file needs a reviewed draft plan.")
            else:
                if int(plan.get("selected_cues", 0)) <= 0 or int(plan.get("groups", 0)) <= 0:
                    errors.append(f"{row.get('filename')}: selected cue/group counts must be positive.")
                if "pass" not in str(plan.get("serial_text_time_verification", "")).lower():
                    errors.append(f"{row.get('filename')}: source mapping verification is not marked pass.")
        else:
            errors.append(f"{row.get('filename')}: unknown or missing classification.")
    return {
        "sample_count": len(results),
        "blocked_count": sum(1 for row in results if row.get("block_required") is True),
        "single_product_count": sum(1 for row in results if row.get("block_required") is False),
        "errors": errors,
        "all_pass": bool(results) and not errors,
        "semantic_method": "manual assistant review recorded as fixture; not an automated classifier",
    }

def assign_document_keys(docs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Avoid silent overwrite when two independent SRTs share a basename or path."""
    name_counts = Counter(doc["filename"] for doc in docs)
    used = set()
    assigned = []
    for ordinal, doc in enumerate(docs, start=1):
        if name_counts[doc["filename"]] == 1:
            key = doc["filename"]
        else:
            path_hash = hashlib.sha256(doc["file_id"].encode("utf-8")).hexdigest()[:10]
            key = f"{doc['filename']}::{path_hash}"
        if key in used:
            key = f"{key}::{ordinal}"
        doc["document_key"] = key
        used.add(key)
        assigned.append(doc)
    return assigned


def _canonical_source_keys_digest(doc: dict[str, Any]) -> str:
    return hashlib.sha256("\n".join(e["source_key"] for e in doc["entries"]).encode("utf-8")).hexdigest()


def _batch_identity_payload(docs: list[dict[str, Any]]) -> dict[str, Any]:
    if any("document_key" not in doc for doc in docs):
        assign_document_keys(docs)
    return {
        "workflow_version": "V3.0",
        "support_package_revision": SUPPORT_PACKAGE_REVISION,
        "ordered_files": [
            {
                "file_slot": f"f{ordinal:02d}",
                "document_key": doc["document_key"],
                "file_id": doc["file_id"],
                "filename": doc["filename"],
                "sha256": doc["sha256"],
                "canonical_entry_count": len(doc["entries"]),
                "canonical_source_keys_digest": _canonical_source_keys_digest(doc),
            }
            for ordinal, doc in enumerate(docs, start=1)
        ],
    }


def _batch_parse_state(doc: dict[str, Any]) -> str:
    d = doc["diagnostics"]
    hard_ok = bool(
        doc.get("entries")
        and d.get("fully_parsed")
        and d.get("index_unique")
        and d.get("time_order_valid")
        and d.get("duration_valid")
    )
    return "PARSED" if hard_ok else "STRUCTURE_WARNING"


def build_batch_manifest(docs: list[dict[str, Any]]) -> dict[str, Any]:
    """Create an internal multi-SRT routing state without merging canonical documents."""
    if not docs:
        raise ValueError("At least one parsed SRT document is required for a batch.")
    identity = _batch_identity_payload(docs)
    batch_id = hashlib.sha256(
        json.dumps(identity, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    files = []
    for ordinal, doc in enumerate(docs, start=1):
        slot = f"f{ordinal:02d}"
        parse_state = _batch_parse_state(doc)
        files.append({
            "file_slot": slot,
            "document_key": doc["document_key"],
            "file_id": doc["file_id"],
            "filename": doc["filename"],
            "sha256": doc["sha256"],
            "encoding": doc["encoding"],
            "parse_status": parse_state,
            "canonical_count": len(doc["entries"]),
            "canonical_source_keys_digest": _canonical_source_keys_digest(doc),
            "product_windows": [],
            "product_count": 0,
            "target_product": None,
            "target_source_keys": [],
            "target_status": "UNASSESSED",
            "route_state": parse_state,
            "relation_hint": "UNKNOWN",
            "deep_scan_state": "NOT_STARTED",
            "final_gate_state": "NOT_STARTED",
            "verified_manifest_id": None,
            "task_state": create_task_state(doc),
        })
    return {
        "schema": "srt_v3_batch_manifest_v1",
        "workflow_version": "V3.0",
        "support_package_revision": SUPPORT_PACKAGE_REVISION,
        "batch_id": batch_id,
        "phase": "parsed",
        "file_count": len(files),
        "file_order": [row["file_slot"] for row in files],
        "files": files,
        "product_scan_method": "assistant-authored light boundary scan; Python only validates and routes recorded results",
    }


def validate_batch_manifest_identity(batch_manifest: dict[str, Any], docs: list[dict[str, Any]]) -> bool:
    if batch_manifest.get("schema") != "srt_v3_batch_manifest_v1":
        raise ValueError("Unsupported batch manifest schema.")
    identity = _batch_identity_payload(docs)
    expected_id = hashlib.sha256(
        json.dumps(identity, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    if batch_manifest.get("batch_id") != expected_id:
        raise ValueError("Batch manifest identity mismatch.")
    expected_rows = identity["ordered_files"]
    rows = batch_manifest.get("files", [])
    if len(rows) != len(expected_rows):
        raise ValueError("Batch manifest file count mismatch.")
    keys = (
        "file_slot", "document_key", "file_id", "filename", "sha256",
        "canonical_entry_count", "canonical_source_keys_digest",
    )
    for row, expected in zip(rows, expected_rows):
        observed = {
            "file_slot": row.get("file_slot"),
            "document_key": row.get("document_key"),
            "file_id": row.get("file_id"),
            "filename": row.get("filename"),
            "sha256": row.get("sha256"),
            "canonical_entry_count": row.get("canonical_count"),
            "canonical_source_keys_digest": row.get("canonical_source_keys_digest"),
        }
        if any(observed[k] != expected[k] for k in keys):
            raise ValueError(f"Batch manifest file identity mismatch for {expected['file_slot']}.")
    return True


def _batch_doc_map(docs: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {doc["document_key"]: doc for doc in docs}


def _find_batch_file(batch_manifest: dict[str, Any], file_ref: str) -> dict[str, Any]:
    matches = [
        row for row in batch_manifest.get("files", [])
        if file_ref in (row.get("file_slot"), row.get("document_key"))
    ]
    if len(matches) != 1:
        raise KeyError(f"Batch file reference is missing or ambiguous: {file_ref!r}")
    return matches[0]


def _product_window_from_scan(doc: dict[str, Any], product: dict[str, Any]) -> dict[str, Any]:
    name = str(product.get("name") or "").strip()
    classification = str(product.get("classification") or "").strip()
    if not name:
        raise ValueError("Every scanned product requires a non-empty name.")
    allowed = {"independent_sales", "same_variant", "accessory", "mention", "uncertain"}
    if classification not in allowed:
        raise ValueError(f"Unsupported product classification for {name!r}: {classification!r}")
    source_keys = list(product.get("source_keys") or [])
    by_key = _source_entries_by_key(doc)
    missing = [key for key in source_keys if key not in by_key]
    if missing:
        raise ValueError(f"Product scan crosses or misses canonical file identity: {missing[:3]}")
    entries = [by_key[key] for key in source_keys]
    return {
        "name": name,
        "classification": classification,
        "source_keys": source_keys,
        "matches_requested_target": bool(product.get("matches_requested_target", False)),
        "source_start_raw": min((e["start_raw"] for e in entries), default=None),
        "source_end_raw": max((e["end_raw"] for e in entries), default=None),
        "source_index_raw": [e["index_raw"] for e in entries],
    }


def _set_batch_row_target(
    row: dict[str, Any],
    doc: dict[str, Any],
    target_product: str,
    target_source_keys: list[str],
    context_before: int = 1,
    context_after: int = 1,
    merge_gap_blocks: int = 2,
) -> None:
    state = set_task_state_target(
        row["task_state"], doc, target_product, target_source_keys,
        context_before=context_before,
        context_after=context_after,
        merge_gap_blocks=merge_gap_blocks,
    )
    row["task_state"] = state
    row["target_product"] = target_product
    row["target_source_keys"] = list(target_source_keys)
    row["target_status"] = "RESOLVED"
    row["route_state"] = "READY" if row.get("parse_status") == "PARSED" else "STRUCTURE_WARNING"


def apply_batch_product_scan(
    batch_manifest: dict[str, Any],
    docs: list[dict[str, Any]],
    product_scans: dict[str, Any],
    requested_target: str | None = None,
) -> dict[str, Any]:
    """Apply assistant-authored light product scans once and deterministically route files.

    Python does not infer product semantics. For a requested global target, the assistant
    marks product records with matches_requested_target; this function only validates
    those recorded decisions and preserves HOT-PATH state.
    """
    validate_batch_manifest_identity(batch_manifest, docs)
    updated = copy.deepcopy(batch_manifest)
    doc_map = _batch_doc_map(docs)
    for row in updated["files"]:
        scan = product_scans.get(row["file_slot"])
        if scan is None:
            scan = product_scans.get(row["document_key"])
        if scan is None:
            continue
        doc = doc_map[row["document_key"]]
        products = [_product_window_from_scan(doc, p) for p in list(scan.get("products") or [])]
        row["product_windows"] = products
        independent = [p for p in products if p["classification"] == "independent_sales"]
        row["product_count"] = len(independent)
        relation = str(scan.get("relation_hint") or "UNKNOWN")
        if relation not in {"INDEPENDENT", "POSSIBLE_CONTINUOUS_SEGMENT", "SAME_PRODUCT_POSSIBLE", "UNKNOWN"}:
            raise ValueError(f"Unsupported relation_hint: {relation!r}")
        row["relation_hint"] = relation

        if row.get("parse_status") != "PARSED":
            row["target_status"] = "BLOCKED_BY_STRUCTURE"
            row["route_state"] = "STRUCTURE_WARNING"
            continue

        if requested_target is not None:
            matched = [p for p in products if p["matches_requested_target"]]
            if len(matched) == 1:
                _set_batch_row_target(row, doc, str(requested_target).strip(), matched[0]["source_keys"])
            elif not matched:
                row["target_product"] = str(requested_target).strip()
                row["target_source_keys"] = []
                row["target_status"] = "TARGET_NOT_FOUND"
                row["route_state"] = "TARGET_NOT_FOUND"
            else:
                row["target_product"] = str(requested_target).strip()
                row["target_source_keys"] = []
                row["target_status"] = "TARGET_AMBIGUOUS"
                row["route_state"] = "TARGET_AMBIGUOUS"
        elif len(independent) == 1:
            _set_batch_row_target(row, doc, independent[0]["name"], independent[0]["source_keys"])
        elif len(independent) > 1:
            row["target_status"] = "WAITING_PRODUCT_SELECTION"
            row["route_state"] = "WAITING_PRODUCT_SELECTION"
        else:
            row["target_status"] = "TARGET_NOT_FOUND"
            row["route_state"] = "TARGET_NOT_FOUND"

    states = {row["route_state"] for row in updated["files"]}
    if "WAITING_PRODUCT_SELECTION" in states or "TARGET_AMBIGUOUS" in states:
        updated["phase"] = "awaiting_product_selection"
    elif "READY" in states:
        updated["phase"] = "routed"
    else:
        updated["phase"] = "scanned"
    return updated


def set_batch_file_target(
    batch_manifest: dict[str, Any],
    docs: list[dict[str, Any]],
    file_ref: str,
    target_product: str,
    target_source_keys: list[str],
    context_before: int = 1,
    context_after: int = 1,
    merge_gap_blocks: int = 2,
) -> dict[str, Any]:
    """Resolve one previously ambiguous file without re-reading or re-parsing any SRT."""
    validate_batch_manifest_identity(batch_manifest, docs)
    updated = copy.deepcopy(batch_manifest)
    row = _find_batch_file(updated, file_ref)
    doc = _batch_doc_map(docs)[row["document_key"]]
    if row.get("parse_status") != "PARSED":
        raise ValueError("Cannot route a structurally blocked SRT into the deep-scan HOT PATH.")
    _set_batch_row_target(
        row, doc, str(target_product).strip(), list(target_source_keys),
        context_before=context_before,
        context_after=context_after,
        merge_gap_blocks=merge_gap_blocks,
    )
    states = {r["route_state"] for r in updated["files"]}
    updated["phase"] = "awaiting_product_selection" if (
        "WAITING_PRODUCT_SELECTION" in states or "TARGET_AMBIGUOUS" in states
    ) else "routed"
    return updated


def build_batch_confirmation_request(batch_manifest: dict[str, Any]) -> dict[str, Any]:
    files = []
    for row in batch_manifest.get("files", []):
        if row.get("route_state") not in {"WAITING_PRODUCT_SELECTION", "TARGET_AMBIGUOUS"}:
            continue
        files.append({
            "file_slot": row["file_slot"],
            "filename": row["filename"],
            "document_key": row["document_key"],
            "products": [
                {
                    "name": p["name"],
                    "classification": p["classification"],
                    "source_start_raw": p.get("source_start_raw"),
                    "source_end_raw": p.get("source_end_raw"),
                }
                for p in row.get("product_windows", [])
                if p.get("classification") == "independent_sales"
            ],
        })
    return {
        "batch_id": batch_manifest.get("batch_id"),
        "needs_confirmation": bool(files),
        "files": files,
    }


def build_batch_model_review_bundle(
    batch_manifest: dict[str, Any],
    docs: list[dict[str, Any]],
    file_ref: str,
) -> dict[str, Any]:
    """Build one file-scoped model bundle for a READY file in a multi-SRT batch.

    R8 sends the file scope once at payload level (``s``) and keeps row cue refs
    local (``c001``/``c002``/...). Cross-file safety still comes from the full
    deterministic identity chain: batch_id + file_slot + bundle_id + canonical
    document identity. This avoids repeating ``f01_`` on every row.
    """
    validate_batch_manifest_identity(batch_manifest, docs)
    row = _find_batch_file(batch_manifest, file_ref)
    if row.get("route_state") != "READY":
        raise ValueError(f"Batch file is not READY for deep review: {row.get('route_state')}")
    doc = _batch_doc_map(docs)[row["document_key"]]
    target_slice = row.get("task_state", {}).get("target_slice")
    if not target_slice:
        raise ValueError("READY batch file is missing a resumable target slice.")
    bundle = build_model_review_bundle(
        doc,
        target_slice,
        batch_id=batch_manifest["batch_id"],
        file_slot=row["file_slot"],
    )
    bundle["schema"] = "srt_v3_batch_model_review_bundle_v3"
    bundle["payload"]["s"] = row["file_slot"]
    bundle["internal"]["cue_ref_scope"] = "file_local"
    return bundle


def resolve_batch_model_cue_refs(
    batch_manifest: dict[str, Any],
    docs: list[dict[str, Any]],
    file_ref: str,
    bundle: dict[str, Any],
    cue_refs: list[str],
) -> list[str]:
    validate_batch_manifest_identity(batch_manifest, docs)
    row = _find_batch_file(batch_manifest, file_ref)
    internal = bundle.get("internal", {})
    payload = bundle.get("payload", {})
    if internal.get("batch_id") != batch_manifest.get("batch_id") or internal.get("file_slot") != row.get("file_slot"):
        raise ValueError("Batch model bundle belongs to a different batch file slot.")
    # R8 carries file scope once in the payload instead of repeating it in every cue_ref.
    # R7 bundles did not have ``s``; accepting a missing scope keeps resumability for
    # already-built R7 bundles while the internal identity checks remain mandatory.
    payload_scope = payload.get("s")
    if payload_scope is not None and payload_scope != row.get("file_slot"):
        raise ValueError("Batch model payload scope does not match the requested file slot.")
    doc = _batch_doc_map(docs)[row["document_key"]]
    return resolve_model_cue_refs(doc, bundle, cue_refs, bundle_id=payload.get("b"))


def attach_batch_verified_manifest(
    batch_manifest: dict[str, Any],
    docs: list[dict[str, Any]],
    file_ref: str,
    verified_manifest: dict[str, Any],
) -> dict[str, Any]:
    """Attach a passing Final Gate result while enforcing strict single-file identity."""
    validate_batch_manifest_identity(batch_manifest, docs)
    updated = copy.deepcopy(batch_manifest)
    row = _find_batch_file(updated, file_ref)
    doc = _batch_doc_map(docs)[row["document_key"]]
    if not verified_manifest.get("all_pass"):
        raise ValueError("Cannot attach a failed verified_manifest to a batch file.")
    if (
        verified_manifest.get("file_id") != doc.get("file_id")
        or verified_manifest.get("filename") != doc.get("filename")
        or verified_manifest.get("sha256") != doc.get("sha256")
    ):
        raise ValueError("Cross-file verified_manifest attachment is forbidden.")
    canonical_keys = {e["source_key"] for e in doc["entries"]}
    for entry in verified_manifest.get("entries", []):
        if (
            entry.get("source_key") not in canonical_keys
            or entry.get("file_id") != doc.get("file_id")
            or entry.get("filename") != doc.get("filename")
        ):
            raise ValueError("Verified manifest contains a source row from another SRT file.")
    row["verified_manifest_id"] = verified_manifest["manifest_id"]
    row["final_gate_state"] = "PASS"
    row["route_state"] = "COMPLETED"
    row["task_state"]["verified_manifest_id"] = verified_manifest["manifest_id"]
    updated["phase"] = "completed" if all(
        r["route_state"] in {"COMPLETED", "TARGET_NOT_FOUND", "SKIPPED", "STRUCTURE_WARNING"}
        for r in updated["files"]
    ) else updated.get("phase", "routed")
    return updated

def summarize_document(doc: dict[str, Any]) -> dict[str, Any]:
    d = doc["diagnostics"]
    return {
        "filename": doc["filename"],
        "document_key": doc.get("document_key", doc["filename"]),
        "sha256": doc["sha256"],
        "encoding": doc["encoding"],
        "parsed_entries": doc["total_entries"],
        "coverage_start": format_ms_comma(doc["coverage_start_ms"]) if doc["coverage_start_ms"] is not None else None,
        "coverage_end": format_ms_comma(doc["coverage_end_ms"]) if doc["coverage_end_ms"] is not None else None,
        "subtitle_span_ms": doc["overall_span_ms"],
        "subtitle_coverage_ms": doc["overall_subtitle_coverage_ms"],
        "uncovered_gap_ms": doc["overall_uncovered_gap_ms"],
        "fully_parsed": d["fully_parsed"],
        "duplicate_indices": d["duplicate_indices"],
        "missing_index_ranges": d["missing_index_ranges"],
        "non_increasing_indices": d["non_increasing_indices"],
        "malformed_blocks": d["malformed_blocks"],
        "zero_duration": d["zero_duration"],
        "negative_duration": d["negative_duration"],
        "empty_text": d["empty_text"],
        "source_time_reversals": d["source_time_reversals"],
        "time_order_valid": d["time_order_valid"],
        "duration_valid": d["duration_valid"],
        "overlaps": d["overlaps"],
        "long_gaps": d["long_gaps"],
        "serials_reliable": (d["index_unique"] and d["fully_parsed"]),
        "serials_start_at_one": d["serials_start_at_one"],
    }

def main() -> int:
    parser = argparse.ArgumentParser(description="SRT V3.0 parser and verifier")
    parser.add_argument("files", nargs="+", help="SRT files; each file is parsed independently")
    parser.add_argument("--selection-json", help="Optional JSON keyed by filename or document_key")
    parser.add_argument("--semantic-review-json", help="Optional assistant-authored opening/ending/numeric/composition review JSON keyed by filename or document_key")
    parser.add_argument("--require-semantic-review", action="store_true", help="Require a semantic-review record for every selected plan")
    parser.add_argument("--output-json", help="Optional path for machine-readable report")
    parser.add_argument("--include-verified-manifest", action="store_true", help="Include full verified_manifest entries/groups in CLI JSON; default keeps it internal and emits only its ID via the delivery contract")
    parser.add_argument("--emit-task-state", action="store_true", help="Include resumable task-state objects in document summaries; omitted by default to keep model-facing JSON compact")
    parser.add_argument("--emit-batch-manifest", action="store_true", help="Include the internal multi-SRT Batch Router manifest in CLI JSON")
    parser.add_argument("--batch-product-scan-json", help="Optional assistant-authored light product scan JSON keyed by file_slot or document_key")
    parser.add_argument("--requested-target", help="Optional user-specified global target product; scan records must mark matches_requested_target")
    parser.add_argument("--allow-repeats", action="store_true", help="Allow explicitly intentional repeated playback")
    parser.add_argument("--repeat-reason", help="Required reason when a selected source range is intentionally repeated")
    args = parser.parse_args()

    parsed_docs = [parse_srt_path_v3(file_path) for file_path in args.files]
    parsed_docs = assign_document_keys(parsed_docs)
    docs = {doc["document_key"]: doc for doc in parsed_docs}
    filename_aliases: dict[str, list[str]] = {}
    for doc in parsed_docs:
        filename_aliases.setdefault(doc["filename"], []).append(doc["document_key"])

    report = {"version": "V3.0", "support_package_revision": SUPPORT_PACKAGE_REVISION, "documents": [], "plans": {}}
    batch_manifest = build_batch_manifest(parsed_docs) if (len(parsed_docs) > 1 or args.emit_batch_manifest or args.batch_product_scan_json) else None
    if args.batch_product_scan_json:
        product_scans = json.loads(Path(args.batch_product_scan_json).read_text(encoding="utf-8"))
        batch_manifest = apply_batch_product_scan(batch_manifest, parsed_docs, product_scans, requested_target=args.requested_target)
    if batch_manifest is not None and (args.emit_batch_manifest or args.batch_product_scan_json):
        report["batch_manifest"] = batch_manifest
        report["batch_confirmation"] = build_batch_confirmation_request(batch_manifest)
    semantic_reviews = json.loads(Path(args.semantic_review_json).read_text(encoding="utf-8")) if args.semantic_review_json else None
    failures = []
    for doc in parsed_docs:
        summary = summarize_document(doc)
        if args.emit_task_state:
            summary["task_state"] = create_task_state(doc)
        report["documents"].append(summary)

    if args.selection_json:
        selections = json.loads(Path(args.selection_json).read_text(encoding="utf-8"))
        for requested_key, groups in selections.items():
            if requested_key in docs:
                document_key = requested_key
            elif requested_key in filename_aliases and len(filename_aliases[requested_key]) == 1:
                document_key = filename_aliases[requested_key][0]
            elif requested_key in filename_aliases:
                raise ValueError(
                    f"Selection key {requested_key!r} is ambiguous because multiple SRTs share this basename; "
                    f"use one of: {filename_aliases[requested_key]}"
                )
            else:
                raise KeyError(f"Selection refers to an unparsed file: {requested_key}")
            doc = docs[document_key]
            plan = validate_and_plan_groups(
                doc, groups,
                allow_repeats=args.allow_repeats,
                repeat_reason=args.repeat_reason,
            )
            verified_manifest = build_verified_manifest(doc, plan)
            verification = verified_manifest["verification"]
            delivery_contract = {
                "selected_count": verified_manifest["selected_count"],
                "serial_count": verified_manifest["serial_count"],
                "group_count": verified_manifest["group_count"],
                "serials": verified_manifest["serials"],
                "copy_button_payload": verified_manifest["copy_button_payload"],
                "code_block_payload": verified_manifest["code_block_payload"],
                "absolute_final_line": verified_manifest["absolute_final_line"],
                "count_consistent": verified_manifest["count_consistent"],
                "serials_consistent": verified_manifest["serials_consistent"],
                "copy_payloads_consistent": verified_manifest["copy_payloads_consistent"],
                "verified_manifest_id": verified_manifest["manifest_id"],
                "all_pass": verified_manifest["all_pass"],
            }
            plan_report = {
                "selected_count": plan["selected_count"],
                "group_count": len(plan["groups"]),
                "groups": [
                    {
                        "group_no": g["group_no"],
                        "indices": g["indices"],
                        "source_start": format_ms_comma(g["source_start_ms"]),
                        "source_end": format_ms_comma(g["source_end_ms"]),
                        "source_span_ms": g["source_span_ms"],
                        "subtitle_coverage_ms": g["subtitle_coverage_ms"],
                        "uncovered_gap_ms": g["uncovered_gap_ms"],
                        "timeline_start": format_ms_dot(g["timeline_start_ms"]),
                        "timeline_end": format_ms_dot(g["timeline_end_ms"]),
                    } for g in plan["groups"]
                ],
                "total_planned_span_ms": plan["total_planned_span_ms"],
                "total_subtitle_coverage_ms": plan["total_subtitle_coverage_ms"],
                "total_uncovered_gap_ms": plan["total_uncovered_gap_ms"],
                "serials": plan["serials"],
                "verification": verification,
                "delivery_sequence_contract": delivery_contract,
                "critical_numeric_candidates": detect_critical_numeric_candidates(doc),
            }
            if args.include_verified_manifest:
                plan_report["verified_manifest"] = verified_manifest
            if not verification["all_pass"] or not delivery_contract["all_pass"]:
                failures.append(f"{document_key}: source/count/copy verification failed")
            if semantic_reviews is not None:
                review_key = requested_key if requested_key in semantic_reviews else document_key
                if review_key not in semantic_reviews:
                    if args.require_semantic_review:
                        failures.append(f"{document_key}: semantic review JSON is missing")
                        plan_report["semantic_review"] = {"status": "missing", "all_pass": False, "errors": ["Missing semantic review record."]}
                    else:
                        plan_report["semantic_review"] = {"status": "not_provided", "all_pass": None, "errors": []}
                else:
                    semantic_result = validate_semantic_review(doc, plan, semantic_reviews[review_key])
                    plan_report["semantic_review"] = semantic_result
                    if not semantic_result["all_pass"]:
                        failures.append(f"{document_key}: semantic review failed")
            report["plans"][document_key] = plan_report

    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output_json:
        Path(args.output_json).write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 2 if failures else 0

if __name__ == "__main__":
    raise SystemExit(main())
