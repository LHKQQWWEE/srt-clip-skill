# SRT切片文案 V3.0｜工具链效率优化 R4

STATUS: ACTIVE SUPPORT PACKAGE R4｜业务版本仍为 V3.0，不升级 V3.1

## 目标
本轮只优化确定性工具层和模型输入体积，不改变五部分结构、第三部分冻结格式、商品语义判断、开头钩子三标准、原话保真或 source_key/时间码硬核验。

## 1. 单次 verified_manifest Final Gate
新增 `build_verified_manifest(doc, plan)`：
- 最终播放顺序仍只以 source_key 为锚点；
- 一次回查 canonical 源记录；
- 一次生成逐条原始字段、组级时间指标、累计成片时间轴、最终序号串和复制 payload；
- 第三部分、第五部分以及兼容层 `build_delivery_sequence_contract()` 均从同一 manifest 派生；
- CLI 不再先独立 `verify_final_selection()` 再重复构建 delivery contract。

成功路径新增单测确认：一次 `build_verified_manifest()` 只调用一次 canonical source resolve。

## 2. 紧凑中间态
新增 `build_compact_intermediate(doc, source_keys=None)`，只向模型需要的阶段提供：
- source_key / 原编号 / block ordinal；
- 原始起止时间和整数毫秒；
- 原文；
- 前后字幕间隔；
- 机械文本指纹与完全重复计数；
- 关键数字风险类别。

这不是自动商品/卖点分类器，不替代助手语义判断。

## 3. 目标商品切片
新增 `build_target_slice()`：商品边界由助手在轻量全文扫描后确定；程序仅按 source_key 截取目标区间并增加有限前后上下文。多商品确认后可把深度语义分析限制在目标商品区间，而不是再次把整份 SRT 送入深扫。

## 4. 会话任务状态对象
新增 `create_task_state()` 和 `set_task_state_target()`：
- 绑定 file_id、SHA-256、canonical source-key digest 和条数；
- 用户确认商品后记录 target_product、target_source_keys 和 target_slice；
- 状态与当前 canonical 文件身份不一致时直接拒绝复用；
- CLI 默认不输出状态对象，避免增加模型输入；仅 `--emit-task-state` 时输出。

## 5. 候选池机械压缩
新增 `compress_candidate_pool()`：
- 助手先提供已排序候选及 semantic_cluster / role；
- Python只删除完全相同 source_key 组合，按簇上限和开头/结尾上限截断；
- 默认每簇最多3个，开头最多5个，结尾最多5个；
- 不使用关键词替代语义评分，不擅自删除唯一事实、唯一购买动作或必要上下文。

## 6. CLI输出体积控制
- `--include-verified-manifest`：仅审计时输出完整 manifest；日常默认只在 delivery contract 返回 manifest ID。
- `--emit-task-state`：仅需要跨轮复用/调试时输出 task state；日常默认省略。
- 标准回归 JSON 不重复嵌套完整 source verification。

## 7. 实测边界
在本包 `1(4).srt` 40条/8组计划上，对 R3 的“`verify_final_selection + build_delivery_sequence_contract`”与 R4 的单次 `build_verified_manifest` 做同进程微基准：
- R3旧路径中位数约 0.6047 ms / 次；
- R4单次 manifest 约 0.3242 ms / 次；
- 确定性 Final Gate 微基准下降约 46.4%。

同一环境对完整9/10文件 CLI 子进程做多轮观察，R4与R3总耗时基本持平，差异处在毫秒级运行噪声；因此不得把46.4%宣称为端到端任务提速。标准CLI JSON体积较R3旧输出约减少3%，主要来自去除重复 verification 嵌套。

模型语义推理、Drive调用、人工确认和客户端渲染耗时不包含在上述微基准中。真正端到端效果必须用下一次真实 `srt切片文案` 任务继续计时。

## 8. 回归结果
- 单元测试：55/55通过；R3原47项全部保留通过，新增8项工具链测试。
- 主回归：9份基准SRT文件身份、2,120条字幕、6份候选方案全部通过。
- B组别名专项：1(5).srt，164条源字幕、38条入选、5组，来源映射与时间码通过。
- 1(4).srt语义审查：40条/8组，semantic review与verified_manifest均通过。
- 第三部分冻结格式与五部分结构未修改。
