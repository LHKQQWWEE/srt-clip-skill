# SRT切片文案 V3.0｜多SRT cue scope-once优化 R8

STATUS: ACTIVE SUPPORT PACKAGE R8｜业务版本仍为V3.0｜FAST-PATH 2.0保持不变

## 目标
R8只优化R7 Batch Router的模型载荷，不改变商品识别、文件隔离、HOT PATH、成交编排、五部分结构、第三部分冻结格式、45–90秒、multi-window、source_key或Final Gate。

R7在每一行cue_ref中重复文件命名空间，例如`f03_c001`、`f03_c002`。当目标商品包含数百条字幕时，`f03_`会在每行重复，形成可避免的序列化输入开销。

## R8协议
- 文件作用域只在bundle payload顶层发送一次：`s: "f03"`。
- 行级cue_ref恢复为文件内局部短引用：`c001`、`c002`、……。
- `bundle_id`仍由完整身份生成，身份继续包含`batch_id`、`file_slot`、`file_id`、`filename`、SHA-256和ordered source keys。
- `resolve_batch_model_cue_refs()`仍先校验batch/file slot，再校验payload scope，再调用canonical bundle resolver校验bundle_id、文件身份和source_key映射。
- 旧R7 `f01_c001` namespaced bundle继续允许恢复；R8不会让已经建立的R7 bundle状态失效。

## 安全性
R8不是通过删除文件身份来省字节。文件身份从“每行重复”移动到“bundle作用域一次 + internal完整身份链”。

跨文件负向测试：使用f01 bundle尝试在f02解析`c001`时，程序返回`Batch model bundle belongs to a different batch file slot.`并阻断。verified_manifest跨文件阻断规则保持不变。

## 真实三文件字节回归
沿用上一轮真实三SRT：
- `10月26日 (1).srt`：122行，7,504 → 7,018 bytes，下降6.477%。
- `10月28日(1).srt`：选定黑牛/黑色牛仔裤后84行，5,093 → 4,759 bytes，下降6.558%。
- `10月29日(1).srt`：818行，45,742 → 42,472 bytes，下降7.149%。
- 三文件合计：58,339 → 54,249 bytes，减少4,090 bytes，下降7.011%。

## 单SRT非回归
- 单SRT默认仍使用`c001/c002/...`，不增加`s`字段。
- `2(4).srt`同一66行生产slice模型payload继续为3,746 bytes。
- 普通单SRT CLI在忽略`support_package_revision`后与R7逐项一致。

## 回归
- 80/80单元测试通过；R7原78项全部保持通过，新增2项R8 scope-once与R7 bundle兼容测试。
- 11份SRT/6份既有CLI方案全部`verification.all_pass=true`。
- 跨文件resolver负向测试通过。
- R7 namespaced bundle恢复兼容测试通过。

## 指标纪律
本地确定性bundle构建500次观测：f03 R7约21.5830ms/次，R8约21.4325ms/次。该差异仅说明没有观察到程序层退化，不代表模型推理、Drive、客户端或端到端任务耗时同比下降。7.011%与7.149%只代表序列化模型payload体积下降。

## 版本治理
R8是V3.0程序支持修订，不创建V3.1。R7及更早支持包归档勿执行；业务规则和Runtime FAST-PATH 2.0不变。
