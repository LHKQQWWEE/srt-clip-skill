# -*- coding: utf-8 -*-
import unittest
import json
from pathlib import Path
from unittest.mock import patch
import tempfile
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from srt_v3_engine import (
    parse_srt_bytes_v3, parse_srt_path_v3, decode_srt_strict,
    validate_and_plan_groups, verify_final_selection,
    FIVE_SECTION_HEADINGS, THIRD_SECTION_FIELD_ORDER,
    validate_five_section_contract, validate_five_part_document,
    serial_copy_contract, validate_copy_payloads, render_third_section,
    render_five_part_document, route_project, validate_semantic_gate,
    assign_document_keys, timestamp_to_ms, format_ms_dot,
    detect_critical_numeric_candidates, validate_critical_claim_reviews,
    validate_candidate_competition, validate_final_composition_review,
    validate_semantic_review, validate_conversion_flow_review, build_delivery_sequence_contract,
    render_fifth_section, build_verified_manifest, build_compact_intermediate,
    build_target_slice, create_task_state, set_task_state_target,
    compress_candidate_pool, normalize_text_fingerprint,
    mechanical_surface_flags, validate_embedded_format_contract,
    FROZEN_FORMAT_CONTRACT_SHA256, build_model_review_bundle,
    resolve_model_cue_refs, resolve_candidate_cue_refs,
    build_batch_manifest, validate_batch_manifest_identity,
    apply_batch_product_scan, set_batch_file_target,
    build_batch_confirmation_request, build_batch_model_review_bundle,
    resolve_batch_model_cue_refs, attach_batch_verified_manifest,
)

BASELINE_GROUPS = {
    "1(1).srt": [
        [5,6,7,8,9,10], [16,17,18,19,20,21,22,23,24],
        [33,34,35,36], [64,65,66,67,68],
        [92,93,94,95,96,97,98,99,100], [120,121,122,123], [13,14,15]
    ],
    "2(1).srt": [
        [15,16,17,18,19,20,21,22,23,24],
        [33,34,35,36,37,38,39,40,41,42],
        [75,76,77,78,79], [83,84,85,86,87,88], [2,3,4], [80,81,82]
    ],
    "3(3).srt": [
        [6,7,8], [20,21,22,23,24,25], [67,68,69,70,71],
        [77,78,79], [107,108,109,110,111,112,113,114,115,116,117,118,119],
        [126,127,128], [187,188,189,190,191,192], [74]
    ],
}
EXPECTED_BASELINE = {
    "1(1).srt": (40, 7, 52301, 49668, 2633),
    "2(1).srt": (37, 6, 47400, 44301, 3099),
    "3(3).srt": (40, 8, 47802, 46804, 998),
}
NEW_SAMPLE_COUNTS = {
    "10月26日 (1).srt": 122,
    "10月28日(1).srt": 137,
    "10月28日(2).srt": 260,
    "10月29日(1).srt": 823,
    "10月30日(1).srt": 160,
    "1(4).srt": 164,
}

B_GROUP_1_5 = [
    list(range(28, 37)),
    list(range(20, 25)),
    list(range(64, 78)),
    list(range(92, 101)),
    [105],
]

class TestV3Engine(unittest.TestCase):
    def fixture_doc(self, text, filename="fixture.srt", threshold=5000):
        return parse_srt_bytes_v3(
            text.encode("utf-8"), filename, long_gap_threshold_ms=threshold
        )

    def test_utf8_sig(self):
        doc = parse_srt_bytes_v3(
            b"\xef\xbb\xbf1\r\n00:00:00,000 --> 00:00:01,000\r\n\xe4\xb8\xad\xe6\x96\x87",
            "bom.srt"
        )
        self.assertEqual(doc["encoding"], "utf-8-sig")
        self.assertEqual(doc["entries"][0]["original_text"], "中文")

    def test_plain_utf8_is_reported_as_utf8_not_utf8_sig(self):
        raw = "1\n00:00:00,000 --> 00:00:01,000\n中文".encode("utf-8")
        doc = parse_srt_bytes_v3(raw, "plain-utf8.srt")
        self.assertEqual(doc["encoding"], "utf-8")

    def test_route_keeps_pure_srt_separate_from_video_project(self):
        pure = route_project("srt切片文案", ["a.srt", "b.MP4", "c.txt"])
        self.assertEqual(pure["route"], "srt_v3_active")
        self.assertEqual(pure["accepted_files"], ["a.srt"])
        self.assertEqual(pure["ignored_files"], ["b.MP4", "c.txt"])
        self.assertFalse(pure["reads_media"])
        video = route_project("切片文案", ["a.srt", "b.mp4"])
        self.assertEqual(video["route"], "cut_v5.1")
        self.assertTrue(video["reads_media"])

    def test_duplicate_basenames_get_distinct_document_keys(self):
        raw = "1\n00:00:00,000 --> 00:00:01,000\nA".encode("utf-8")
        a = parse_srt_bytes_v3(raw, "same.srt", file_id="/left/same.srt")
        b = parse_srt_bytes_v3(raw, "same.srt", file_id="/right/same.srt")
        keyed = assign_document_keys([a, b])
        self.assertEqual(len({d["document_key"] for d in keyed}), 2)
        self.assertNotEqual(keyed[0]["entries"][0]["source_key"], keyed[1]["entries"][0]["source_key"])

    def test_semantic_gate_fixture_requires_block_for_multi_product(self):
        root = Path(__file__).parent.parent / "test_data"
        manifest = json.loads((root / "sample_manifest_and_semantic_gate.json").read_text(encoding="utf-8"))
        result = validate_semantic_gate(manifest)
        self.assertTrue(result["all_pass"], result["errors"])
        self.assertEqual(result["sample_count"], 6)
        self.assertEqual(result["blocked_count"], 4)
        self.assertEqual(result["single_product_count"], 2)

    def test_semantic_gate_rejects_unblocked_multi_product_sample(self):
        root = Path(__file__).parent.parent / "test_data"
        manifest = json.loads((root / "sample_manifest_and_semantic_gate.json").read_text(encoding="utf-8"))
        manifest["semantic_gate_results"][1]["block_required"] = False
        result = validate_semantic_gate(manifest)
        self.assertFalse(result["all_pass"])
        self.assertTrue(any("must block" in error for error in result["errors"]))

    def test_gb18030_fallback(self):
        raw = "1\n00:00:00,000 --> 00:00:01,000\n中文".encode("gb18030")
        doc = parse_srt_bytes_v3(raw, "gb.srt")
        self.assertEqual(doc["encoding"], "gb18030")
        self.assertEqual(doc["entries"][0]["original_text"], "中文")

    def test_strict_decode_failure(self):
        with self.assertRaises(UnicodeError):
            decode_srt_strict(b"\x81")

    def test_duplicate_basename_cli_does_not_overwrite_or_guess_selection(self):
        engine_path = Path(__file__).parent.parent / "src" / "srt_v3_engine.py"
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            left = root / "left" / "same.srt"
            right = root / "right" / "same.srt"
            left.parent.mkdir()
            right.parent.mkdir()
            fixture = "1\n00:00:00,000 --> 00:00:01,000\nA"
            left.write_text(fixture, encoding="utf-8")
            right.write_text(fixture, encoding="utf-8")

            parsed = subprocess.run(
                [sys.executable, "-S", str(engine_path), str(left), str(right)],
                capture_output=True, text=True
            )
            self.assertEqual(parsed.returncode, 0)
            report = json.loads(parsed.stdout)
            self.assertEqual(len(report["documents"]), 2)
            keys = [row["document_key"] for row in report["documents"]]
            self.assertEqual(len(set(keys)), 2)

            selection = root / "selection.json"
            selection.write_text(json.dumps({"same.srt": [[1]]}), encoding="utf-8")
            blocked = subprocess.run(
                [sys.executable, "-S", str(engine_path), str(left), str(right),
                 "--selection-json", str(selection)],
                capture_output=True, text=True
            )
            self.assertNotEqual(blocked.returncode, 0)
            self.assertIn("ambiguous", blocked.stderr.lower())

    def test_duplicate_missing_overlap_zero_negative_empty_and_long_gap(self):
        fixture = (
            "1\n00:00:00,000 --> 00:00:01,000\nA\n\n"
            "1\n00:00:00,800 --> 00:00:01,500\nB\n\n"
            "3\n00:00:02,000 --> 00:00:02,000\nC\n\n"
            "4\n00:00:05,000 --> 00:00:04,000\nD\n\n"
            "5\n00:00:06,000 --> 00:00:06,500\n"
        )
        doc = self.fixture_doc(fixture, threshold=1000)
        d = doc["diagnostics"]
        self.assertEqual(d["duplicate_indices"], [1])
        self.assertEqual(d["missing_index_ranges"], ["2"])
        self.assertEqual(d["zero_duration"], [3])
        self.assertEqual(d["negative_duration"], [4])
        self.assertEqual(d["empty_text"], [5])
        self.assertTrue(d["overlaps"])
        self.assertTrue(d["long_gaps"])
        self.assertFalse(d["duration_valid"])

    def test_malformed_block_detected(self):
        fixture = (
            "1\n00:00:00,000 --> 00:00:01,000\nA\n\n"
            "BAD\n00:00:01,000 --> 00:00:02,000\nB"
        )
        doc = self.fixture_doc(fixture)
        self.assertEqual(len(doc["diagnostics"]["malformed_blocks"]), 1)
        self.assertFalse(doc["diagnostics"]["fully_parsed"])

    def test_source_time_reversal_detected_and_selection_blocked(self):
        fixture = (
            "1\n00:00:02,000 --> 00:00:03,000\nA\n\n"
            "2\n00:00:01,000 --> 00:00:02,000\nB"
        )
        doc = self.fixture_doc(fixture)
        self.assertEqual(doc["diagnostics"]["source_time_reversals"], [(1,2)])
        with self.assertRaises(ValueError):
            validate_and_plan_groups(doc, [[1,2]])

    def test_unique_file_namespaces_even_for_identical_bytes(self):
        a = self.fixture_doc("1\n00:00:00,000 --> 00:00:01,000\nA", "a.srt")
        b = self.fixture_doc("1\n00:00:00,000 --> 00:00:01,000\nA", "b.srt")
        self.assertNotEqual(a["entries"][0]["source_key"], b["entries"][0]["source_key"])

    def test_three_baseline_regressions_exact(self):
        root = Path(__file__).parent.parent / "source_srt"
        for filename, groups in BASELINE_GROUPS.items():
            doc = parse_srt_path_v3(str(root / filename))
            plan = validate_and_plan_groups(doc, groups)
            verify = verify_final_selection(doc, plan)
            actual = (
                plan["selected_count"], len(plan["groups"]),
                plan["total_planned_span_ms"],
                plan["total_subtitle_coverage_ms"],
                plan["total_uncovered_gap_ms"],
            )
            self.assertEqual(actual, EXPECTED_BASELINE[filename])
            self.assertTrue(verify["all_pass"])

    def test_optimization_manifest_records_v3_active_and_nine_unique_srt_samples(self):
        root = Path(__file__).parent.parent
        manifest = json.loads((root / "test_data" / "sample_manifest_and_semantic_gate.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["active_version"], "V3.0")
        self.assertEqual(manifest["total_unique_srt_files"], 9)
        self.assertEqual(manifest["total_entries"], 2120)
        self.assertIn("1(4).srt", manifest["new_unique_files"])
        self.assertTrue(any(
            row.get("filename") == "1(5).srt"
            and row.get("same_sha256_as") == "1(4).srt"
            and row.get("sha256") == "cadfc755c24b572bfda1168cfe9d7e3b03181b27d49a5b9c74e7cdf4658406e5"
            for row in manifest["excluded_duplicates"]
        ))
        self.assertEqual(manifest["quality_optimization_cli_timing_ms"]["exit_code"], 0)

    def test_six_new_samples_full_structure_parse(self):
        root = Path(__file__).parent.parent / "source_srt"
        for filename, expected_count in NEW_SAMPLE_COUNTS.items():
            doc = parse_srt_path_v3(str(root / filename))
            self.assertEqual(doc["total_entries"], expected_count, filename)
            self.assertTrue(doc["diagnostics"]["fully_parsed"], filename)
            self.assertTrue(doc["diagnostics"]["index_unique"], filename)
            self.assertFalse(doc["diagnostics"]["malformed_blocks"], filename)
            self.assertFalse(doc["diagnostics"]["overlaps"], filename)
            self.assertFalse(doc["diagnostics"]["source_time_reversals"], filename)

    def test_skipped_source_block_must_split_group(self):
        root = Path(__file__).parent.parent / "source_srt"
        doc = parse_srt_path_v3(str(root / "1(1).srt"))
        with self.assertRaises(ValueError):
            validate_and_plan_groups(doc, [[5,7]])

    def test_repeat_requires_explicit_permission(self):
        root = Path(__file__).parent.parent / "source_srt"
        doc = parse_srt_path_v3(str(root / "1(1).srt"))
        with self.assertRaises(ValueError):
            validate_and_plan_groups(doc, [[5,6],[5,6]])
        with self.assertRaises(ValueError):
            validate_and_plan_groups(doc, [[5,6],[5,6]], allow_repeats=True)
        plan = validate_and_plan_groups(doc, [[5,6],[5,6]], allow_repeats=True, repeat_reason="intentional callback")
        self.assertEqual(plan["repeat_counts"], {"5":2,"6":2})

    def test_cross_group_time_overlap_requires_explicit_permission(self):
        fixture = (
            "1\n00:00:00,000 --> 00:00:02,000\nA\n\n"
            "2\n00:00:01,000 --> 00:00:03,000\nB"
        )
        doc = self.fixture_doc(fixture)
        with self.assertRaises(ValueError):
            validate_and_plan_groups(doc, [[1],[2]])
        plan = validate_and_plan_groups(doc, [[1],[2]], allow_repeats=True, repeat_reason="intentional replay")
        self.assertTrue(plan["cross_group_overlaps"])

    def test_invalid_duration_cannot_be_selected(self):
        fixture = "1\n00:00:01,000 --> 00:00:01,000\nA"
        doc = self.fixture_doc(fixture)
        with self.assertRaises(ValueError):
            validate_and_plan_groups(doc, [[1]])


    def test_serial_output_must_match_source_mapping(self):
        root = Path(__file__).parent.parent / "source_srt"
        doc = parse_srt_path_v3(str(root / "1(1).srt"))
        plan = validate_and_plan_groups(doc, [[5,6]])
        plan["serials"] = "999,998"
        verification = verify_final_selection(doc, plan)
        self.assertFalse(verification["serials_source_mapping_pass"])
        self.assertFalse(verification["all_pass"])

    def test_serial_copy_payloads_are_identical(self):
        serials = "5,6,7,8"
        contract = serial_copy_contract(serials)
        self.assertEqual(contract["copy_button_payload"], contract["code_block_payload"])
        self.assertEqual(contract["code_block_payload"], contract["absolute_final_line"])

    def test_five_section_order_and_third_section_fields_locked(self):
        self.assertTrue(validate_five_section_contract(FIVE_SECTION_HEADINGS))
        self.assertFalse(validate_five_section_contract(FIVE_SECTION_HEADINGS[::-1]))
        self.assertEqual(
            THIRD_SECTION_FIELD_ORDER,
            [
                "片段序号/片段功能",
                "预计成片时间轴",
                "原SRT起止时间",
                "源序号",
                "本组未覆盖间隔",
                "SRT源字幕定位",
                "完整原始字幕文本",
            ]
        )
        bodies = {heading: "测试内容" for heading in FIVE_SECTION_HEADINGS}
        rendered = render_five_part_document(bodies)
        self.assertTrue(validate_five_part_document(rendered))
        self.assertFalse(validate_five_part_document("\n".join(FIVE_SECTION_HEADINGS[::-1])))

    def test_b_group_1_5_regression_renders_from_unique_source_index(self):
        root = Path(__file__).parent.parent / "source_srt"
        doc = parse_srt_path_v3(str(root / "1(5).srt"))
        plan = validate_and_plan_groups(doc, B_GROUP_1_5)
        verification = verify_final_selection(doc, plan)
        contract = build_delivery_sequence_contract(doc, plan)
        self.assertEqual(doc["total_entries"], 164)
        baseline_doc = parse_srt_path_v3(str(root / "1(4).srt"))
        self.assertEqual(doc["sha256"], baseline_doc["sha256"])
        self.assertNotEqual(doc["file_id"], baseline_doc["file_id"])
        self.assertNotEqual(doc["entries"][93]["source_key"], baseline_doc["entries"][93]["source_key"])
        self.assertEqual(plan["selected_count"], 38)
        self.assertEqual(len(plan["groups"]), 5)
        self.assertEqual(plan["total_planned_span_ms"], 47634)
        self.assertEqual(plan["total_subtitle_coverage_ms"], 45201)
        self.assertEqual(plan["total_uncovered_gap_ms"], 2433)
        self.assertTrue(verification["all_pass"], verification["errors"])
        self.assertTrue(verification["group_metadata_pass"])
        self.assertTrue(contract["all_pass"])
        rendered = render_third_section(
            doc, plan, "大衣的版型适配、110支细羊毛与柔软度解释", 
            ["小个子版型适配", "110支面料差异", "纱线细腻与柔软解释", "体重尺码建议", "购买动作收口"]
        )
        self.assertIn("94 | 00:01:58,900 --> 00:02:00,066 | 100斤以下穿s码", rendered)
        self.assertNotIn("94 | 00:02:00,066 --> 00:01:58,900", rendered)
        self.assertTrue(rendered.index("28 | ") < rendered.index("20 | ") < rendered.index("64 | ") < rendered.index("92 | ") < rendered.index("105 | "))
        self.assertEqual(plan["serials"], ",".join(str(i) for i in list(range(28,37))+list(range(20,25))+list(range(64,78))+list(range(92,101))+[105]))

    def test_source_mapping_blocks_reversed_start_end_time_fields(self):
        root = Path(__file__).parent.parent / "source_srt"
        doc = parse_srt_path_v3(str(root / "1(5).srt"))
        plan = validate_and_plan_groups(doc, B_GROUP_1_5)
        cue = next(e for e in plan["groups"][3]["entries"] if e["index"] == 94)
        source_cue = doc["entries_by_index"][94][0]
        source_times_before = (source_cue["start_raw"], source_cue["end_raw"], source_cue["start_ms"], source_cue["end_ms"])
        self.assertIsNot(cue, source_cue)
        cue["start_raw"], cue["end_raw"] = cue["end_raw"], cue["start_raw"]
        cue["start_ms"], cue["end_ms"] = cue["end_ms"], cue["start_ms"]
        self.assertEqual(
            (source_cue["start_raw"], source_cue["end_raw"], source_cue["start_ms"], source_cue["end_ms"]),
            source_times_before,
        )
        verification = verify_final_selection(doc, plan)
        self.assertFalse(verification["time_pass"])
        self.assertFalse(verification["all_pass"])
        with self.assertRaises(ValueError):
            render_third_section(doc, plan, "测试主题", ["1", "2", "3", "4", "5"])

    def test_source_mapping_blocks_time_fields_copied_from_adjacent_cue(self):
        root = Path(__file__).parent.parent / "source_srt"
        doc = parse_srt_path_v3(str(root / "1(5).srt"))
        plan = validate_and_plan_groups(doc, B_GROUP_1_5)
        cue94 = next(e for e in plan["groups"][3]["entries"] if e["index"] == 94)
        cue95 = next(e for e in plan["groups"][3]["entries"] if e["index"] == 95)
        for field in ("start_raw", "end_raw", "start_ms", "end_ms"):
            cue94[field] = cue95[field]
        verification = verify_final_selection(doc, plan)
        self.assertFalse(verification["time_pass"])
        self.assertFalse(verification["all_pass"])

    def test_source_mapping_blocks_group_source_and_timeline_metadata_drift(self):
        root = Path(__file__).parent.parent / "source_srt"
        doc = parse_srt_path_v3(str(root / "1(5).srt"))
        plan = validate_and_plan_groups(doc, B_GROUP_1_5)
        plan["groups"][3]["source_end_ms"] += 1
        verification = verify_final_selection(doc, plan)
        self.assertFalse(verification["group_metadata_pass"])
        self.assertFalse(verification["all_pass"])
        with self.assertRaises(ValueError):
            render_third_section(doc, plan, "测试主题", ["1", "2", "3", "4", "5"])

    def test_third_section_renderer_preserves_exact_approved_order_and_source_text(self):
        fixture = (
            "5\n00:00:10,000 --> 00:00:11,000\n开头原话\n\n"
            "6\n00:00:11,000 --> 00:00:12,500\n第二句\n第三行"
        )
        doc = parse_srt_bytes_v3(fixture.encode("utf-8"), "render.srt")
        plan = validate_and_plan_groups(doc, [[5,6]])
        rendered = render_third_section(
            doc, plan, "测试主推主题", ["开头钩子"]
        )
        expected = (
            "三、最佳成片方案\n"
            "主推主题：测试主推主题\n"
            "预计成片时长：00:00:02.500\n"
            "片段1｜开头钩子｜预计成片 00:00:00.000–00:00:02.500｜"
            "原SRT 00:00:10.000–00:00:12.500｜源序号 5–6｜"
            "本组未覆盖间隔 00:00:00.000｜SRT源字幕定位\n"
            "5 | 00:00:10,000 --> 00:00:11,000 | 开头原话\n"
            "6 | 00:00:11,000 --> 00:00:12,500 | 第二句\n第三行"
        )
        self.assertEqual(rendered, expected)
        self.assertLess(rendered.index("SRT源字幕定位"), rendered.index("5 | 00:00:10,000"))
        self.assertIn("第二句\n第三行", rendered)

    def test_third_section_renderer_blocks_failed_source_verification(self):
        fixture = (
            "5\n00:00:10,000 --> 00:00:11,000\n开头原话\n\n"
            "6\n00:00:11,000 --> 00:00:12,500\n第二句"
        )
        doc = parse_srt_bytes_v3(fixture.encode("utf-8"), "render-fail.srt")
        plan = validate_and_plan_groups(doc, [[5,6]])
        plan["serials"] = "999,998"
        with self.assertRaises(ValueError):
            render_third_section(doc, plan, "测试主题", ["开头钩子"])

    def test_copy_payloads_must_match_exactly_and_be_valid_serials(self):
        self.assertTrue(validate_copy_payloads("005,006,007", "005,006,007", "005,006,007"))
        self.assertFalse(validate_copy_payloads("005,006", "005,007", "005,006"))
        self.assertFalse(validate_copy_payloads("5, 6", "5, 6", "5, 6"))
        self.assertFalse(validate_copy_payloads("5,6", "5,6", "5,6\nextra"))


    def test_original_serial_token_preserved(self):
        fixture = (
            "001\n00:00:00,000 --> 00:00:01,000\nA\n\n"
            "002\n00:00:01,000 --> 00:00:02,000\nB"
        )
        doc = self.fixture_doc(fixture, "leading-zero.srt")
        plan = validate_and_plan_groups(doc, [[1,2]])
        self.assertEqual(plan["serials"], "001,002")

    def test_delivery_sequence_contract_generates_count_and_copy_from_one_sequence(self):
        fixture = (
            "001\n00:00:00,000 --> 00:00:01,000\nA\n\n"
            "002\n00:00:01,000 --> 00:00:02,000\nB"
        )
        doc = self.fixture_doc(fixture, "canonical-sequence.srt")
        plan = validate_and_plan_groups(doc, [[1, 2]])
        contract = build_delivery_sequence_contract(doc, plan)
        self.assertTrue(contract["all_pass"])
        self.assertEqual(contract["selected_count"], 2)
        self.assertEqual(contract["serial_count"], 2)
        self.assertEqual(contract["group_count"], 1)
        self.assertEqual(contract["serials"], "001,002")
        self.assertEqual(contract["copy_button_payload"], contract["code_block_payload"])
        self.assertEqual(contract["code_block_payload"], contract["absolute_final_line"])

    def test_fifth_section_count_and_copy_surfaces_are_generated_from_same_sequence(self):
        fixture = (
            "001\n00:00:00,000 --> 00:00:01,000\nA\n\n"
            "002\n00:00:01,000 --> 00:00:02,000\nB"
        )
        doc = self.fixture_doc(fixture, "fifth-section.srt")
        plan = validate_and_plan_groups(doc, [[1], [2]])
        rendered = render_fifth_section(doc, plan)
        self.assertEqual(rendered["count_label"], "最终序号：2条字幕")
        self.assertEqual(rendered["copy_button_payload"], "001,002")
        self.assertEqual(rendered["code_block_payload"], "001,002")
        self.assertEqual(rendered["absolute_final_line"], "001,002")
        self.assertEqual(rendered["code_block_text"], "```text\n001,002\n```")
        self.assertTrue(rendered["all_pass"])

    def test_delivery_sequence_contract_blocks_manual_count_mismatch(self):
        fixture = (
            "1\n00:00:00,000 --> 00:00:01,000\nA\n\n"
            "2\n00:00:01,000 --> 00:00:02,000\nB"
        )
        doc = self.fixture_doc(fixture, "count-mismatch.srt")
        plan = validate_and_plan_groups(doc, [[1, 2]])
        plan["selected_count"] = 1
        contract = build_delivery_sequence_contract(doc, plan)
        self.assertFalse(contract["count_consistent"])
        self.assertFalse(contract["all_pass"])

    def test_delivery_sequence_contract_blocks_playback_array_drift_even_when_count_matches(self):
        fixture = (
            "1\n00:00:00,000 --> 00:00:01,000\nA\n\n"
            "2\n00:00:01,000 --> 00:00:02,000\nB"
        )
        doc = self.fixture_doc(fixture, "playback-array-drift.srt")
        plan = validate_and_plan_groups(doc, [[1], [2]])
        plan["selected_indices_in_playback_order"] = [2, 1]
        with self.assertRaises(AssertionError):
            build_delivery_sequence_contract(doc, plan)

    def test_critical_numeric_detector_flags_85_de_yangmao_as_ambiguous(self):
        fixture = "1\n00:00:00,000 --> 00:00:01,000\n85的羊毛"
        doc = self.fixture_doc(fixture, "ambiguous-material.srt")
        candidates = detect_critical_numeric_candidates(doc)
        self.assertEqual(len(candidates), 1)
        self.assertEqual(candidates[0]["category"], "material_composition")
        self.assertEqual(candidates[0]["risk"], "ambiguous_missing_unit")

    def test_critical_claim_gate_blocks_ambiguous_numeric_used_as_fact(self):
        fixture = "1\n00:00:00,000 --> 00:00:01,000\n85的羊毛"
        doc = self.fixture_doc(fixture, "ambiguous-material-selected.srt")
        plan = validate_and_plan_groups(doc, [[1]])
        bad = [{
            "source_index": 1, "category": "material_composition", "raw_text": "85的羊毛",
            "decision": "clear", "use_as_fact": True, "reason": "assumed percentage"
        }]
        result = validate_critical_claim_reviews(doc, plan, bad)
        self.assertFalse(result["all_pass"])
        good = [{
            "source_index": 1, "category": "material_composition", "raw_text": "85的羊毛",
            "decision": "verbatim_only", "use_as_fact": False,
            "warning": "比例单位不完整，不得推断为85%", "reason": "保留原话但不作为成分事实"
        }]
        self.assertTrue(validate_critical_claim_reviews(doc, plan, good)["all_pass"])

    def test_critical_claim_gate_requires_review_for_every_selected_numeric_candidate(self):
        fixture = "1\n00:00:00,000 --> 00:00:01,000\n780克的克重"
        doc = self.fixture_doc(fixture, "weight-review.srt")
        plan = validate_and_plan_groups(doc, [[1]])
        result = validate_critical_claim_reviews(doc, plan, [])
        self.assertFalse(result["all_pass"])
        self.assertEqual(result["missing_reviews"][0]["source_index"], 1)

    def test_candidate_competition_blocks_context_dependent_opening(self):
        fixture = (
            "1\n00:00:00,000 --> 00:00:01,000\n那我就让你们做一件\n\n"
            "2\n00:00:01,000 --> 00:00:02,000\n这是大衣"
        )
        doc = self.fixture_doc(fixture, "opening-review.srt")
        candidates = [{
            "candidate_id": "opening-1", "source_indices": [1, 2],
            "standalone_intelligibility": "partial", "product_anchor": "clear",
            "transition_fit": "medium", "context_dependency": "medium",
            "decision": "selected", "decision_reason": "test"
        }]
        result = validate_candidate_competition(doc, "opening_hook", candidates, "opening-1")
        self.assertFalse(result["all_pass"])

    def test_candidate_competition_requires_reason_for_rejected_alternatives(self):
        fixture = (
            "1\n00:00:00,000 --> 00:00:01,000\n深藏青大衣\n\n"
            "2\n00:00:01,000 --> 00:00:02,000\n准备好链接上车"
        )
        doc = self.fixture_doc(fixture, "ending-review.srt")
        candidates = [
            {"candidate_id": "end-1", "source_indices": [2],
             "standalone_intelligibility": "yes", "product_anchor": "contextual",
             "transition_fit": "strong", "context_dependency": "low",
             "purchase_action": "explicit", "transaction_info": "not_applicable",
             "natural_close": "strong", "decision": "selected", "decision_reason": "best CTA"},
            {"candidate_id": "end-2", "source_indices": [1],
             "standalone_intelligibility": "yes", "product_anchor": "clear",
             "transition_fit": "medium", "context_dependency": "low",
             "purchase_action": "none", "transaction_info": "not_applicable",
             "natural_close": "weak", "decision": "rejected", "decision_reason": ""}
        ]
        result = validate_candidate_competition(doc, "ending_close", candidates, "end-1")
        self.assertFalse(result["all_pass"])
        self.assertTrue(any("decision_reason" in e for e in result["errors"]))

    def test_candidate_competition_blocks_ending_without_purchase_action(self):
        fixture = "1\n00:00:00,000 --> 00:00:01,000\n大衣结束了"
        doc = self.fixture_doc(fixture, "weak-ending.srt")
        candidates = [{
            "candidate_id": "end-weak", "source_indices": [1],
            "standalone_intelligibility": "yes", "product_anchor": "clear",
            "transition_fit": "strong", "context_dependency": "low",
            "purchase_action": "none", "transaction_info": "not_applicable",
            "natural_close": "medium", "decision": "selected", "decision_reason": "weak test"
        }]
        result = validate_candidate_competition(doc, "ending_close", candidates, "end-weak")
        self.assertFalse(result["all_pass"])
        self.assertTrue(any("purchase action" in e for e in result["errors"]))

    def test_cli_require_semantic_review_blocks_missing_review_record(self):
        root = Path(__file__).parent.parent
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            srt = td / "one.srt"
            srt.write_text("1\n00:00:00,000 --> 00:00:01,000\n大衣", encoding="utf-8")
            selections = td / "selection.json"
            selections.write_text(json.dumps({"one.srt": [[1]]}), encoding="utf-8")
            reviews = td / "reviews.json"
            reviews.write_text("{}", encoding="utf-8")
            output = td / "report.json"
            result = subprocess.run(
                [sys.executable, "-S", str(root / "src" / "srt_v3_engine.py"), str(srt),
                 "--selection-json", str(selections), "--semantic-review-json", str(reviews),
                 "--require-semantic-review", "--output-json", str(output)],
                capture_output=True, text=True,
            )
            self.assertEqual(result.returncode, 2)
            report = json.loads(output.read_text(encoding="utf-8"))
            plan = report["plans"]["one.srt"]
            self.assertFalse(plan["semantic_review"]["all_pass"])
            self.assertEqual(plan["semantic_review"]["status"], "missing")

    def test_final_composition_review_requires_every_group_and_final_readthrough(self):
        fixture = (
            "1\n00:00:00,000 --> 00:00:01,000\nA\n\n"
            "2\n00:00:01,000 --> 00:00:02,000\nB"
        )
        doc = self.fixture_doc(fixture, "composition-review.srt")
        plan = validate_and_plan_groups(doc, [[1], [2]])
        review = {
            "price_placement_reviewed": True, "product_boundary_reviewed": True,
            "continuity_reviewed": True, "duplication_reviewed": True,
            "marginal_contribution_reviewed": True, "final_readthrough_completed": True,
            "final_readthrough_passed": False, "overall_decision": "pass",
            "segment_contributions": [
                {"group_no": 1, "source_indices": [1], "contribution_type": "new_information", "reason": "A"},
                {"group_no": 2, "source_indices": [2], "contribution_type": "distinct_evidence", "reason": "B"}
            ]
        }
        result = validate_final_composition_review(doc, plan, review)
        self.assertFalse(result["all_pass"])

    def test_optimized_1_4_regression_semantic_review_and_source_mapping(self):
        root = Path(__file__).parent.parent
        doc = parse_srt_path_v3(str(root / "source_srt" / "1(4).srt"))
        selections = json.loads((root / "test_data" / "optimized_task_1_4_selection.json").read_text(encoding="utf-8"))
        review_data = json.loads((root / "test_data" / "optimized_task_1_4_semantic_review.json").read_text(encoding="utf-8"))
        plan = validate_and_plan_groups(doc, selections["1(4).srt"])
        delivery = build_delivery_sequence_contract(doc, plan)
        semantic = validate_semantic_review(doc, plan, review_data["1(4).srt"])
        self.assertEqual(doc["total_entries"], 164)
        self.assertTrue(delivery["all_pass"])
        self.assertEqual(delivery["selected_count"], 40)
        self.assertEqual(delivery["serial_count"], 40)
        self.assertEqual(delivery["group_count"], 8)
        self.assertEqual(plan["total_planned_span_ms"], 48833)
        self.assertEqual(plan["serials"], "8,9,10,30,31,32,33,34,35,36,20,21,22,23,24,64,65,66,67,68,69,70,71,72,73,74,92,93,94,95,96,97,123,142,143,144,145,103,104,105")
        self.assertTrue(semantic["all_pass"], semantic["errors"])

    def test_r6_conversion_oriented_1_4_regression(self):
        root = Path(__file__).parent.parent
        doc = parse_srt_path_v3(str(root / "source_srt" / "1(4).srt"))
        selections = json.loads((root / "test_data" / "r6_conversion_1_4_selection.json").read_text(encoding="utf-8"))
        review_data = json.loads((root / "test_data" / "r6_conversion_1_4_semantic_review.json").read_text(encoding="utf-8"))
        plan = validate_and_plan_groups(doc, selections["1(4).srt"])
        semantic = validate_semantic_review(doc, plan, review_data["1(4).srt"])
        manifest = build_verified_manifest(doc, plan)
        self.assertTrue(manifest["all_pass"])
        self.assertTrue(semantic["all_pass"], semantic["errors"])
        self.assertEqual(plan["selected_count"], 41)
        self.assertEqual(len(plan["groups"]), 7)
        self.assertEqual(plan["total_planned_span_ms"], 49799)
        self.assertEqual(semantic["conversion_flow"]["payoff_group_no"], 1)
        self.assertEqual(semantic["conversion_flow"]["cta_group_no"], 7)

    def test_timestamp_integer_math(self):
        self.assertEqual(timestamp_to_ms("01:02:03,456"), 3723456)
        self.assertEqual(format_ms_dot(3723456), "01:02:03.456")

    def test_path_parser_rejects_non_srt_files(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "not-a-subtitle.txt"
            p.write_text("1\n00:00:00,000 --> 00:00:01,000\nA", encoding="utf-8")
            with self.assertRaises(ValueError):
                parse_srt_path_v3(str(p))

    def test_parser_reads_path_once(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "once.srt"
            p.write_text("1\n00:00:00,000 --> 00:00:01,000\nA", encoding="utf-8")
            original = Path.read_bytes
            calls = []
            def counted(path):
                calls.append(str(path))
                return original(path)
            with patch.object(Path, "read_bytes", counted):
                doc = parse_srt_path_v3(str(p))
            self.assertEqual(len(calls), 1)
            self.assertEqual(doc["total_entries"], 1)


    def test_verified_manifest_is_single_canonical_source_for_third_and_fifth_surfaces(self):
        fixture = (
            "001\n00:00:00,000 --> 00:00:01,000\nA\n\n"
            "002\n00:00:01,000 --> 00:00:02,500\nB"
        )
        doc = self.fixture_doc(fixture, "manifest.srt")
        plan = validate_and_plan_groups(doc, [[1, 2]])
        manifest = build_verified_manifest(doc, plan)
        self.assertTrue(manifest["all_pass"])
        self.assertEqual(manifest["serials"], "001,002")
        self.assertEqual(manifest["selected_count"], 2)
        self.assertEqual(manifest["groups"][0]["timeline_end_ms"], 2500)
        self.assertEqual(manifest["entries"][1]["original_text"], "B")
        self.assertEqual(len(manifest["manifest_id"]), 64)
        fifth = render_fifth_section(doc, plan)
        self.assertEqual(fifth["verified_manifest_id"], manifest["manifest_id"])
        self.assertEqual(fifth["absolute_final_line"], manifest["serials"])

    def test_verified_manifest_resolves_source_only_once_on_success(self):
        import srt_v3_engine as engine
        fixture = (
            "1\n00:00:00,000 --> 00:00:01,000\nA\n\n"
            "2\n00:00:01,000 --> 00:00:02,000\nB"
        )
        doc = self.fixture_doc(fixture, "single-gate.srt")
        plan = validate_and_plan_groups(doc, [[1, 2]])
        original = engine.resolve_plan_entries_from_source
        calls = []
        def counted(d, p):
            calls.append(1)
            return original(d, p)
        with patch.object(engine, "resolve_plan_entries_from_source", counted):
            manifest = engine.build_verified_manifest(doc, plan)
        self.assertTrue(manifest["all_pass"])
        self.assertEqual(len(calls), 1)

    def test_compact_intermediate_carries_gaps_duplicate_fingerprint_and_numeric_risk(self):
        fixture = (
            "1\n00:00:00,000 --> 00:00:01,000\n85的羊毛\n\n"
            "2\n00:00:01,500 --> 00:00:02,000\n85 的羊毛"
        )
        doc = self.fixture_doc(fixture, "compact.srt")
        compact = build_compact_intermediate(doc)
        self.assertEqual(compact["row_count"], 2)
        self.assertEqual(compact["rows"][0]["gap_after_ms"], 500)
        self.assertEqual(compact["rows"][1]["gap_before_ms"], 500)
        self.assertEqual(compact["rows"][0]["text_fingerprint"], compact["rows"][1]["text_fingerprint"])
        self.assertEqual(compact["rows"][0]["exact_duplicate_count"], 2)
        self.assertIn("material_composition", compact["rows"][0]["critical_numeric_categories"])

    def test_target_slice_limits_model_facing_rows_to_target_plus_context(self):
        fixture = "\n\n".join(
            f"{i}\n00:00:0{i-1},000 --> 00:00:0{i},000\nT{i}" for i in range(1, 6)
        )
        doc = self.fixture_doc(fixture, "slice.srt")
        target_keys = [doc["entries"][2]["source_key"]]
        result = build_target_slice(doc, target_keys, context_before=1, context_after=1)
        self.assertEqual(result["slice_start_block_ordinal"], 2)
        self.assertEqual(result["slice_end_block_ordinal"], 4)
        self.assertEqual(result["compact"]["row_count"], 3)
        self.assertEqual([r["index"] for r in result["compact"]["rows"]], [2, 3, 4])

    def test_task_state_can_resume_after_product_confirmation_without_reparse(self):
        fixture = (
            "1\n00:00:00,000 --> 00:00:01,000\nA\n\n"
            "2\n00:00:01,000 --> 00:00:02,000\nB"
        )
        doc = self.fixture_doc(fixture, "state.srt")
        state = create_task_state(doc)
        self.assertEqual(state["phase"], "parsed")
        updated = set_task_state_target(
            state, doc, "深藏青大衣", [doc["entries"][1]["source_key"]], context_before=0, context_after=0
        )
        self.assertEqual(updated["phase"], "target_confirmed")
        self.assertEqual(updated["target_product"], "深藏青大衣")
        self.assertEqual(updated["target_slice"]["compact"]["row_count"], 1)
        self.assertEqual(state["phase"], "parsed")

    def test_task_state_rejects_wrong_canonical_document(self):
        a = self.fixture_doc("1\n00:00:00,000 --> 00:00:01,000\nA", "a-state.srt")
        b = self.fixture_doc("1\n00:00:00,000 --> 00:00:01,000\nB", "b-state.srt")
        state = create_task_state(a)
        with self.assertRaises(ValueError):
            set_task_state_target(state, b, "B", [b["entries"][0]["source_key"]])

    def test_candidate_pool_compression_is_deterministic_and_bounded(self):
        candidates = [
            {"candidate_id": "a1", "source_keys": ["k1"], "semantic_cluster": "fit", "role": "opening_hook"},
            {"candidate_id": "a1dup", "source_keys": ["k1"], "semantic_cluster": "fit", "role": "opening_hook"},
            {"candidate_id": "a2", "source_keys": ["k2"], "semantic_cluster": "fit", "role": "opening_hook"},
            {"candidate_id": "a3", "source_keys": ["k3"], "semantic_cluster": "fit", "role": "opening_hook"},
            {"candidate_id": "a4", "source_keys": ["k4"], "semantic_cluster": "fit", "role": "opening_hook"},
            {"candidate_id": "b1", "source_keys": ["k5"], "semantic_cluster": "fabric", "role": "opening_hook"},
        ]
        result = compress_candidate_pool(candidates, per_cluster_limit=3, opening_limit=5)
        self.assertEqual([x["candidate_id"] for x in result["kept"]], ["a1", "a2", "a3", "b1"])
        reasons = {x["candidate_id"]: x["reason"] for x in result["dropped"]}
        self.assertEqual(reasons["a1dup"], "exact_source_duplicate")
        self.assertEqual(reasons["a4"], "cluster_limit")
        self.assertLessEqual(result["kept_count"], 5)

    def test_normalized_fingerprint_is_format_conservative(self):
        self.assertEqual(normalize_text_fingerprint("85 的羊毛！"), normalize_text_fingerprint("85的羊毛"))
        self.assertNotEqual(normalize_text_fingerprint("85的羊毛"), normalize_text_fingerprint("95的羊毛"))

    def test_r5_multi_window_target_slice_avoids_unrelated_middle_region(self):
        root = Path(__file__).parent.parent / "source_srt"
        doc = parse_srt_path_v3(str(root / "2(4).srt"))
        target_indices = list(range(12, 43)) + list(range(75, 90))
        target_keys = [doc["entries_by_index"][i][0]["source_key"] for i in target_indices]
        result = build_target_slice(doc, target_keys, context_before=1, context_after=1, merge_gap_blocks=2)
        self.assertEqual(doc["total_entries"], 89)
        self.assertEqual(result["window_count"], 2)
        self.assertEqual([(w["slice_start_block_ordinal"], w["slice_end_block_ordinal"]) for w in result["windows"]], [(11,43),(74,89)])
        self.assertEqual(result["slice_row_count"], 49)
        self.assertAlmostEqual(result["reduction_ratio"], 40/89, places=6)
        self.assertNotIn(doc["entries_by_index"][60][0]["source_key"], result["slice_source_keys"])

    def test_r5_compact_intermediate_flags_question_context_without_auto_exclusion(self):
        root = Path(__file__).parent.parent / "source_srt"
        doc = parse_srt_path_v3(str(root / "2(4).srt"))
        keys = [doc["entries_by_index"][i][0]["source_key"] for i in (13, 15, 22, 24)]
        compact = build_compact_intermediate(doc, keys)
        by_index = {row["index"]: row for row in compact["rows"]}
        for idx in (13, 15, 22):
            self.assertTrue(by_index[idx]["question_like"])
            self.assertTrue(by_index[idx]["context_dependency_hint"])
        self.assertFalse(by_index[24]["question_like"])
        self.assertEqual(compact["row_count"], 4)

    def test_r5_candidate_compressor_drops_only_safe_same_cluster_surface_repeat(self):
        root = Path(__file__).parent.parent / "source_srt"
        doc = parse_srt_path_v3(str(root / "2(4).srt"))
        key = lambda i: doc["entries_by_index"][i][0]["source_key"]
        candidates = [
            {"candidate_id":"c86", "source_keys":[key(86)], "semantic_cluster":"浅米推荐", "role":"core_value"},
            {"candidate_id":"c87", "source_keys":[key(87)], "semantic_cluster":"浅米推荐", "role":"core_value"},
            {"candidate_id":"c88", "source_keys":[key(88)], "semantic_cluster":"浅米推荐", "role":"core_value"},
        ]
        result = compress_candidate_pool(candidates, doc=doc, near_duplicate_threshold=0.80)
        kept = [x["candidate_id"] for x in result["kept"]]
        reasons = {x["candidate_id"]: x["reason"] for x in result["dropped"]}
        self.assertIn("c86", kept)
        self.assertIn("c87", kept)  # contains 现货, mechanically protected
        self.assertEqual(reasons.get("c88"), "surface_near_duplicate")

    def test_r5_candidate_compressor_never_auto_drops_question_like_candidate_as_repeat(self):
        fixture = (
            "1\n00:00:00,000 --> 00:00:01,000\n什么颜色多一点\n\n"
            "2\n00:00:01,000 --> 00:00:02,000\n什么颜色多一点呢"
        )
        doc = self.fixture_doc(fixture, "questions.srt")
        candidates = [
            {"candidate_id":"q1", "source_keys":[doc["entries"][0]["source_key"]], "semantic_cluster":"颜色", "role":"core_value"},
            {"candidate_id":"q2", "source_keys":[doc["entries"][1]["source_key"]], "semantic_cluster":"颜色", "role":"core_value"},
        ]
        result = compress_candidate_pool(candidates, doc=doc, near_duplicate_threshold=0.5)
        self.assertEqual(result["kept_count"], 2)
        self.assertTrue(all(x["mechanical_flags"]["question_like"] for x in result["kept"]))

    def test_r5_embedded_frozen_format_contract_is_valid(self):
        self.assertTrue(validate_embedded_format_contract())
        self.assertEqual(len(FROZEN_FORMAT_CONTRACT_SHA256), 64)

    def test_r5_third_and_fifth_render_reuse_one_supplied_manifest_without_second_source_resolve(self):
        import srt_v3_engine as engine
        fixture = (
            "5\n00:00:10,000 --> 00:00:11,000\n开头原话\n\n"
            "6\n00:00:11,000 --> 00:00:12,500\n第二句"
        )
        doc = self.fixture_doc(fixture, "one-manifest-render.srt")
        plan = validate_and_plan_groups(doc, [[5,6]])
        manifest = build_verified_manifest(doc, plan)
        with patch.object(engine, "resolve_plan_entries_from_source", side_effect=AssertionError("should not re-resolve")):
            third = engine.render_third_section(doc, plan, "测试", ["开头钩子"], verified_manifest=manifest)
            fifth = engine.render_fifth_section(doc, plan, verified_manifest=manifest)
        self.assertIn("三、最佳成片方案", third)
        self.assertEqual(fifth["verified_manifest_id"], manifest["manifest_id"])

    def test_r5_task_state_rejects_digest_drift_even_if_file_id_and_sha_are_forged_equal(self):
        a = self.fixture_doc("1\n00:00:00,000 --> 00:00:01,000\nA", "state-a.srt")
        state = create_task_state(a)
        altered = dict(a)
        altered["entries"] = [dict(a["entries"][0], source_key=a["entries"][0]["source_key"] + "x")]
        altered["entries_by_index"] = {1:[altered["entries"][0]]}
        with self.assertRaises(ValueError):
            set_task_state_target(state, altered, "A", [altered["entries"][0]["source_key"]])


    def test_r5_model_review_bundle_omits_source_keys_from_model_payload_and_resolves_safely(self):
        root = Path(__file__).parent.parent / "source_srt"
        doc = parse_srt_path_v3(str(root / "2(4).srt"))
        target_indices = list(range(1,43)) + list(range(63,68)) + list(range(75,90))
        target_keys = [doc["entries_by_index"][i][0]["source_key"] for i in target_indices]
        target_slice = build_target_slice(doc, target_keys, context_before=1, context_after=1, merge_gap_blocks=2)
        bundle = build_model_review_bundle(doc, target_slice)
        payload_text = json.dumps(bundle["payload"], ensure_ascii=False)
        self.assertNotIn("source_key", payload_text)
        self.assertNotIn(doc["entries"][0]["source_key"], payload_text)
        self.assertNotIn('"s":', payload_text)
        self.assertNotIn('"e":', payload_text)
        self.assertEqual(bundle["schema"], "srt_v3_model_review_bundle_v2")
        self.assertEqual(len(bundle["payload"]["rows"]), 66)
        refs = [bundle["payload"]["rows"][0]["r"], bundle["payload"]["rows"][-1]["r"]]
        keys = resolve_model_cue_refs(doc, bundle, refs, bundle_id=bundle["payload"]["b"])
        self.assertEqual(keys[0], target_slice["slice_source_keys"][0])
        self.assertEqual(keys[-1], target_slice["slice_source_keys"][-1])

    def test_r5_model_review_bundle_rejects_wrong_bundle_id(self):
        doc = self.fixture_doc("1\n00:00:00,000 --> 00:00:01,000\nA", "bundle.srt")
        bundle = build_model_review_bundle(doc)
        with self.assertRaises(ValueError):
            resolve_model_cue_refs(doc, bundle, ["c001"], bundle_id="wrong")

    def test_r5_candidate_cue_refs_resolve_before_compression(self):
        fixture = (
            "1\n00:00:00,000 --> 00:00:01,000\n浅米色很优秀\n\n"
            "2\n00:00:01,000 --> 00:00:02,000\n我觉得这个浅米色很优秀啊"
        )
        doc = self.fixture_doc(fixture, "bundle-candidates.srt")
        bundle = build_model_review_bundle(doc)
        candidates = [
            {"candidate_id":"a", "cue_refs":["c001"], "semantic_cluster":"浅米", "role":"core_value"},
            {"candidate_id":"b", "cue_refs":["c002"], "semantic_cluster":"浅米", "role":"core_value"},
        ]
        resolved = resolve_candidate_cue_refs(doc, bundle, candidates)
        self.assertTrue(all("source_keys" in row for row in resolved))
        compressed = compress_candidate_pool(resolved, doc=doc, near_duplicate_threshold=0.8)
        self.assertEqual(compressed["kept_count"], 1)
        self.assertEqual(compressed["dropped"][0]["reason"], "surface_near_duplicate")


    def test_r5_real_2_4_previous_delivery_plan_remains_exact(self):
        root = Path(__file__).parent.parent / "source_srt"
        doc = parse_srt_path_v3(str(root / "2(4).srt"))
        groups = [
            list(range(36,43)), list(range(75,80)), list(range(12,25)),
            list(range(83,89)), list(range(33,36)), [82],
        ]
        plan = validate_and_plan_groups(doc, groups)
        manifest = build_verified_manifest(doc, plan)
        self.assertTrue(manifest["all_pass"])
        self.assertEqual(plan["selected_count"], 35)
        self.assertEqual(len(plan["groups"]), 6)
        self.assertEqual(plan["total_planned_span_ms"], 45333)
        self.assertEqual(
            manifest["serials"],
            "36,37,38,39,40,41,42,75,76,77,78,79,12,13,14,15,16,17,18,19,20,21,22,23,24,83,84,85,86,87,88,33,34,35,82",
        )


    def _batch_fixture_docs(self, count=3, same_name=False, identical_text=False):
        docs = []
        for i in range(1, count + 1):
            text_value = "同一商品" if identical_text else f"商品{i}"
            fixture = (
                f"1\n00:00:00,000 --> 00:00:01,000\n{text_value} 开头\n\n"
                f"2\n00:00:01,000 --> 00:00:02,000\n{text_value} 卖点"
            )
            name = "same.srt" if same_name else f"batch{i}.srt"
            doc = parse_srt_bytes_v3(fixture.encode("utf-8"), name, file_id=f"/batch/{i}/{name}")
            docs.append(doc)
        return assign_document_keys(docs)

    def test_r7_batch_case1_two_single_product_files_auto_ready(self):
        docs = self._batch_fixture_docs(2)
        manifest = build_batch_manifest(docs)
        scans = {}
        for i, doc in enumerate(docs, start=1):
            scans[f"f{i:02d}"] = {"products": [{
                "name": f"商品{i}", "classification": "independent_sales",
                "source_keys": [e["source_key"] for e in doc["entries"]],
            }]}
        routed = apply_batch_product_scan(manifest, docs, scans)
        self.assertEqual([r["route_state"] for r in routed["files"]], ["READY", "READY"])
        self.assertEqual(routed["phase"], "routed")
        self.assertFalse(build_batch_confirmation_request(routed)["needs_confirmation"])

    def test_r8_batch_case2_same_serials_use_scope_once_local_cue_refs(self):
        docs = self._batch_fixture_docs(3, identical_text=True)
        manifest = build_batch_manifest(docs)
        scans = {}
        for i, doc in enumerate(docs, start=1):
            scans[f"f{i:02d}"] = {"products": [{
                "name": "同一商品", "classification": "independent_sales",
                "source_keys": [e["source_key"] for e in doc["entries"]],
            }]}
        routed = apply_batch_product_scan(manifest, docs, scans)
        scoped_refs = []
        bundles = []
        for i in range(1, 4):
            slot = f"f{i:02d}"
            bundle = build_batch_model_review_bundle(routed, docs, slot)
            bundles.append(bundle)
            file_refs = [row["r"] for row in bundle["payload"]["rows"]]
            self.assertEqual(bundle["payload"]["s"], slot)
            self.assertEqual(bundle["internal"]["cue_ref_scope"], "file_local")
            self.assertTrue(all(ref.startswith("c") and "_" not in ref for ref in file_refs))
            scoped_refs.extend((slot, ref) for ref in file_refs)
        self.assertEqual(len(scoped_refs), len(set(scoped_refs)))
        # A local cue ref from f01 cannot be resolved under f02 because the bundle/file identity is checked.
        with self.assertRaises(ValueError):
            resolve_batch_model_cue_refs(routed, docs, "f02", bundles[0], ["c001"])


    def test_r8_batch_scope_once_payload_is_smaller_than_r7_namespaced_rows(self):
        root = Path(__file__).resolve().parents[1]
        doc = parse_srt_path_v3(root / "source_srt" / "10月29日(1).srt")
        docs = assign_document_keys([doc])
        manifest = build_batch_manifest(docs)
        scans = {"f01": {"products": [{
            "name": "361度速干裤",
            "classification": "independent_sales",
            "source_keys": [e["source_key"] for e in doc["entries"]],
        }]}}
        routed = apply_batch_product_scan(manifest, docs, scans)
        r8 = build_batch_model_review_bundle(routed, docs, "f01")
        target_slice = routed["files"][0]["task_state"]["target_slice"]
        r7_simulated = build_model_review_bundle(
            doc, target_slice, cue_ref_prefix="f01_",
            batch_id=routed["batch_id"], file_slot="f01",
        )
        compact = lambda payload: len(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
        r8_bytes = compact(r8["payload"])
        r7_bytes = compact(r7_simulated["payload"])
        self.assertLess(r8_bytes, r7_bytes)
        self.assertGreater((r7_bytes - r8_bytes) / r7_bytes, 0.05)
        self.assertEqual(r8["payload"]["rows"][0]["r"], "c001")
        self.assertEqual(r8["payload"]["s"], "f01")

    def test_r8_resolver_keeps_r7_namespaced_bundle_backward_compatible(self):
        docs = self._batch_fixture_docs(1)
        manifest = build_batch_manifest(docs)
        scans = {"f01": {"products": [{
            "name": "A", "classification": "independent_sales",
            "source_keys": [e["source_key"] for e in docs[0]["entries"]],
        }]}}
        routed = apply_batch_product_scan(manifest, docs, scans)
        target_slice = routed["files"][0]["task_state"]["target_slice"]
        legacy = build_model_review_bundle(
            docs[0], target_slice, cue_ref_prefix="f01_",
            batch_id=routed["batch_id"], file_slot="f01",
        )
        keys = resolve_batch_model_cue_refs(routed, docs, "f01", legacy, ["f01_c001"])
        self.assertEqual(keys, [docs[0]["entries"][0]["source_key"]])

    def test_r7_batch_case3_duplicate_filenames_do_not_overwrite(self):
        docs = self._batch_fixture_docs(2, same_name=True, identical_text=True)
        manifest = build_batch_manifest(docs)
        self.assertTrue(validate_batch_manifest_identity(manifest, docs))
        self.assertEqual([r["file_slot"] for r in manifest["files"]], ["f01", "f02"])
        self.assertEqual(len({r["document_key"] for r in manifest["files"]}), 2)
        self.assertEqual(len({r["file_id"] for r in manifest["files"]}), 2)

    def test_r7_batch_case4_only_ambiguous_file_requests_confirmation(self):
        docs = self._batch_fixture_docs(3)
        manifest = build_batch_manifest(docs)
        scans = {
            "f01": {"products": [{"name":"A", "classification":"independent_sales", "source_keys":[e["source_key"] for e in docs[0]["entries"]]}]},
            "f02": {"products": [
                {"name":"B1", "classification":"independent_sales", "source_keys":[docs[1]["entries"][0]["source_key"]]},
                {"name":"B2", "classification":"independent_sales", "source_keys":[docs[1]["entries"][1]["source_key"]]},
            ]},
            "f03": {"products": [{"name":"C", "classification":"independent_sales", "source_keys":[e["source_key"] for e in docs[2]["entries"]]}]},
        }
        routed = apply_batch_product_scan(manifest, docs, scans)
        self.assertEqual([r["route_state"] for r in routed["files"]], ["READY", "WAITING_PRODUCT_SELECTION", "READY"])
        request = build_batch_confirmation_request(routed)
        self.assertTrue(request["needs_confirmation"])
        self.assertEqual([x["file_slot"] for x in request["files"]], ["f02"])
        self.assertEqual([p["name"] for p in request["files"][0]["products"]], ["B1", "B2"])

    def test_r7_batch_case5_requested_target_routes_found_not_found_and_unique_match(self):
        docs = self._batch_fixture_docs(3)
        manifest = build_batch_manifest(docs)
        scans = {
            "f01": {"products": [{"name":"羽绒服", "classification":"independent_sales", "matches_requested_target":True, "source_keys":[e["source_key"] for e in docs[0]["entries"]]}]},
            "f02": {"products": [{"name":"毛衣", "classification":"independent_sales", "matches_requested_target":False, "source_keys":[e["source_key"] for e in docs[1]["entries"]]}]},
            "f03": {"products": [
                {"name":"羽绒服", "classification":"independent_sales", "matches_requested_target":True, "source_keys":[docs[2]["entries"][0]["source_key"]]},
                {"name":"半身裙", "classification":"independent_sales", "matches_requested_target":False, "source_keys":[docs[2]["entries"][1]["source_key"]]},
            ]},
        }
        routed = apply_batch_product_scan(manifest, docs, scans, requested_target="羽绒服")
        self.assertEqual([r["route_state"] for r in routed["files"]], ["READY", "TARGET_NOT_FOUND", "READY"])
        self.assertEqual(routed["files"][2]["target_product"], "羽绒服")
        self.assertEqual(len(routed["files"][2]["target_source_keys"]), 1)

    def test_r7_batch_case6_identical_text_and_serials_cannot_cross_attach_manifest(self):
        docs = self._batch_fixture_docs(2, identical_text=True)
        manifest = build_batch_manifest(docs)
        scans = {}
        for i, doc in enumerate(docs, start=1):
            scans[f"f{i:02d}"] = {"products": [{
                "name":"同一商品", "classification":"independent_sales",
                "source_keys":[e["source_key"] for e in doc["entries"]],
            }]}
        routed = apply_batch_product_scan(manifest, docs, scans)
        plan1 = validate_and_plan_groups(docs[0], [[1,2]])
        verified1 = build_verified_manifest(docs[0], plan1)
        attached = attach_batch_verified_manifest(routed, docs, "f01", verified1)
        self.assertEqual(attached["files"][0]["final_gate_state"], "PASS")
        with self.assertRaises(ValueError):
            attach_batch_verified_manifest(routed, docs, "f02", verified1)

    def test_r7_batch_case7_relation_hint_never_merges_files(self):
        docs = self._batch_fixture_docs(2)
        manifest = build_batch_manifest(docs)
        scans = {
            "f01": {"relation_hint":"POSSIBLE_CONTINUOUS_SEGMENT", "products":[{"name":"A", "classification":"independent_sales", "source_keys":[e["source_key"] for e in docs[0]["entries"]]}]},
            "f02": {"relation_hint":"POSSIBLE_CONTINUOUS_SEGMENT", "products":[{"name":"A", "classification":"independent_sales", "source_keys":[e["source_key"] for e in docs[1]["entries"]]}]},
        }
        routed = apply_batch_product_scan(manifest, docs, scans)
        self.assertEqual([r["relation_hint"] for r in routed["files"]], ["POSSIBLE_CONTINUOUS_SEGMENT"] * 2)
        b1 = build_batch_model_review_bundle(routed, docs, "f01")
        b2 = build_batch_model_review_bundle(routed, docs, "f02")
        k1 = set(b1["internal"]["ref_to_source_key"].values())
        k2 = set(b2["internal"]["ref_to_source_key"].values())
        self.assertTrue(k1.isdisjoint(k2))

    def test_r7_batch_case8_structure_error_isolated_to_one_file(self):
        good1 = self.fixture_doc("1\n00:00:00,000 --> 00:00:01,000\nA", "good1.srt")
        bad = self.fixture_doc("1\n00:00:02,000 --> 00:00:01,000\nBAD", "bad.srt")
        good2 = self.fixture_doc("1\n00:00:00,000 --> 00:00:01,000\nC", "good2.srt")
        docs = assign_document_keys([good1, bad, good2])
        manifest = build_batch_manifest(docs)
        scans = {
            "f01":{"products":[{"name":"A","classification":"independent_sales","source_keys":[good1["entries"][0]["source_key"]]}]},
            "f02":{"products":[{"name":"BAD","classification":"independent_sales","source_keys":[bad["entries"][0]["source_key"]]}]},
            "f03":{"products":[{"name":"C","classification":"independent_sales","source_keys":[good2["entries"][0]["source_key"]]}]},
        }
        routed = apply_batch_product_scan(manifest, docs, scans)
        self.assertEqual([r["route_state"] for r in routed["files"]], ["READY", "STRUCTURE_WARNING", "READY"])
        self.assertEqual(routed["files"][1]["target_status"], "BLOCKED_BY_STRUCTURE")

    def test_r7_batch_case9_hot_path_confirmation_does_not_reparse_or_rescan(self):
        import srt_v3_engine as engine
        docs = self._batch_fixture_docs(2)
        manifest = build_batch_manifest(docs)
        scans = {
            "f01": {"products":[{"name":"A","classification":"independent_sales","source_keys":[e["source_key"] for e in docs[0]["entries"]]}]},
            "f02": {"products":[
                {"name":"B1","classification":"independent_sales","source_keys":[docs[1]["entries"][0]["source_key"]]},
                {"name":"B2","classification":"independent_sales","source_keys":[docs[1]["entries"][1]["source_key"]]},
            ]},
        }
        routed = apply_batch_product_scan(manifest, docs, scans)
        with patch.object(engine, "parse_srt_path_v3", side_effect=AssertionError("must not reparse")):
            confirmed = set_batch_file_target(
                routed, docs, "f02", "B2", [docs[1]["entries"][1]["source_key"]],
                context_before=0, context_after=0,
            )
        self.assertEqual(confirmed["files"][0]["route_state"], "READY")
        self.assertEqual(confirmed["files"][1]["route_state"], "READY")
        self.assertEqual(confirmed["files"][1]["task_state"]["target_slice"]["slice_row_count"], 1)

    def test_r7_batch_case10_each_file_uses_own_verified_manifest_for_output(self):
        docs = self._batch_fixture_docs(2)
        manifest = build_batch_manifest(docs)
        scans = {}
        for i, doc in enumerate(docs, start=1):
            scans[f"f{i:02d}"] = {"products":[{
                "name":f"商品{i}", "classification":"independent_sales",
                "source_keys":[e["source_key"] for e in doc["entries"]],
            }]}
        routed = apply_batch_product_scan(manifest, docs, scans)
        attached = routed
        ids = []
        for i, doc in enumerate(docs, start=1):
            plan = validate_and_plan_groups(doc, [[1,2]])
            verified = build_verified_manifest(doc, plan)
            third = render_third_section(doc, plan, f"商品{i}", ["开头钩子"], verified_manifest=verified)
            fifth = render_fifth_section(doc, plan, verified_manifest=verified)
            self.assertIn(doc["entries"][0]["original_text"], third)
            self.assertEqual(fifth["absolute_final_line"], "1,2")
            attached = attach_batch_verified_manifest(attached, docs, f"f{i:02d}", verified)
            ids.append(verified["manifest_id"])
        self.assertNotEqual(ids[0], ids[1])
        self.assertEqual([r["final_gate_state"] for r in attached["files"]], ["PASS", "PASS"])
        self.assertEqual(attached["phase"], "completed")

    def test_r7_batch_cli_emits_manifest_and_confirmation_without_changing_single_file_default(self):
        engine_path = Path(__file__).parent.parent / "src" / "srt_v3_engine.py"
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            a = root / "a.srt"
            b = root / "b.srt"
            a.write_text("1\n00:00:00,000 --> 00:00:01,000\nA", encoding="utf-8")
            b.write_text("1\n00:00:00,000 --> 00:00:01,000\nB", encoding="utf-8")
            normal = subprocess.run([sys.executable, "-S", str(engine_path), str(a)], capture_output=True, text=True)
            self.assertEqual(normal.returncode, 0)
            self.assertNotIn("batch_manifest", json.loads(normal.stdout))
            batch = subprocess.run([sys.executable, "-S", str(engine_path), str(a), str(b), "--emit-batch-manifest"], capture_output=True, text=True)
            self.assertEqual(batch.returncode, 0, batch.stderr)
            payload = json.loads(batch.stdout)
            self.assertEqual(payload["support_package_revision"], "R8")
            self.assertEqual(payload["batch_manifest"]["file_count"], 2)
            self.assertFalse(payload["batch_confirmation"]["needs_confirmation"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
