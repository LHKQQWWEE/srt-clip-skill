# SRT切片文案 V3.0｜多SRT Batch Router R7

STATUS: HISTORICAL SUPPORT PACKAGE R7｜已被R8取代｜业务版本仍为V3.0

## 目标
R7只增强一次输入多个SRT时的批次入口、文件隔离、商品确认路由与HOT PATH状态复用。不会把多个SRT拼成一个大文件，不改变单SRT成交编排，不修改五部分结构、第三部分冻结格式、45–90秒时长门槛、R6成交角色、multi-window、source_key或Final Gate。

## 新增确定性能力
- `build_batch_manifest()`：按上传顺序建立`f01/f02/...`文件槽位，绑定document_key、file_id、filename、SHA-256与canonical source-key摘要。
- `apply_batch_product_scan()`：消费助手完成的一次轻量商品/换款扫描；Python只校验来源并路由，不自动推断商品语义。
- 单商品文件自动READY；多商品文件只进入一次`WAITING_PRODUCT_SELECTION`；已明确文件不重复询问。
- 用户预先指定全局目标时，由助手在轻扫结果标记`matches_requested_target`；程序只执行确定性FOUND/NOT_FOUND/AMBIGUOUS路由。
- `set_batch_file_target()`：用户确认后只更新对应文件task_state并构建multi-window target slice，不重读SRT、不重解析、不重扫其它文件。
- `build_batch_model_review_bundle()`：多文件语义阶段使用`f01_c001`、`f02_c001`等带文件命名空间的短cue_ref；单SRT默认bundle仍保持R6的`c001`形式与同等载荷大小。
- `resolve_batch_model_cue_refs()`：回映前同时校验batch_id、file_slot、bundle_id、file_id、filename、SHA-256与canonical索引。
- `attach_batch_verified_manifest()`：Final Gate仍逐文件独立；禁止把另一SRT的verified_manifest或source_key挂入当前文件。
- `relation_hint`只作提示；即便识别为`POSSIBLE_CONTINUOUS_SEGMENT`，用户未明确要求合并时仍保持FILE ISOLATION。

## 错误隔离
一个文件结构异常只标记该文件`STRUCTURE_WARNING`；其它文件保留READY/HOT PATH状态。一个文件Final Gate失败不会要求其它文件重新读取或重新解析。

## 单SRT非回归
单SRT默认CLI不创建或输出Batch manifest。R7在单文件默认路径上不增加Batch Router输出；既有模型payload行结构与3746-byte测试样本大小保持不变，仅bundle身份哈希因支持包修订号变化而自然变化。

## 真实六文件批次路由回归
使用现有人工商品边界记录复用六份真实SRT：
- `10月26日 (1).srt`：单商品，加绒宽松/阔腿牛仔裤 → READY。
- `10月28日(1).srt`：多商品 → WAITING_PRODUCT_SELECTION。
- `10月28日(2).srt`：多商品 → WAITING_PRODUCT_SELECTION。
- `10月29日(1).srt`：单商品，361度速干裤 → READY。
- `10月30日(1).srt`：多商品 → WAITING_PRODUCT_SELECTION。
- `1(4).srt`：深藏青羊毛大衣 + 日本进口直筒裤 → WAITING_PRODUCT_SELECTION。

Batch confirmation只包含4份未决文件；2份单商品文件不重复确认。

## 版本治理
R7是V3.0程序支持修订，不是V3.1。R6及更早支持包归档勿执行；业务规则权威顺序与FAST-PATH 2.0不变。


> R8现行覆盖：行级`f01_c001`已优化为bundle顶层一次`s=f01` + 行级`c001`，安全身份链不变。详见`BATCH_SCOPE_OPTIMIZATION_R8.md`。
