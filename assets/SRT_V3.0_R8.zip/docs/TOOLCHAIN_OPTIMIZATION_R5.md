# SRT切片文案 V3.0｜工具链效率优化 R5

STATUS: ACTIVE SUPPORT PACKAGE R5｜业务版本仍为V3.0，不升级V3.1｜Runtime仍FAST-PATH 2.0

## 目标
R5针对R4首次真实任务`2(4).srt`暴露出的三个问题优化：单连续target slice吞入无关中间区段、模型载荷仍包含大量长source_key/重复时间字段、格式审计触发第二次Drive读取。所有改动仅限工具层，不改变五部分、第三部分冻结格式、source_key硬核验、商品语义判断、开头三标准或原话保真。

## 1. Multi-window target slice
`build_target_slice()`由R4的min(target)→max(target)单窗口，升级为多个离散窗口。目标source_key先按block ordinal分组，再只对近邻窗口合并，并分别添加有界上下文。

`2(4).srt`生产口径按完整商品归属保留1–42、63–67、75–89：
- R4：最小/最大范围扩展后89/89条；
- R5：窗口1–43、62–68、74–89，共66/89条；
- 行数减少25.843%。

程序本身的multi-window构建会比单min/max多约1ms级机械开销，但目标是减少后续模型语义输入，而不是追求Python函数本身更快。

## 2. 短cue_ref模型载荷
新增`build_model_review_bundle()`：
- 模型只看到`c001/c002...`短引用、原始序号、原始起止时间、原文、必要表面标记/数字风险；
- 长`source_key`、file identity和cue_ref映射留在工具内部；
- 模型返回cue_ref后通过`resolve_model_cue_refs()`校验bundle_id、file_id、filename、SHA-256并回映canonical source_key；
- `resolve_candidate_cue_refs()`在候选压缩前统一转换为source_key。

`2(4).srt`相同生产窗口：R4 compact JSON约34,194 bytes；R5模型payload约6,254 bytes，减少81.710%。这只是序列化输入体积，不是模型token或端到端时间的直接等价值。

## 3. 表面重复与问句/碎片预标记
`build_compact_intermediate()`新增：
- `question_like`：仅依据问号/疑问表面词；
- `context_dependency_hint`：问句或极短指示型碎片；
- `surface_repeat_group`：仅相邻、短时间间隔、高表面相似的重复提示。

这些标记不自动删除字幕。`compress_candidate_pool(..., doc=...)`仅在助手已经给出相同`semantic_cluster + role`的前提下，且不存在关键数字、交易词、问句或显式保护标记时，才允许把高相似候选标为`surface_near_duplicate`。

真实例：2(4)的86与88相似度0.9091，88可作为重复候选剔除；87含“现货”，被交易词保护保留。

## 4. 冻结格式本地化
V3.0第三部分和第五部分机器模板嵌入引擎，固定机器契约SHA-256：
`25c49cac6254299842351c8f4e668a561e2da531e77e4e8a2d7c9d26f392973c`

`validate_embedded_format_contract()`在渲染前自检。正常日常任务不再为了字段/标点读取Drive冻结契约；只有hash异常、规则冲突、审计/升级才读取原Drive契约。原`docs/FORMAT_CONTRACT.md`未修改。

## 5. 同一manifest渲染
`render_third_section()`与`render_fifth_section()`新增可选`verified_manifest`参数。已由Final Gate生成manifest时，两部分直接复用，不再重复canonical source resolve。传入manifest仍会校验file identity、SHA、source_key播放序列、count/serials和manifest identity hash。

## 6. 2(4).srt真实回归
- 89条，UTF-8，结构诊断通过；与`2(1).srt`SHA相同，但按独立文件身份处理。
- 原R4交付计划35条/6组/45.333秒，在R5 verified_manifest中继续all_pass=true。
- R5第三部分与R4逐字一致；最终序号完全一致。
- 问句提示：13、15、22为question/context-dependent；24不是问句。
- multi-window与short cue_ref不改变canonical索引、计划或Final Gate。

## 7. 回归
- 单元测试66/66；R4原55项全部通过，新增11项R5专项。
- 9份基准SRT文件身份/2,120条字幕/6份主CLI方案通过。
- B组1(5) 38条/5组通过。
- 1(4) semantic review all_pass=true。
- 2(4) 35条/6组通过。

## 8. 指标纪律
不得将25.843% slice行数减少或81.710% JSON字节减少直接宣传为端到端同等提速。实际用户体感仍由模型推理、Drive启动读取、上下文长度、客户端渲染等组成，需继续用真实任务测量。
