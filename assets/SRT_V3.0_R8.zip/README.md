# srt切片文案 V3.0｜正式开发与回归素材包

STATUS: SUPPORT PACKAGE R8｜ACTIVE BUSINESS VERSION: V3.0｜正式触发词：`srt切片文案`

本包用于V3.0程序实现、回归追溯与审计，不替代Google Drive中的V3.0完整项目规则、专项执行卡或固定交付格式冻结契约。日常执行必须遵循现行总控路由与V3.0专项执行卡。

## 内容
- `src/srt_v3_engine.py`：严格SRT解码、一次读取、唯一索引、SHA-256、时间计算、原文/编号/时间/source key核验、源记录只读与候选副本隔离、按source_key回查渲染、片段组时间轴元数据核验、第三部分真实文本渲染、五部分契约校验，以及V3.0质量优化校验器。
- `tests/test_srt_v3_engine.py`：80项单元测试；保留R7全部78项并新增scope-once载荷压缩与R7 bundle兼容专项回归。
- `test_data/regression_selections.json`：三份基准、两份新增单商品样本及本次1(4).srt优化样本的候选组。
- `test_data/optimized_task_1_5_b_selection.json`：1(5).srt B组38条字幕、5组的专用来源映射回归选择。
- `test_data/sample_manifest_and_semantic_gate.json`：九份真实SRT样本清单及人工商品边界门禁记录。
- `test_data/optimized_task_1_4_selection.json`：1(4).srt本次优化后的独立成片选择。
- `test_data/optimized_task_1_4_semantic_review.json`：1(4).srt开头竞争、结尾竞争、关键数字复核及组合级质检记录。
- `test_data/v3_cli_regression_report.json`：九份唯一SRT、六份候选方案的完整CLI回归JSON报告。
- `test_data/optimized_task_1_5_b_cli_report.json`：B组单独CLI来源映射报告。
- `test_data/optimized_task_1_5_b_third_section_verified.txt`：由唯一source_key回查渲染的B组第三部分测试文本。
- `source_srt/`：九份基准SRT文件身份、1(5).srt别名回归副本，以及R5首次真实实测别名2(4).srt；2(4).srt与2(1).srt SHA-256相同，不增加独立字节样本。
- `docs/FORMAT_CONTRACT.md`：第三部分格式契约摘要（本次优化未修改）。
- `docs/QUALITY_OPTIMIZATION.md`：V3.0质量优化实施说明。
- `docs/REGRESSION_SUMMARY.md`：程序回归、商品门禁、1(4)专项回归和计时边界。
- `docs/SOURCE_MAPPING_FIX_20261101.md`：原始记录绑定、候选副本隔离和B组第94条时间码专项修复说明。
- `docs/TEST_RUN_20261101.txt`：R3历史测试记录。
- `docs/TOOLCHAIN_OPTIMIZATION_R4.md`：R4历史工具链效率优化说明。
- `docs/TOOLCHAIN_OPTIMIZATION_R5.md`：R5历史工具链效率说明。
- `docs/CONVERSION_OPTIMIZATION_R6.md`：R6跨品类成交编排与效率优化说明（R7继续继承）。
- `docs/BATCH_ROUTER_R7.md`：R7历史多SRT Batch Router、文件隔离与HOT PATH复用说明。
- `docs/BATCH_SCOPE_OPTIMIZATION_R8.md`：R8文件作用域单次发送、局部cue_ref与兼容/安全回归说明。
- `docs/TEST_RUN_R6_20261101.txt`：R6历史完整测试与A/B回归结果。
- `docs/TEST_RUN_R7_20261101.txt`：R7历史多SRT回归、单SRT非回归与性能观测。
- `docs/TEST_RUN_R8_20261101.txt` / `TEST_RUN_R8_UNITTEST_VERBOSE.txt`：R8 scope-once优化与80项单测记录。
- `docs/TEST_RUN_R4_20261101.txt`：R4历史测试结果。
- `docs/TEST_RUN_R5_20261101.txt`：R5 66项单测、主回归、B组、2(4)真实样本和输入体积测试。

## 测试命令
在包根目录运行：

```bash
python -S -m unittest discover -s tests -v
python -S src/srt_v3_engine.py source_srt/*.srt --selection-json test_data/regression_selections.json --semantic-review-json test_data/optimized_task_1_4_semantic_review.json --output-json /tmp/v3_cli_report.json
python -S src/srt_v3_engine.py 'source_srt/1(4).srt' --selection-json test_data/optimized_task_1_4_selection.json --semantic-review-json test_data/optimized_task_1_4_semantic_review.json --require-semantic-review --output-json /tmp/v3_1_4_report.json
python -S src/srt_v3_engine.py 'source_srt/1(5).srt' --selection-json test_data/optimized_task_1_5_b_selection.json --output-json test_data/optimized_task_1_5_b_cli_report.json
```

`--semantic-review-json`接收由助手完成的语义审查记录；Python只检查候选来源、审查完整性和硬约束，不自动判断商品语义或代替人工选择。需要强制每份选段文件都附语义审查时，增加`--require-semantic-review`。

## B组来源映射修复
- 候选计划与原始解析索引不再共享可变字幕对象；候选计划只保存独立副本。
- 最终展示逐条通过`source_key`回查原始字幕对象，不允许拆分来源列表拼装编号、时间码和文本。
- 起止时间方向、原始时间字符串与毫秒值、source_key、文件身份、组级源时间范围和成片时间轴均参与自动校验；任一错配阻断第三/第五部分渲染。

## V3.0质量优化
1. 开头钩子候选独立竞争：审查独立可理解性、商品锚点、衔接、上下文依赖；不合格候选不能被选为开头。
2. 结尾候选独立竞争：审查购买动作、交易信息可靠性、自然收束和商品锚点；没有可靠购买动作时不补造逼单。
3. 关键数字/材质/价格/尺码/优惠/库存候选拦截：程序只发现疑似数字候选；助手逐条审查。单位不完整的数字不能被擅自标准化；逐字保留时须标注疑点，排除/冲突项不得留在最终选择中。
4. 序号、数量和复制内容单一来源：最终播放顺序从片段组展开为唯一序列；字幕数、组数、原始序号、复制按钮payload、代码块和绝对末行均由同一序列生成并交叉核验。
5. 组合级最终复检：每组必须说明边际贡献；复核价格位置、商品边界、连续性、重复内容，并完成最终通读。

## 职责边界
Python只负责客观解析、结构诊断、索引、时间计算、原始编号/原文/时间/source key映射核验、序号数量/复制契约、审查记录完整性及CLI报告。商品边界、话语角色、语义去重、同类竞争、开头/结尾候选优劣、组合边际贡献和促单判断由助手结合完整SRT上下文完成；人工语义审查不得伪装成自动分类器。

程序解析/CLI耗时不等于端到端任务耗时。无独立金标准不宣称语义准确率；不推断视频/音频事实，不读取MP4或音频。

## 固定格式保护
五部分结构和第三部分格式契约保持原样。`docs/FORMAT_CONTRACT.md`本次未修改；质量优化不得增加、删除、重命名或调换第三部分字段。

## ZIP文件名编码
正式ZIP使用标准UTF-8文件名标记，中文SRT样本名在Windows、macOS和Linux解压后均应保持原名。包内不包含Python运行时`__pycache__`或`.pyc`文件。

## R4工具链效率优化（业务版本仍为V3.0）
- `build_verified_manifest()` 将来源回查、组级时间指标、成片时间轴、序号及复制payload合并为一次确定性Final Gate；第三/第五部分同源消费。
- `build_compact_intermediate()` / `build_target_slice()` 用于减少目标商品确认后的模型输入体积，商品边界仍由助手语义判断。
- `create_task_state()` / `set_task_state_target()` 为跨轮商品确认保存可验证的文件身份和目标区间状态，状态错配直接阻断复用。
- `compress_candidate_pool()` 只做机械去重与上限控制，语义簇和候选排序由助手提供。
- 日常CLI默认不展开完整verified_manifest或task state，审计时分别使用`--include-verified-manifest`和`--emit-task-state`。
- R4单元测试55/55通过；旧47项无回归。Final Gate微基准下降约46.4%，但完整CLI总耗时仅基本持平，因此不宣称端到端提速比例。


## R5工具链效率优化（业务版本仍为V3.0）
- `build_target_slice()`升级为multi-window：不再用目标字幕最早→最晚位置把中间无关区间整段带入深扫；窗口只在重叠或近邻时合并。
- 新增`build_model_review_bundle()`：语义阶段只发送短`cue_ref`（如c001）+原编号/时间/原文/必要标记；长`source_key`映射留在Python内部，模型返回后再用`resolve_model_cue_refs()`安全回映。
- `build_compact_intermediate()`新增表面问句、上下文依赖和相邻重复提示；这些只做审查提示，不自动判定商品语义或删除问句。
- `compress_candidate_pool(..., doc=...)`只在“助手已标同一semantic_cluster + 同一role”且无关键数字/交易词/问句保护时，删除高相似表面重复；唯一事实、购买动作和必要上下文可显式豁免。
- 冻结第三部分格式已嵌入引擎并带固定SHA-256自检；正常任务无需为了格式再读取Drive冻结契约。审计/冲突时才回读原契约。
- 第三/第五部分可显式传入同一`verified_manifest`渲染，避免渲染阶段再次canonical回查。
- `2(4).srt`生产口径实测：完整商品归属窗口使R4的89/89条连续slice降为R5的66/89条（-25.8%）；短cue_ref模型载荷由R4约34,194 bytes降为R5约6,254 bytes（-81.7%）。该指标是序列化输入体积，不等于端到端时间提速。
- 66/66单元测试通过；原R4 55项无回归；9份基准/6主方案、B组38条/5组、1(4)语义审查和2(4)35条/6组均通过。


## R6成交编排与效率优化（业务版本仍为V3.0）
- 不新增第二次全文扫描。多商品门禁继续先于商品专属深扫与成片编排。
- 在既有目标商品深扫中一次性标记：需求/痛点、核心结果、证明、适用、顾虑、交易理由、CTA，并用紧凑conversion-flow审查记录钩子兑现、相邻推进、边际价值与CTA终止。
- 开头从“信息强”升级为“目标用户代入 + 具体价值承诺 + 可快速兑现”；中段按购买决策推进而非卖点堆积；结尾优先形成“为什么买/为什么现在买/怎么下单”，CTA后截止。
- `build_model_review_bundle()`升级为v2：语义阶段不再重复携带start/end原时间字段；最终时间码仍由canonical source_key在Final Gate回查。2(4).srt同一66行目标slice，模型payload由6254 bytes降至3746 bytes（-40.102%），最终计划完全不变。
- 1(4).srt成交导向A/B：旧方案40条/8组/48.833秒；新方案41条/7组/49.799秒。新方案将“小个子对大衣偏大偏松的顾虑→适配结果”前置为钩子，并保持面料/触感证明、尺码顾虑、交易理由、CTA闭环；来源映射和语义审查均通过。
- R6单测67/67通过；既有CLI回归无来源/格式退化。


## R7多SRT Batch Router（业务版本仍为V3.0）
- 多SRT新增内部`batch_manifest`与稳定`f01/f02/...`文件槽位；文件身份继续由file_id、filename、SHA-256、canonical source-key摘要共同校验。
- 商品识别仍由助手完成一次轻量语义扫描；Python不伪装自动商品分类器，只验证来源并路由。
- 单商品文件自动READY；多商品只集中确认未决文件；确认后复用task_state和multi-window slice，不重读、不重解析、不重扫。
- 多文件模型短引用使用`f01_c001`等命名空间；单SRT默认仍使用R6形态`c001`，模型payload测试样本仍为3746 bytes。
- Final Gate和verified_manifest逐文件独立；跨文件source_key/manifest直接阻断。
- R7单元测试78/78通过，11文件/6方案既有CLI回归通过；业务版本继续V3.0，不创建V3.1。


## R8多SRT cue scope-once优化（业务版本仍为V3.0）
- R7的多文件行级cue_ref从`f01_c001`改为R8的文件内局部`c001`；文件槽位只在bundle顶层`s=f01`发送一次。
- 安全链不减少：batch_id、file_slot、bundle_id、file_id、filename、SHA-256、canonical source-key映射仍全部校验；跨文件bundle解析继续硬阻断。
- 旧R7 namespaced bundle保持可恢复，避免跨轮状态失效。
- 上一轮三份真实SRT同条件payload合计58,339→54,249 bytes，下降7.011%；其中`10月29日(1).srt` 45,742→42,472 bytes，下降7.149%。
- 单SRT不增加scope字段；`2(4).srt`同一66行生产slice仍为3,746 bytes。
- R8单元测试80/80通过；11份SRT/6份既有CLI方案全部通过。业务版本继续V3.0，不创建V3.1。
